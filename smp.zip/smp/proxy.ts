/**
 * Generate proxy
 */

import {
  API_BASE_URL,
  API_TARGET_URL,
  MOCK_API_BASE_URL,
  MOCK_API_TARGET_URL,
} from './constant';
import { ProxyOptions } from 'vite';

type ProxyTargetList = Record<string, ProxyOptions>;

export const ret: ProxyTargetList = {
  // test
  [API_BASE_URL]: {
    target: API_TARGET_URL,
    changeOrigin: true,
    rewrite: (path) => path.replace(new RegExp(`^${API_BASE_URL}`), ''),
  },
  // 기존 mock url 적용 모듈
  // [MOCK_API_BASE_URL]: {
  //   target: MOCK_API_TARGET_URL,
  //   changeOrigin: true,
  //   rewrite: (path) => path.replace(new RegExp(`^${MOCK_API_BASE_URL}`), '/v1'),
  // },
};

// SMP PostMan Mock Server
export const mock_url: ProxyTargetList = {
  target: MOCK_API_TARGET_URL,
  changeOrigin: true,
  rewrite: (path) => path.replace(new RegExp(`^${MOCK_API_BASE_URL}`), '/v1'),
};

// export default ret;
