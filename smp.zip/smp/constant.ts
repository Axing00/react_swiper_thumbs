/**
 * @name Config
 * @description 프로젝트 설정
 */

// 앱 이름
export const APP_TITLE = 'SMP';

// 로컬 서비스 포트
export const VITE_PORT = 3000;

// prefix
export const API_PREFIX = '/api';

// serve
export const API_BASE_URL = '/api';
export const API_TARGET_URL = 'http://localhost:3000';

// 기존 mock 예시
// export const MOCK_API_BASE_URL = '/mock/api';
// export const MOCK_API_TARGET_URL = 'http://localhost:3000';

// SMP PostMan Mock Server
export const MOCK_API_BASE_URL = '/v1';
export const MOCK_API_TARGET_URL =
  'https://1ba6324e-0e78-4a2b-b071-54eaf7a97f39.mock.pstmn.io';
