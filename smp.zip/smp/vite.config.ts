import { quasar, transformAssetUrls } from '@quasar/vite-plugin';
import vue from '@vitejs/plugin-vue';
import visualizer from 'rollup-plugin-visualizer';
import { AntDesignVueResolver } from 'unplugin-vue-components/resolvers';
import Components from 'unplugin-vue-components/vite';
import { defineConfig } from 'vite';
import { aliasObj } from './aliases';
import { mock_url as proxyTarget } from './proxy';

export default defineConfig(() => {
  const aliasConfig = aliasObj.vite;
  return {
    test: {
      globals: true,
      environment: 'happy-dom',
    },
    plugins: [
      vue({
        template: { transformAssetUrls },
      }),
      quasar({
        sassVariables: 'src/assets/styles/quasar.variables.sass',
      }),
      visualizer({
        filename: 'bundleVisaulizer.html',
        template: 'treemap', // ( default treemap) - Which diagram type to use: sunburst, treemap, network.
        open: true,
      }),
      Components({
        customComponentResolvers: [AntDesignVueResolver()],
      }),
    ],
    server: {
      host: '0.0.0.0',
      // hmr: { overlay: false }, // HMR 연결을 끊거나 설정합니다. server.hmr.overlay를 false로 설정합니다. 서버 오류 커버레이를 사용할 수 없습니다.
      // port: VITE_PORT, // 형식: number 지정 서버 포트
      // open: false, // 종류: boolean | string은 서버가 시작되면 자동으로 브라우저에서 프로그램을 엽니다.
      // cors: false, // 종류: boolean | CorsOptions 서버 개발을 위한 CORS 설정.기본 소스 사용 및 허용
      // proxy: {
      //   '/view': {
      //     target: 'http://localhost:3001',
      //     changeOrigin: false,
      //     secure: false,
      //     logLevel: 'debug',
      //   },
      // },
      // proxy: {
      //   '/api': {
      // target: 'http://200.100.1.135:8000',
      // target: 'http://200.100.1.195',
      // target: 'http://localhost:3000',
      //     changeOrigin: true,
      //   },
      // },

      proxy: { '/v1': proxyTarget },
    },
    build: {
      // 정적 자원 패키지 dist아래의 디렉토리?
      outDir: './dist/spa/',

      emptyOutDir: true,
      rollupOptions: {
        output: {
          // 각 파일 별로 경로 분류
          assetFileNames: (assetInfo) => {
            let extType = assetInfo.name.split('.').at(1);

            if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
              extType = 'img';
            }

            return `assets/${extType}/[name]-[hash][extname]`;
          },
          chunkFileNames: 'assets/chunks/js[name]-[hash].js',
          entryFileNames: 'assets/js/[name]-[hash].js',
          // manualChunks: configManualChunk,
          manualChunks: {
            common: [
              'vue',
              'vue-i18n',
              'vue-router',
              'vue-types',
              '@vueuse/core',
              'pinia',
              'axios',
              'lodash-es',
              'dayjs',
              'dayjs/plugin/utc',
              'dayjs/plugin/timezone',
              'dayjs/plugin/advancedFormat.js',
              'dayjs/plugin/weekYear.js',
              'dayjs/plugin/weekday.js',
              'dayjs/plugin/weekOfYear.js',
              'dayjs/plugin/localeData.js',
              'dayjs/plugin/customParseFormat.js',
            ],
            // 'antdv-dep': [
            //   // 'dayjs',
            //   // 'dayjs/plugin/advancedFormat.js',
            //   // 'dayjs/plugin/weekYear.js',
            //   // 'dayjs/plugin/weekday.js',
            //   // 'dayjs/plugin/weekOfYear.js',
            //   // 'dayjs/plugin/localeData.js',
            //   // 'dayjs/plugin/customParseFormat.js',
            //   'resize-observer-polyfill',
            //   'dom-align',
            //   '@ctrl/tinycolor',
            //   '@ant-design/colors',
            //   '@ant-design/icons-vue',
            // ],
            // antdv: ['ant-design-vue'],
            'v-network-graph': ['v-network-graph'],
            echarts: ['echarts'],
            'vue-echarts': ['vue-echarts'],
          },
        },
        // external: [/node_modules\/ant-design-vue\/es\/(?!table)\/(.*)/],
      },
      // Turning off brotliSize display can slightly reduce packaging time
      // brotliSize: false,

      // 500kb초과시 경고
      chunkSizeWarningLimit: 500,
    },
    resolve: {
      alias: aliasConfig,
    },
    productionSourceMap: false,
    css: {
      preprocessorOptions: {
        scss: {
          prependData: `@import "${__dirname}/src/assets/styles/variables.scss";`,
          quietDeps: true,
        },
      },
    },
  };
});
