Megazone SMP UI Project

- <h4>최초 패키지 설치</h4> <p> <b>-></b> &nbsp; npm i</p>

<br>

- <h4>프로젝트 실행</h4> <p> <b>-></b> &nbsp; npm run dev </p>

<br>

- <h4>현재 서버와 연결되지 않은 상태입니다. 추후 PostMan 서버와 연결할 예정입니다.</h4>

<br>

- <h4>커밋 시 주의사항</h4> <p> <b>-></b> &nbsp; 코드 내에 타입 오류가 있을 경우, 빌드 오류가 발생하니 커밋 전에 타입 설정 오류가 없는지 꼭 확인해주시고, 자동 타입 검사가 실행되지 않아 타입 오류를 파악할 수 없다면, 커밋 전에 로컬 빌드(<em><b>npm run build</b></em>)를 한번 실행한 후에 타입 오류 여부 파악 후 커밋해주시길 바랍니다. </P> <p> <b>-></b> &nbsp; 또한, 타입 오류 외에도 해당 기능 내부에서 발생할 수 있는 build 오류들이 생길 수 있기 때문에 커밋 전 build 실행 후 build 오류 발생시 해당 오류 해결 후 커밋 해주시길 바랍니다. </P>

<br>

- <h4>오류 처리</h4> <p> <b>-></b> &nbsp; Davis-Lite에서 사용하던 통신 실패시 오류 처리는 모두 주석 처리 해놓았습니다. </p> <p> <b>-></b> &nbsp; 오류는 해당하는 기능 Store 내부에서 처리 해주시길 바랍니다.</p> <p> <b>-></b> &nbsp; 에러처리를 위한 에러코드, 메세지 정리는 src > enums > httpResult.ts 파일을 참고해 주시길 바랍니다. </p> <p> <b>-></b> &nbsp; 데이터 요청에 응답값은 모두 Response 내부의 data에 들어가며 data 내부의 data, result, error는 모두 데이터에 대한 결과값을 나타냅니다. </p> <p> <b>-></b> &nbsp; Response 내부의 statusText 값은 통신과 관련된 상태값만을 표시합니다. </p>

<br>

- <h4>페이지 별 Depth 구성</h4> <b>-></b> &nbsp; 각 담당하는 메뉴는 views > page 내부에 depth별로 2 depth까지 모두 directory로 담당자가 직접 생성해주시고, 추후 merge를 통해 디렉토리 구조가 통합되도록 할 예정입니다.
