<template>
  <div class="no-wrap q-pa-md drop-basic detail-search-container">
    <div class="title">
      <span>{{ props.periodTitle }}</span>
    </div>
    <div class="period-area flex align-center">
      <div class="left-area">
        <q-input v-model="date" filled mask="date" :rules="['date']" readonly>
          <template #append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-date v-model="date">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="right-area">
        <q-input v-model="date" filled mask="date" :rules="['date']" readonly>
          <template #append>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-date v-model="date">
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue';

// export default {
// setup () {
//     return {
//     date: ref('2023/02/23');

//     }

// }
// }
const date = ref('2023/02/23');
const props = defineProps({
  periodTitle: String,
});
</script>
