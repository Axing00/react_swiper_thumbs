<template>
  <div class="no-wrap q-pa-md drop-basic current-alarm-detail-search">
    <!-- 기간 영역 -->
    <div v-if="showPeriod">
      <div class="title">
        <span>{{ period }}</span>
      </div>
      <div class="period-area">
        <div>
          <div class="left-area">
            <q-input v-model="startDate" filled mask="date" readonly>
              <template #append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      ref="startDateRef"
                      v-model="startDate"
                      :options="beforeDay"
                      @update:model-value="updateStartDate"
                    >
                      <div class="row items-center justify-end">
                        <q-btn
                          v-close-popup
                          label="Close"
                          color="primary"
                          flat
                        />
                      </div>
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
        <div>
          <div class="right-area">
            <q-input v-model="endDate" filled mask="date" readonly>
              <template #append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      ref="endDateRef"
                      v-model="endDate"
                      :options="afterDay"
                      @update:model-value="updateEndDate"
                    >
                      <div class="row items-center justify-end">
                        <q-btn
                          v-close-popup
                          label="Close"
                          color="primary"
                          flat
                        />
                      </div>
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
      </div>
    </div>
    <!--//끝 기간 영역 -->
    <!-- 중간영역 -->
    <div class="middle-area">
      <div class="left-area">
        <card-comp :theme="`empty`">
          <template #body>
            <!-- 셀렉트 박스 standard 테마-->
            <select-box-comp
              :options="selectObj.options"
              :select="selectObj.select"
              class="y-select select-box"
              :theme="'standard'"
              @change:check="checkSelect"
              @change:selected="(newValue) => (selectObj.select = newValue)"
            />
          </template>
        </card-comp>
      </div>
      <!-- 인풋 (기본) -->
      <div class="right-area">
        <q-input
          v-model="inputName.inputValue"
          :error="inputName.error"
          :error-message="inputName.errorMessage"
          :type="inputName.type"
          :maxlength="50"
          class="y-search"
          outlined
          :placeholder="detailPlaceholder"
        />
      </div>
    </div>
    <!--//끝 중간영역 -->

    <!-- 버튼 영역 -->
    <div class="row y-btn-area">
      <div class="left-area">
        <button-comp
          class="y-btn line"
          :label="initBtn.label"
          :theme="initBtn.theme"
          @click:clicked="clickInitBtn"
        />
      </div>
      <div class="right-area">
        <button-comp
          v-close-popup
          class="y-btn"
          :label="closeBtn.label"
          :theme="closeBtn.theme"
          @click:clicked="clickCloseBtn"
        />
        <button-comp
          v-close-popup
          class="y-btn primary"
          :label="searchBtn.label"
          :theme="searchBtn.theme"
          @click:clicked="clickSearchBtn"
        />
      </div>
    </div>
    <!--//끝 버튼 영역 -->
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue';
import InputComp, { Input } from '@components/InputComp.vue';
import { lang } from '@config/langConfig';
import ButtonComp from '@components/ButtonComp.vue';

// button 인터페이스
interface Button {
  label?: string;
  theme?: 'basic' | 'pink' | 'white';
  icon?: string;
  disable?: boolean;
}

// Store 사용하기 위해 변수에 할당
const startDateRef = ref();
const endDateRef = ref();
const startDate = ref<any>(new Date());
const endDate = ref<any>(new Date());
const emit = defineEmits([
  'init',
  'cancel',
  'ok',
  'detail-close',
  'detail-search',
]);
const period = ref<string>(lang('event.cu.detail.period'));

// 버튼 정보 객체
let initBtn = ref<Button>({
  label: lang('event.cu.detail.initialization'),
  theme: 'basic',
});
let closeBtn = ref<Button>({
  label: lang('event.cu.detail.close'),
  theme: 'basic',
});
let searchBtn = ref<Button>({
  label: lang('event.cu.detail.search'),
  theme: 'pink',
});

// 인풋 이름 객체
const inputName = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: '',
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
});

// 셀렉트 박스 정보 객체
let selectObj = ref<any>({
  options: [],
  select: {},
  error: false,
  errorMessage: lang('common.validation.required'),
});

const props = defineProps({
  detailSearchOption: {
    type: Object,
    required: false,
    default: () => {
      return {};
    },
  },
  detailPlaceholder: {
    type: String,
    required: false,
    default: '',
  },
  startDate: {
    type: String,
    required: false,
    default: '',
  },
  endDate: {
    type: String,
    required: false,
    default: '',
  },
  searchWord: {
    type: String,
    required: false,
    default: '',
  },
  menuType: {
    type: String,
    required: false,
    default: '',
  },
  showPeriod: {
    type: Boolean,
    required: false,
    default: true,
  },
});

// 셀렉트 박스 값 변경시 동작하는 함수
function checkSelect() {
  if (selectObj.value.select.value === null) {
    selectObj.value.error = true;
    selectObj.value.errorMessage = lang('common.validation.required');
  } else {
    selectObj.value.error = false;
  }
}

function clickInitBtn() {
  setToday();
  initData();
}

async function clickCloseBtn() {
  let start = startDate.value.replaceAll('/', '-');
  let end = endDate.value.replaceAll('/', '-');
  let params = {
    start: start,
    end: end,
    input: inputName.value.inputValue,
    option: selectObj.value.select.label,
  };
  await emit('detail-close', params);
}

async function clickSearchBtn() {
  let start = startDate.value.replaceAll('/', '-');
  let end = endDate.value.replaceAll('/', '-');
  let params = {
    start: start,
    end: end,
    input: inputName.value.inputValue,
    option: selectObj.value.select.label,
  };
  await emit('detail-search', params);
  // await clickInitBtn();
}

function updateStartDate(value, reason, details) {
  startDate.value =
    details.year +
    '-' +
    (details.month >= 10 ? details.month : '0' + details.month) +
    '-' +
    (details.day >= 10 ? details.day : '0' + details.day);
}

function updateEndDate(value, reason, details) {
  endDate.value =
    details.year +
    '-' +
    (details.month >= 10 ? details.month : '0' + details.month) +
    '-' +
    (details.day >= 10 ? details.day : '0' + details.day);
}
function initDate() {
  const dates = new Date();
  const year = dates.getFullYear();
  const month = dates.getMonth() + 1;
  const day = dates.getDate();

  if (props.menuType == 'currentAlarm') {
    startDate.value = props.startDate;
    endDate.value = props.endDate;
  } else {
    startDate.value =
      props.startDate != ''
        ? props.startDate
        : `${year}-${month >= 10 ? month : '0' + month}-${
            day >= 10 ? day : '0' + day
          }`;
    endDate.value =
      props.endDate != ''
        ? props.endDate
        : `${year}-${month >= 10 ? month : '0' + month}-${
            day >= 10 ? day : '0' + day
          }`;
  }
}
function setToday() {
  const dates = new Date();
  const year = dates.getFullYear();
  const month = dates.getMonth() + 1;
  const day = dates.getDate();

  if (props.menuType == 'currentAlarm') {
    startDate.value = '';
    endDate.value = '';
  } else {
    startDate.value = `${year}-${month >= 10 ? month : '0' + month}-${
      day >= 10 ? day : '0' + day
    }`;
    endDate.value = `${year}-${month >= 10 ? month : '0' + month}-${
      day >= 10 ? day : '0' + day
    }`;
  }
}

function initData() {
  inputName.value.inputValue = '';
  selectObj.value.select = {
    label: lang('event.cu.detail.all'),
    value: null,
    description: null,
  };
}

// endDate 이후의 날짜 비활성화 처리
function beforeDay(date) {
  return date <= endDate.value.replaceAll('-', '/');
}

// startDate 이전의 날짜 비활성화 처리
function afterDay(date) {
  return date >= startDate.value.replaceAll('-', '/');
}

// 해당 라이프 사이클시 동작하는 메소드 (사용 안하면 삭제)
onMounted(async () => {
  try {
    inputName.value.inputValue = props.searchWord;
    selectObj.value = props.detailSearchOption;
    initDate();
  } catch (err) {
    // console.log(err);
  }
});
onBeforeUnmount(() => {
  // clickInitBtn();
});
</script>
