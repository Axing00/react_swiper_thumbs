<template>
  <default-dialog
    ref="dialogRef"
    :title="title"
    :persistent="persistent"
    :cancel-btn="cancelBtn"
    @ok="onClickOK"
    @cancel="onClickCancel"
  >
    <template #body>
      {{ $t(message) }}
    </template>
  </default-dialog>
</template>

<script setup lang="ts">
// import { useDialogPluginComponent } from 'quasar';

import DefaultDialog from '@components/dialog/DefaultDialog.vue';
import { ref } from 'vue';
import { QDialog } from 'quasar';

defineProps({
  // 타이틀
  title: {
    type: String,
    default: 'common.dialog.confirm',
    required: false,
  },
  // 확인 알림창일 때의 메세지
  message: {
    type: String,
    default: 'message',
    required: false,
  },
  // persistence 속성
  persistent: {
    type: Boolean,
    default: true,
    required: false,
  },
  cancelBtn: {
    type: Boolean,
    default: true,
    required: false,
  },
});

const dialogRef = ref(QDialog);

const emit = defineEmits(['ok', 'cancel']);
function onClickOK() {
  emit('ok');
  dialogRef.value.hide();
}

function onClickCancel() {
  emit('cancel');
  dialogRef.value.hide();
}
</script>
