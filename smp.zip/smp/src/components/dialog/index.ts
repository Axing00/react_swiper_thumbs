import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';
import { Dialog, DialogChainObject } from 'quasar';
import { Component } from 'vue';

type DialogOption = {
  component: Component;
  componentProps?: unknown;
};

const dialog = {
  /**
   * dialog 창 열기
   * @param option
   *  {
   *    component:  > 사용자 정의 컴포넌트
   *    componentProps: Object > 사용자 정의 전달 값
   * }
   * @returns
   */
  open(option: DialogOption): DialogChainObject {
    const popup = Dialog.create({
      componentProps: option.componentProps,
      component: option.component,
    });
    return popup;
  },

  /**
   * Confirm Dialog
   * @param title > 다국어 키
   * @param message  > 다국어 키
   * @returns
   */
  confirm(title: string, message: string): DialogChainObject {
    return this.open({
      component: ConfirmDialog,
      componentProps: {
        title: title,
        message: message,
      },
    });
  },
};

export default dialog;
