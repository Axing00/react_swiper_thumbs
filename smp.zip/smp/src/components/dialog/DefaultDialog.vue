<template>
  <q-dialog
    ref="dialogRef"
    persistent
    medium
    @hide="onDialogHide"
    @show="onShow"
  >
    <!-- "설명" 같이 사이즈가 큰 팝업창은 .popup-container.y-lg 로 사용 -->
    <div class="popup-container" :class="[size]">
      <!-- 타이틀 부분 -->
      <q-card-section class="modal-title-basic y-title-area">
        <slot name="header">
          <p>{{ $t(title) }}</p>
          <span v-if="closeBtn" v-close-popup class="close-btn"> </span>
        </slot>
        <q-space />
      </q-card-section>
      <!-- // 타이틀 부분 -->

      <!-- body -->
      <div class="content-area">
        <slot name="body"> </slot>
      </div>

      <!-- // body -->

      <slot name="button">
        <div class="footer-area">
          <div class="y-btn-area">
            <q-btn
              v-if="cancelBtn"
              :label="$t('common.button.cancel')"
              class="y-btn"
              @click="onCancelClick"
            />
            <q-btn
              :label="$t('common.button.ok')"
              class="y-btn primary"
              @click="onOKClick"
            />
          </div>
        </div>
      </slot>
    </div>
  </q-dialog>
</template>

<script setup lang="ts">
import { useDialogPluginComponent } from 'quasar';

defineProps({
  // 타이틀
  title: {
    type: String,
    default: 'common.dialog.confirm',
    required: true,
  },
  closeBtn: {
    type: Boolean,
    default: true,
  },
  size: {
    type: String,
    default: '',
  },
  cancelBtn: {
    type: Boolean,
    default: true,
    required: false,
  },
});

const emit = defineEmits([...useDialogPluginComponent.emits, 'cancel', 'show']);

const { dialogRef, onDialogHide, onDialogCancel } = useDialogPluginComponent();

/**
 * OK 버튼 클릭
 * 수동으로 ok 이벤트 전달
 * ok 이벤트를 받는 곳에서 hide() 호출
 * ex)
 *      emit('ok');
 *      dialogRef.value.hide();
 */
function onOKClick() {
  // onDialogOK();
  emit('ok');
}

function onShow() {
  emit('show');
}

function onCancelClick() {
  onDialogCancel();
}
defineExpose({ hide });
function hide() {
  dialogRef.value?.hide();
}
</script>
