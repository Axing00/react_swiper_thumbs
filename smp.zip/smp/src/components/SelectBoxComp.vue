<template>
  <q-select
    v-model="selectedValue"
    dense
    options-dense
    no-error-icon
    hide-bottom-space
    :class="classList"
    :options="props.options"
    :disable="props.disable"
    :readonly="props.readonly"
    :error="props.error"
    :error-message="props.errorMessage"
    :virtual-scroll-item-size="virtualScrollSize"
    :popup-content-class="popupContentClass"
    outlined
    @change="checkValidation"
    @blur="checkValidation"
  />
</template>

<script lang="ts" setup>
import { computed, PropType, ref } from 'vue';

export interface SelectBox {
  options: Option[];
  select: Option;
  error?: boolean;
  errorMessage?: string;
}
export interface Option {
  label: string;
  value: string | number | null;
  description?: string | null;
}
const emit = defineEmits(['change:selected', 'change:check']);

const props = defineProps({
  disable: { type: Boolean, default: false, required: false },
  readonly: { type: Boolean, default: false, required: false },
  options: {
    type: Array as PropType<Array<Option>>,
    default: () => [
      {
        label: '선택하세요',
        value: null,
        description: null,
      },
    ],
    required: false,
  },
  select: {
    type: Object as PropType<Option>,
    default: () => {
      return { label: '선택하세요', value: null, description: null };
    },
    required: false,
  },
  error: { type: Boolean, default: false, required: false },
  errorMessage: { type: String, default: '오류입니다.', required: false },
  theme: { type: String, default: 'basic', required: false },
  size: { type: String, default: undefined, required: false },
});

const selectedValue = computed({
  get() {
    return props.select;
  },
  set(val) {
    emit('change:selected', val);
  },
});

// 유효성 체크
function checkValidation() {
  emit('change:check');
}

// 테마별 class 변경
let classList = ref<Array<string>>([]);
let isOutline = ref<boolean>(true);
let virtualScrollSize = ref<number>(24);
let popupContentClass = ref<string>();
function checkTheme() {
  switch (props.theme) {
    case 'standard':
      isOutline.value = false;
      classList.value = ['select-standard'];
      break;

    default:
      classList.value = ['select-basic'];
      break;
  }
}
checkTheme();

function checkSize() {
  switch (props.size) {
    case 'xs':
      virtualScrollSize.value = 14;
      classList.value.push('select-size-xs');
      popupContentClass.value = 'font-size-12';
      break;

    default:
      break;
  }
}
checkSize();
</script>
