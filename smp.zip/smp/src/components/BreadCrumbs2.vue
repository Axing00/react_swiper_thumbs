<!-- 
title_path에 parent만 있는 경우
parent 1 > sub parent 2 > sub parent 3 > ....

title_path에 parent / link가 있는 경우
parent 1 > sub parent 2 > link > menuCode.title
 -->
<template>
  <div class="bread-crumbs-container">
    <q-breadcrumbs class="bread-font-m detail-title-area">
      <template #separator>
        <q-icon size="16px" name="chevron_right" class="bread-crumb" />
      </template>
      <q-breadcrumbs-el
        v-for="(menuCode, idx) in titlePathInfo.parents"
        :key="idx"
        :label="$t(`${menuCode}.title`)"
        class="title"
      />

      <!-- 상세 페이지인 경우 링크/상세 추가-->
      <template
        v-if="titlePathInfo.parents.length != 0 && titlePathInfo.link != ''"
      >
        <q-breadcrumbs-el
          :label="$t(`${titlePathInfo.link}.title`)"
          class="title"
          :to="gethref()"
        />
        <q-breadcrumbs-el :label="$t(`common.label.detail`)" class="title" />
      </template>
      <!-- // 상세 페이지인 경우 -->
    </q-breadcrumbs>
  </div>
</template>

<script setup lang="ts">
// 라우터
import { router } from '@/router';
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';

const route = useRoute();
const titlePathInfo = ref({
  parents: [] as string[],
  link: '',
});

// 마지막 부모의 키 값을 마지막 (.) 으로 분리하여 배열에 등록
const getParentsFn = (datas: string[]) => {
  if (datas.length == 0) return [];

  const lastParent = datas[datas.length - 1];
  const pCode = lastParent.substring(0, lastParent.lastIndexOf('.'));
  if (pCode != '') {
    datas.push(pCode);
    getParentsFn(datas);
  }
  return datas;
};

const getTitlePathInfoFn = () => {
  // titlePath 기본 구조체 - meta.title_path 정보 읽기
  const titlePath = Object.assign(
    { parent: '', link: '' },
    route?.meta?.title_path
  );

  // 부모값을 배열에 등록 -> 재귀호출을 통해 부모 구조 만들기전 기본 데이터형
  const datas = [] as string[];
  if (titlePath.parent != '') {
    datas.push(titlePath.parent);
  }

  return {
    parents: getParentsFn(datas).reverse(),
    link: titlePath.link,
  };
};

function gethref() {
  const target = router.resolve({ name: titlePathInfo.value.link });
  return target?.href ?? '/';
}

const updatePath = () => {
  titlePathInfo.value = getTitlePathInfoFn();
};

onMounted(() => {
  updatePath();
});

defineExpose({
  updatePath,
});
</script>
