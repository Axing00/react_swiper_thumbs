<!-- 
  DataTable 공통 컴포넌트
  created by yoonsunsohn (2022-06-13)
  참고: https://antdv.com/components/table
 -->
<template>
  <div class="table-area">
    <div class="content-top">
      <!-- DataTable 제목 -->
      <div class="top-left">
        <h3 class="main-title">{{ title }}</h3>
      </div>
      <!-- DataTable 우측 상단 필터/버튼 영역 -->
      <div class="top-right">
        <!-- Input 필터 -->
        <q-input
          v-if="!!props.inputFilter"
          ref="keywordRef"
          v-model="searchInput"
          :maxlength="50"
          :placeholder="listPlaceholder"
          outlined
          class="y-search"
        >
          <template #prepend>
            <q-icon name="search" />
          </template>
          <template #append>
            <q-icon
              name="close"
              class="cursor-pointer close"
              @click="searchInput = ''"
            />
          </template>
        </q-input>
        <!-- Selectbox 필터 1 -->
        <q-select
          v-for="(selectFilter, idx) in selectFilterArr"
          :key="selectFilter.column"
          v-model="searchSelectArr[idx]"
          :options="selectFilter.selectOptions"
          class="y-select"
          outlined
          popup-content-class="y-select-drop table-select-drop"
        />
        <!-- 자동 새로고침 시간 표시 -->
        <span v-if="props.autoRefresh" class="auto-time">{{
          refreshTimeText
        }}</span>
        <!-- 자동 새로고침 토글 -->
        <q-toggle
          v-if="props.autoRefresh"
          v-model="isAutoRefresh"
          :label="$t('common.label.autoRefresh')"
          class="auto-new"
          @update:model-value="onUpdateAutoRefresh"
        />
        <!-- 생성 버튼 -->
        <q-btn
          v-if="addBtn"
          class="y-btn primary"
          :label="$t('common.button.create')"
          :icon="`add`"
          @click="onClickAdd"
        />
        <!-- 알람 영역 -->
        <div v-if="showAlarmCount" class="current-alarm-container">
          <div class="current-alarm-area">
            <div class="contents all-area">
              <span class="label-area">ALL</span>
              <span class="count-area">{{ alarmAllCount }}</span>
            </div>
            <div class="contents cr-area">
              <span class="label-area">CR</span>
              <span class="count-area">{{ alarmCriticalCount }}</span>
            </div>
            <div class="contents mj-area">
              <span class="label-area">MJ</span>
              <span class="count-area">{{ alarmMajorCount }}</span>
            </div>
            <div class="contents mn-area">
              <span class="label-area">MN</span>
              <span class="count-area">{{ alarmMinorCount }}</span>
            </div>
            <div class="contents wr-area">
              <span class="label-area">WR</span>
              <span class="count-area">{{ alarmWarningCount }}</span>
            </div>
          </div>
        </div>
        <!-- Clear 버튼 -->
        <q-btn
          v-if="clearBtn"
          class="y-btn green"
          label="Clear"
          :icon="`check`"
          :disable="
            title !== $t('event.lo.title') && title !== $t('event.cu.title')
              ? false
              : selectedRowKeysArray.length > 0
              ? false
              : true
          "
          @click="onClickClear"
        />
        <!-- 상세 검색 버튼 -->
        <q-btn-dropdown
          v-if="detailSearchBtn"
          class="y-btn detail-search primary"
          :label="$t('common.button.detailSearch')"
          :icon="`search`"
        >
          <detail-search-comp
            :show-period="showPeriod"
            :start-date="startDate"
            :end-date="endDate"
            :menu-type="menuType"
            :search-word="searchWord"
            :detail-search-option="detailSearchOption"
            :detail-placeholder="detailPlaceholder"
            @detail-search="onClickDetailSearch"
            @detail-close="onClickDetailClose"
          />
        </q-btn-dropdown>
        <!-- 새로고침 버튼 -->
        <button
          v-if="refreshBtn"
          class="refresh-btn"
          @click="onClickRefresh"
        ></button>
        <div v-if="dataCount">총 {{ filteredData.length }}건</div>
      </div>
    </div>
    <a-table
      :columns="props.columns"
      :data-source="filteredData"
      :pagination="props.pagination"
      :show-sorter-tooltip="false"
      :row-selection="rowSelection"
      :on-change="onClickPageChange"
    >
      <template #emptyText>
        <span>{{ $t('common.message.noData') }}</span>
      </template>
      <template #bodyCell="{ column, record }">
        <!-- object일 경우 label로 표시-->
        <template v-if="column.key === 'object'">
          <div>
            {{ record[column.dataIndex].label }}
          </div>
        </template>
        <!-- progress 이용-->
        <template v-if="column.key === 'progress'">
          <progress
            v-if="checkUseProgress(record[column.dataIndex].percent)"
            :value="record[column.dataIndex].percent"
            :max="100"
            :title="record[column.dataIndex].title"
          />
          <progress
            v-else-if="!checkUseProgress(record[column.dataIndex].percent)"
            :value="0"
            :max="100"
            :title="record[column.dataIndex].title"
          />
        </template>
        <!-- 아이콘 표시 이름 -->
        <template v-if="column.key === 'iconName'">
          <div>
            <i
              :class="`name-icon ${record[column.dataIndex].icon}`"
              style="margin-right: 5px"
            />
            <a class="table-link" @click="column.move(record)">
              {{ record[column.dataIndex].name }}
            </a>
          </div>
        </template>
        <!-- 이름 클릭해서 상세보기로 이동 -->
        <template
          v-if="
            checkNameType(column.key, record[column.dataIndex]) === 'string'
          "
        >
          <a class="table-link" @click="column.move(record)">
            {{ record[column.dataIndex] }}
          </a>
        </template>
        <!-- 이름 클릭해서 상세보기로 이동 (Object로 넘어올 경우) -->
        <template
          v-if="
            checkNameType(column.key, record[column.dataIndex]) === 'object'
          "
        >
          <div class="column-object">
            <a class="table-link" @click="column.move(record)">
              {{ record[column.dataIndex].name }}
            </a>
            <span
              v-for="(recordObj, idx) in record[column.dataIndex]"
              :key="idx"
              class="table-link-sub"
            >
              {{ recordObj !== record[column.dataIndex].name ? recordObj : '' }}
            </span>
          </div>
        </template>
        <!-- 상태 표시(아이콘 추가 가능)-->
        <template v-if="column.key === 'status'">
          <div
            class="text-icon"
            :class="checkIcon(record[column.dataIndex]).class"
          >
            <q-icon :name="checkIcon(record[column.dataIndex]).icon" />
            {{ record[column.dataIndex] }}
          </div>
        </template>
        <!-- 수직으로 나타내야 하는 칸 -->
        <template v-if="column.key === 'vertical'">
          <div class="column-object">
            <span
              v-for="(columnData, idx) in record[column.dataIndex]"
              :key="idx"
            >
              {{ columnData }}
            </span>
          </div>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup lang="ts">
import { PropType, ref, computed, onMounted, onUnmounted, watch } from 'vue';
import dayjs from 'dayjs';
import forEach from 'lodash-es/forEach';
import times from 'lodash-es/times';
import { AnyRecord } from 'dns';
import { lang } from '@/config/langConfig';
import DetailSearchComp from '@components/DetailSearchComp.vue';
import { defaultPagination } from '@utils/tablePagingHelper';

export interface SelectFilter {
  column: string;
  selectOptions: Array<Selectbox>;
}

export interface Selectbox {
  value: string;
  label: string;
}

const props = defineProps({
  // DataTable 제목
  title: {
    type: String,
    required: false,
    default: '',
  },
  // DataTable 컬럼 (필수)
  columns: {
    type: Array,
    required: true,
    default: () => [],
  },
  // DataTable 데이터 (필수)
  data: {
    type: Array,
    required: true,
    default: () => [],
  },
  // DataTable 페이지네이션
  pagination: {
    type: Object,
    required: false,
    default: () => {
      return defaultPagination;
    },
  },
  // Input 필터
  inputFilter: {
    type: String,
    required: false,
    default: '',
  },
  // Selectbox 필터 배열
  selectFilterArr: {
    type: Array as PropType<Array<SelectFilter>>,
    required: false,
    default: () => {
      return [];
    },
  },
  // 자동 새로고침 토글
  autoRefresh: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 생성 버튼
  addBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 이벤트 알람 영역
  alarmArea: {
    type: Boolean,
    required: false,
    default: false,
  },
  // Clear 버튼
  clearBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 상세 검색 버튼
  detailSearchBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 새로고침 버튼
  refreshBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // DataTable 컬럼 (필수)
  rowSelection: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 테이블 링크 설정
  showLink: {
    type: Boolean,
    required: false,
    default: true,
  },
  showAlarmCount: {
    type: Boolean,
    required: false,
    default: false,
  },
  alarmAllCount: {
    type: Number,
    required: false,
    default: 0,
  },
  alarmCriticalCount: {
    type: Number,
    required: false,
    default: 0,
  },
  alarmMajorCount: {
    type: Number,
    required: false,
    default: 0,
  },
  alarmMinorCount: {
    type: Number,
    required: false,
    default: 0,
  },
  alarmWarningCount: {
    type: Number,
    required: false,
    default: 0,
  },
  // 상세 검색 옵션
  detailSearchOption: {
    type: Object,
    required: false,
    default: () => {
      return {};
    },
  },
  listPlaceholder: {
    type: String,
    required: false,
    default: 'filter',
  },
  detailPlaceholder: {
    type: String,
    required: false,
    default: '',
  },
  refreshTime: {
    type: Number,
    required: false,
    default: 60000,
  },
  startDate: {
    type: String,
    required: false,
    default: '',
  },
  endDate: {
    type: String,
    required: false,
    default: '',
  },
  searchWord: {
    type: String,
    required: false,
    default: '',
  },
  menuType: {
    type: String,
    required: false,
    default: '',
  },
  dataCount: {
    type: String,
    required: false,
    default: '',
  },
  showPeriod: {
    type: Boolean,
    required: false,
    default: true,
  },
});

const emit = defineEmits([
  'update:input-value',
  'autoRefresh',
  'add',
  'clear',
  'detail-search',
  'detail-close',
  'refresh',
  'onChange:onChanged',
]);

watch(
  () => props.data,
  () => {
    searchInput.value = '';
  }
);

// Input 필터 ref(한글 필터링을 위해 사용)
const keywordRef = ref();

// Input 필터 입력값
const searchInput = ref<string>('');

// Selectbox 필터 선택값 배열
const searchSelectArr = ref<Array<Selectbox>>([
  {
    value: 'All',
    label: lang('common.label.all'),
  },
]);

// 필터링된 데이터
const filteredData = computed({
  get: () => {
    const filtered = props.data.filter((d: any) => {
      // Input 필터 조건
      const inputFilterCondition = props.inputFilter
        ? d[props.inputFilter]?.toString().includes(searchInput.value)
        : true;

      // Selectbox 필터 조건 (전체)
      let selectFilterConditions = true;

      forEach(props.selectFilterArr, (selectFilter, idx) => {
        // Selectbox 필터 조건
        const condition =
          searchSelectArr.value[idx]?.value === 'All'
            ? true
            : d[selectFilter.column]
                .toString()
                .includes(searchSelectArr.value[idx]?.value);
        selectFilterConditions = selectFilterConditions && condition;
      });

      return inputFilterCondition && selectFilterConditions;
    });

    return filtered;
  },
  set: (newVal) => {
    emit('update:input-value', newVal);
  },
});

// 자동 새로고침 시간
let refreshTimeText = ref(dayjs().format('YYYY-MM-DD hh:mm:ss'));

// 자동 새로고침 토글
const isAutoRefresh = ref(true);

let timer = ref(
  setInterval(() => {
    emit('autoRefresh');
    refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
  }, props.refreshTime)
);

// 자동 새로고침 토글 시 호출
const onUpdateAutoRefresh = (val: boolean) => {
  if (val) {
    timer.value = setInterval(() => {
      emit('autoRefresh');
      refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
    }, props.refreshTime);
  }
  if (!val && timer.value) {
    clearInterval(timer.value);
  }
};

// 생성 버튼 클릭 시 호출
const onClickAdd = () => {
  const param = 'param test';
  emit('add', param);
};

// Clear 버튼 클릭 시 호출
const onClickClear = () => {
  if (
    props.title === lang('event.lo.title') ||
    props.title === lang('event.cu.title')
  ) {
    emit('clear', selectedRowsId.value);
    selectedRowKeysArray.value = [];
    selectedRowsId.value = [];
  } else {
    let param = 'param test';
    emit('clear', param);
  }
};

// 상세 검색 버튼 클릭 시 호출
const onClickDetailSearch = (params) => {
  emit('detail-search', params);
};

const onClickPageChange = (page) => {
  // 페이지 이동시 선택된 체크박스 해제
  selectedRowKeysArray.value = [];
  selectedRowsId.value = [];
  emit('onChange:onChanged', page);
};

const onClickDetailClose = (params) => {
  emit('detail-close', params);
};

// 새로고침 버튼 클릭 시 호출
const onClickRefresh = () => {
  const param = 'param test';
  refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
  emit('refresh', param);
};

onMounted(() => {
  // Input 필터 한글 필터링(IME 구성 중 v-model이 업데이트 되지 않으므로 getNativeElement() 사용)
  if (props.inputFilter) {
    const el = keywordRef.value.getNativeElement();
    el.addEventListener('input', (e) => {
      searchInput.value = e.target.value;
    });
  }

  // Selectbox 필터 선택값 배열 셋팅
  times(props.selectFilterArr.length, () => {
    const searchSelect = ref<Selectbox>({
      value: 'All',
      label: lang('common.label.all'),
    });
    searchSelectArr.value.push(searchSelect.value);
  });
});

onUnmounted(() => {
  clearInterval(timer.value);
});

function checkIcon(status: string) {
  const upperStatus = status.toUpperCase();
  switch (upperStatus) {
    case 'OK':
    case 'READY':
      return {
        icon: 'check_circle',
        text: upperStatus,
        class: ['ready'],
      };
    case 'RUNNING':
      return {
        icon: 'play_circle_filled',
        text: upperStatus,
        class: ['ready'],
      };
    case 'ERROR':
      return {
        icon: 'error',
        text: upperStatus,
        class: ['error'],
      };
    default:
      return { icon: '', text: upperStatus, class: [] };
  }
}

function checkUseProgress(percent: number) {
  if (percent && percent > 0) {
    return true;
  }
  return false;
}

function checkNameType(key: string, data: string | object) {
  if (key === 'name' && props.showLink && typeof data === 'string') {
    return 'string';
  } else if (key === 'name' && props.showLink && typeof data === 'object') {
    return 'object';
  }
  return null;
}

// 사용자 목록의 선택한 사용자의 인덱스 저장
const selectedRowKeysArray = ref<any[]>([]);
const selectedRowsId = ref<object[]>([]);

const rowSelection = computed(() => {
  if (props.rowSelection) {
    return {
      selectedRowKeys: selectedRowKeysArray,
      onChange: (
        selectedRowKeys: (string | number)[],
        selectedRows: AnyRecord[]
      ) => {
        // console.log(
        //   `selectedRowKeys: ${selectedRowKeys}`,
        //   'selectedRows: ',
        //   selectedRows
        // );
        selectedRowKeysArray.value = selectedRowKeys;
      },
      onSelect: (record: any, selected: boolean, selectedRows: any[]) => {
        if (selected) {
          selectedRowKeysArray.value.push(record.key);
          selectedRowsId.value.push({ alarmId: record.alarmId });
        } else {
          if (selectedRows.length < 1) {
            selectedRowKeysArray.value = [];
            selectedRowsId.value = [];
          }
        }
      },
      onSelectAll: (
        selected: boolean,
        selectedRows: any[],
        changeRows: any[]
      ) => {
        selectedRowKeysArray.value = [];
        selectedRowsId.value = [];
        selectedRows.forEach((item) => {
          selectedRowKeysArray.value.push(item.key);
          selectedRowsId.value.push({ alarmId: item.alarmId });
        });
      },
      getCheckboxProps: (selectedRowKeys) => {
        return {
          disabled:
            (selectedRowKeys.status != undefined &&
              selectedRowKeys.status === '') ||
            (selectedRowKeys.status != undefined &&
              selectedRowKeys.status !== '' &&
              selectedRowKeys.cleared == 1), // This disables the checkboxes for rows with name "John"
        };
      },
    };
  } else {
    return null;
  }
});
</script>
