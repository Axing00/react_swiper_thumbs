<template>
  <q-btn
    :icon="props.icon"
    :label="props.label"
    :class="classList"
    flat
    :disable="props.disable"
    @click="emit('click:clicked')"
  />
</template>

<script lang="ts" setup>
import { ref } from 'vue';

// button 인터페이스
export interface Button {
  label?: string; // 버튼 라벨
  theme?: 'basic' | 'pink' | 'white'; // 버튼 테마
  icon?: string; // icon명
  disable?: boolean; // disable 여부
}
// emit
const emit = defineEmits(['click:clicked']);

const props = withDefaults(defineProps<Button>(), {
  label: '버튼 라벨명',
  theme: 'basic',
  icon: undefined,
  disable: false,
});

// 테마별 class 변경
let classList = ref<Array<string>>();
function checkTheme() {
  switch (props.theme) {
    case 'white':
      classList.value = ['btn-white', 'btn-size-s'];
      break;

    case 'pink':
      classList.value = ['y-btn', 'pink', 'btn-size-s'];
      break;

    default:
      classList.value = ['btn-basic', 'btn-size-s'];
      break;
  }
}
checkTheme();
</script>
