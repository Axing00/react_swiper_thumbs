<template>
  <q-option-group
    v-model="selectedValue"
    color="primary"
    inline
    dense
    :options="props.options"
    :disable="props.disable"
    :size="props.size"
  />

  <!-- 아래 추가 될 수 있는 확장-->
  <!-- 
    :class="classList"
    :error="props.error"
    :error-message="props.errorMessage"
    @change="checkValidation"
    @blur="checkValidation"
    :type="props.type"
   -->
</template>

<script lang="ts" setup>
import { computed, PropType } from 'vue';

const emit = defineEmits(['change:selected']);

interface Options {
  label: string;
  value: string | number | null;
}
const props = defineProps({
  disable: { type: Boolean, default: false, required: false },
  options: {
    type: Array as PropType<Array<Options>>,
    default: () => [
      {
        label: '선택',
        value: null,
      },
    ],
    required: false,
  },
  group: {
    type: Object as PropType<Options>,
    default: () => {
      return { label: '선택', value: null };
    },
    required: false,
  },
  //   error: { type: Boolean, default: false, required: false },
  //   errorMessage: { type: String, default: '오류입니다.', required: false },
  theme: { type: String, default: 'basic', required: false },
  size: { type: String, default: 'xs', required: false },
  // type: {
  //   type: String as PropType<'radio' | 'checkbox' | 'toggle'>,
  //   default: 'radio',
  //   required: false,
  // },
});

const selectedValue = computed({
  get() {
    return props.group.value;
  },
  set(val) {
    for (let g of props.options) {
      if (g.value == val) {
        emit('change:selected', g);
      }
    }
  },
});

// 유효성 체크
// function checkValidation() {
//   emit('change:check');
// }

// 테마별 class 변경
// let classList = ref<Array<string>>();
// function checkTheme() {
//   switch (props.theme) {
//     // case 'pink':
//     //   classList.value = ['btn-pink', 'btn-size-s'];
//     //   break;

//     default:
//       classList.value = ['radio-basic'];
//       break;
//   }
// }
// checkTheme();
</script>
