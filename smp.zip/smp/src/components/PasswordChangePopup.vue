<!-- 
  https://docs.google.com/document/d/1MgPcFksPMJt9I3sNx54lJvIwAJZbbGHg1E34G8mJzPE/edit#

- 약 
-- 패스워드 길이: 4-24

- 중
-- 패스워드 길이: 8-24
-- 동일 문자 연속 입력 허용 : 3  (pppp 오류)
-- 영문 대소문자 포함 : 1자  이상 필수
-- 숫자 포함: 1자 이상 필수
-- 보유한 이전 비밀번호 수 : 1 (sdx서버에서 체크 가능)

- 강
-- 패스워드 길이: 8-24
-- 동일 문자 연속 입력 허용 : 2  (ppp 오류)
-- 영문 대소문자 포함 : 1자  이상 필수
-- 숫자 포함: 1자 이상 필수
-- 보유한 이전 비밀번호 수 : 3 (sdx서버에서 체크 가능)
-- 특수 문자 포함 : 1자 이상 필수  ~`!@#$%\\^&*()-+=


패스워드 안내 예시 
- 길이 : 8 ~ 24
- 최소 1개 이상 포함: 영문 대/소문자, 숫자, 특수문자( ~\\`!@#$%\\^&*()-+= )
- 동일 문자를 2번 이상 연속 입력 금지
 -->

<template>
  <default-dialog
    ref="dialogRef"
    :title="$t('common.passwordDialog.title')"
    :close-btn="false"
    :persistent="true"
  >
    <!-- 다국어키 수정 -->
    <template #body>
      <div class="content-container">
        <div class="">
          <!-- 사용자 ID -->
          <div class="field-area">
            <span class="label">{{ $t('davisMsg.userId') }}</span>
            <q-input
              v-model="currentDavisLoginUserId.inputValue"
              :maxlength="50"
              class="input-box"
              outlined
              :error="currentDavisLoginUserId.error"
              :error-message="currentDavisLoginUserId.errorMessage"
              type="text"
              :rules="[(val) => !!val || $t('davisMsg.required')]"
              readonly
            />
          </div>

          <!-- 변경 비밀번호 입력 창 -->
          <div class="field-area">
            <span class="label">{{
              $t('davisMsg.passwordChange.newPassword')
            }}</span>
            <q-input
              v-model="newPassword.inputValue"
              :maxlength="24"
              type="password"
              class="input-box"
              outlined
              :error="newPassword.error"
              :error-message="newPassword.errorMessage"
              :rules="[(val) => !!val || $t('davisMsg.required')]"
              @update:model-value="resetValueError"
            />
          </div>

          <!-- 변경 비밀번호 확인 입력 창  -->
          <div class="field-area">
            <span class="label">{{
              $t('davisMsg.passwordChange.checkNewPassword')
            }}</span>
            <q-input
              v-model="confirmPassword.inputValue"
              :maxlength="24"
              type="password"
              class="input-box"
              outlined
              :error="confirmPassword.error"
              :error-message="confirmPassword.errorMessage"
              :rules="[(val) => !!val || $t('davisMsg.required')]"
              @update:model-value="resetValueError"
            />
          </div>
          <div class="field-caution">
            <div class="caution-inner">
              <p class="caution-title text-bold">
                {{ $t('davisMsg.passwordChange.passwordRuleTitle') }}
              </p>
              <ul>
                <li v-for="rule in passwordRuleInfos" :key="rule">
                  {{ rule }}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </template>
    <template #button>
      <q-card-actions align="right">
        <div class="footer-area">
          <div class="y-btn-area">
            <!-- 마지막 패스워드 변경 기간이 일정 시간 지난 경우 -->
            <q-btn
              v-if="popupType == PasswordPopupType.PERIOD"
              :label="$t('common.button.notChanged')"
              class="y-btn"
              @click="onNotChangedClick"
            />

            <!-- 패스워드 변경 -->
            <q-btn
              v-if="popupType == PasswordPopupType.CHANGE"
              :label="$t('common.button.close')"
              class="y-btn"
              @click="onNotChangedClick"
            />
            <q-btn
              :label="$t('common.button.save')"
              class="y-btn primary"
              @click="passChangeBtn"
            />
          </div>
        </div>
      </q-card-actions>
    </template>
  </default-dialog>
</template>

<script setup lang="ts">
import { lang } from '@/config/langConfig';
import dialog from '@/components/dialog';
import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';
import notify from '@/config/notifyConfig';
import { useAuthStore } from '@/store/app/useAuthStore';
import regExpUtil from '@/utils/regExpUtil';
import DefaultDialog from '@components/dialog/DefaultDialog.vue';
import { PasswordPopupType } from '@enums/popupType';
import { QDialog } from 'quasar';
import { computed, ref, Ref } from 'vue';
import cacheHelper from '@/utils/cacheHelper';

import { router } from '@router';

type Input = {
  inputValue: any;
  error: boolean;
  errorMessage: string;
};

/**
 * 패스워드 검증 수준
 */
enum PasswordRuleType {
  LOW,
  MIDDLE,
  HIGH,
}

const clickPopupType = defineProps({
  popupType: {
    type: String,
    default: PasswordPopupType.CHANGE,
    required: true,
  },
});

let currentDavisLoginUserId = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: '',
});

let currentPassword = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: '',
});
let newPassword = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: '',
});
let confirmPassword = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: '',
});

const emit = defineEmits(['ok', 'cancel']);
const dialogRef = ref(QDialog);
const authStore = useAuthStore();

if (
  clickPopupType.popupType == 'first' ||
  clickPopupType.popupType == 'period'
) {
  currentDavisLoginUserId.value.inputValue = authStore.userID;
} else if (clickPopupType.popupType == 'change') {
  currentDavisLoginUserId.value.inputValue =
    cacheHelper.getCache('loginUserId');
}

// 패스워드 규칙 - 강/중/약
// 추후 SDX 서버와 통신을 하여 값을 가져오는 방식으로 변경 필요
let passwordRule = PasswordRuleType.MIDDLE;

const resetValueError = () => {
  newPassword.value.error = false;
  newPassword.value.errorMessage = '';

  confirmPassword.value.error = false;
  confirmPassword.value.errorMessage = '';
};

async function passChangeBtn() {
  // 새로운 비밀번호 유효성 검사
  initValidation();

  // 비밀번호 변경 요청
  if (validatePassword(passwordRule)) {
    newPassword.value.inputValue = window.btoa(newPassword.value.inputValue);
    confirmPassword.value.inputValue = window.btoa(
      confirmPassword.value.inputValue
    );
    try {
      const result = await authStore.davisChangePassword(
        currentDavisLoginUserId.value.inputValue,
        newPassword.value.inputValue,
        confirmPassword.value.inputValue
      );

      if (result === 'NOK') {
        newPassword.value.error = true;
        newPassword.value.errorMessage = lang(
          'davisMsg.passwordChange.error.usedNewPassword' // 이전에 사용한 비밀번호는 사용할 수 없습니다.
        );

        confirmPassword.value.error = true;
        confirmPassword.value.errorMessage = lang(
          'davisMsg.passwordChange.error.usedNewPassword' // 이전에 사용한 비밀번호는 사용할 수 없습니다.
        );

        return;
      } else if (result == 'OK') {
        // 비밀번호 변경 후 한번 더 로그인 방식으로 변경
        emit('ok');
        dialogRef.value.hide();

        if (clickPopupType.popupType == 'first') {
          // 최초 로그인 or 비밀번호 초기화 이후 비밀번호 변경
          dialog.open({
            component: ConfirmDialog,
            componentProps: {
              message: lang(
                'davisMsg.login.info.passChangeCompleteMoveToLogin'
              ),
              // 비밀번호 변경이 완료되었습니다. 다시 한번 로그인 해주세요.
              position: 'top',
              persistent: false,
              closeBtn: false,
              cancelBtn: false,
            },
          });
        } else if (clickPopupType.popupType == 'period') {
          // 비밀번호 변경 이후 3개월 초과
          dialog.open({
            component: ConfirmDialog,
            componentProps: {
              message: lang('davisMsg.login.info.passChangeCompleteMoveToMain'),
              // 비밀번호 변경이 완료되었습니다. 메인화면으로 이동합니다.
              position: 'top',
              persistent: false,
              closeBtn: false,
              cancelBtn: false,
            },
          });

          router.push({
            name: 'main',
          });
        } else if (clickPopupType.popupType == 'change') {
          dialog.open({
            component: ConfirmDialog,

            componentProps: {
              title: lang('davisMsg.login.passwordChange'),
              message: lang('davisMsg.login.info.passChangeComplete'),
              // 비밀번호 변경이 완료되었습니다.
              persistent: false,
              cancelBtn: false,
            },
          });
        }
      }
    } catch (e) {
      // console.error(e);
    } finally {
      newPassword.value.inputValue = '';
      confirmPassword.value.inputValue = '';
    }
  }
}

// 다음에 변경 선택
function onNotChangedClick() {
  emit('cancel');
  dialogRef.value.hide();

  if (clickPopupType.popupType == 'period') {
    router.push({
      name: 'main',
    });
  }
}

function setErrorMsg(input: Ref<Input>, errMsg: string) {
  input.value.error = errMsg != '';
  input.value.errorMessage = errMsg != '' ? lang(errMsg) : '';
}

function initValidation() {
  const ERROR_MSG_REQUIRED = 'davisMsg.passwordChange.validation.required';
  const currErrMsg =
    currentPassword.value.inputValue == '' ? ERROR_MSG_REQUIRED : '';
  setErrorMsg(currentPassword, currErrMsg);

  const newErrMsg =
    newPassword.value.inputValue == '' ? ERROR_MSG_REQUIRED : '';
  setErrorMsg(newPassword, newErrMsg);

  const confErrMsg =
    confirmPassword.value.inputValue == '' ? ERROR_MSG_REQUIRED : '';
  setErrorMsg(confirmPassword, confErrMsg);
}

/**
 * 패스워드 검증
 * @param type
 */
function validatePassword(type: PasswordRuleType): boolean {
  // const curPwd = currentPassword.value.inputValue;
  const curId = currentDavisLoginUserId.value.inputValue;
  const newPwd = newPassword.value.inputValue;
  const confPwd = confirmPassword.value.inputValue;

  let resultMsg = '';
  if (curId == '' || newPwd == '' || confPwd == '') {
    return false;
  }

  if (PasswordRuleType.LOW == type) {
    resultMsg = checkLowValidation(newPwd);
  } else if (PasswordRuleType.MIDDLE == type) {
    resultMsg = checkMiddleValidation(newPwd);
  } else {
    resultMsg = checkHighValidation(newPwd);
  }

  if (resultMsg == '') {
    if (newPwd != confPwd) {
      resultMsg = lang('davisMsg.passwordChange.validation.diffNewConfirm');
    }
  }

  if (resultMsg != '') {
    newPassword.value.errorMessage = resultMsg;
    newPassword.value.error = true;
    return false;
  } else {
    return true;
  }
}

/**
 * 패스워드 검증 - LOW
 * @param pwd
 */
function checkLowValidation(pwd: string): string {
  return checkMinMaxLength(pwd, 4, 24);
}

/**
 * 패스워드 검증 - Middle
 * @param pwd
 */
function checkMiddleValidation(pwd: string): string {
  // 최소/최대 길이
  let resultMsg = checkMinMaxLength(pwd, 8, 24);
  if (resultMsg != '') {
    return resultMsg;
  }

  // 반복 금지
  resultMsg = checkOverRepeat(pwd, 3);
  if (resultMsg != '') {
    return resultMsg;
  }

  // 영문자 포함
  if (!regExpUtil.checkMinAlpha(pwd)) {
    return lang('davisMsg.passwordChange.validation.minAlpha');
  }

  // 숫자 포함
  if (!regExpUtil.checkMinNum(pwd)) {
    return lang('davisMsg.passwordChange.validation.minNumeric');
  }

  return '';
}

/**
 * 패스워드 검증 - High
 * @param pwd
 */
function checkHighValidation(pwd: string): string {
  // 최소/최대 길이
  let resultMsg = checkMinMaxLength(pwd, 8, 24);
  if (resultMsg != '') {
    return resultMsg;
  }

  // 반복 금지
  resultMsg = checkOverRepeat(pwd, 2);
  if (resultMsg != '') {
    return resultMsg;
  }

  // 영문자 포함
  if (!regExpUtil.checkMinAlpha(pwd)) {
    return lang('davisMsg.passwordChange.validation.minAlpha');
  }

  // 숫자 포함
  if (!regExpUtil.checkMinNum(pwd)) {
    return lang('davisMsg.passwordChange.validation.minNumeric');
  }

  // 특수 문자 포함
  if (!regExpUtil.checkMinSpecial(pwd)) {
    return lang('davisMsg.passwordChange.validation.minSpecial');
  }

  return '';
}

/**
 * 패스워드 - 최소/최대 길이 제한
 * @param pwd
 * @param min
 * @param max
 */
function checkMinMaxLength(pwd: string, min: number, max: number): string {
  if (!regExpUtil.checkMinMaxLength(pwd, min, max)) {
    return lang('davisMsg.passwordChange.validation.minMaxLength', [min, max]);
  }
  return '';
}

/**
 * 패스워드 - 최대 문자 반복 제한
 * @param pwd
 * @param count
 */
function checkOverRepeat(pwd: string, count: number): string {
  let result = '';
  if (regExpUtil.checkOverRepeat(pwd, count)) {
    return lang('davisMsg.passwordChange.validation.maxRept', [count + 1]);
  }
  return result;
}

const passwordRuleInfos = computed((): string[] => {
  const rules = [] as string[];
  if (PasswordRuleType.LOW == passwordRule) {
    console.log('');
  } else if (PasswordRuleType.MIDDLE == passwordRule) {
    let rule1 = lang('davisMsg.passwordChange.rule.len', [8, 24]);
    rules.push(rule1);
    let rule2 = lang('davisMsg.passwordChange.rule.sameChar', [4]);
    rules.push(rule2);
    let rule3 = lang('davisMsg.passwordChange.rule.inChar');
    rules.push(rule3);
    let rule4 = lang('davisMsg.passwordChange.rule.noSpace');
    rules.push(rule4);
  } else if (PasswordRuleType.HIGH == passwordRule) {
    console.log('');
  }
  return rules;
});
</script>
