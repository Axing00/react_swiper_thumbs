<!-- 
  DataTable 공통 컴포넌트
  created by yoonsunsohn (2022-06-13)
  참고: https://antdv.com/components/table
 -->
<template>
  <div class="table-area">
    <div class="title-wrap">
      <!-- DataTable 제목 -->
      <h3>{{ title }}</h3>
      <!-- DataTable 우측 상단 필터/버튼 영역 -->
      <div class="area-right">
        <!-- Input 필터 -->
        <q-input
          v-if="!!props.inputFilter"
          ref="keywordRef"
          v-model="searchInput"
          placeholder="filter"
          outlined
        >
          <template #append>
            <q-icon
              name="close"
              class="cursor-pointer"
              @click="searchInput = ''"
            />
          </template>
        </q-input>
        <!-- Selectbox 필터 1 -->
        <q-select
          v-for="(selectFilter, idx) in selectFilterArr"
          :key="selectFilter.column"
          v-model="searchSelectArr[idx]"
          outlined
          class="y-select"
          :options="selectFilter.selectOptions"
        />
        <!-- 자동 새로고침 시간 표시 -->
        <span v-if="props.autoRefresh">{{ refreshTimeText }}</span>
        <!-- 자동 새로고침 토글 -->
        <q-toggle
          v-if="props.autoRefresh"
          v-model="isAutoRefresh"
          label="자동 새로고침"
          @update:model-value="onUpdateAutoRefresh"
        />
        <!-- 생성 버튼 -->
        <q-btn v-if="addBtn" label="생성" :icon="`add`" @click="onClickAdd" />
        <!-- Clear 버튼 -->
        <q-btn v-if="clearBtn" label="Clear" @click="onClickClear" />
        <!-- 상세 검색 버튼 -->
        <q-btn
          v-if="detailSearchBtn"
          label="상세 검색"
          :icon="`search`"
          @click="onClickDetailSearch"
        />
        <!-- 새로고침 버튼 -->
        <q-btn
          v-if="refreshBtn"
          :label="$t('common.button.refresh')"
          :icon="`refresh`"
          @click="onClickRefresh"
        />
      </div>
    </div>
    <a-table
      :columns="props.columns"
      :data-source="filteredData"
      :pagination="props.pagination"
      :show-sorter-tooltip="false"
    >
      <template #bodyCell="{ column, record }">
        <!-- object일 경우 label로 표시-->
        <template v-if="column.key === 'object'">
          <div>
            {{ record[column.dataIndex].label }}
          </div>
        </template>
        <!-- progress 이용-->
        <template v-if="column.key === 'progress'">
          <progress
            v-if="checkUseProgress(record[column.dataIndex].percent)"
            :value="record[column.dataIndex].percent"
            :max="100"
            :title="record[column.dataIndex].title"
          />
          <progress
            v-else-if="!checkUseProgress(record[column.dataIndex].percent)"
            :value="0"
            :max="100"
            :title="record[column.dataIndex].title"
          />
        </template>
        <!-- 이름 클릭해서 상세보기로 이동 -->
        <template v-if="column.key === 'name'">
          <a class="table-link" @click="column.move(record)">
            {{ record[column.dataIndex] }}
          </a>
        </template>
        <!-- 상태 표시(아이콘 추가 가능)-->
        <template v-if="column.key === 'status'">
          <div class="text-icon">
            <q-icon
              v-if="checkIsOk(record[column.dataIndex])"
              name="check_circle"
            />
            <q-icon
              v-else-if="record[column.dataIndex] === `RUNNING`"
              name="play_circle_filled"
            />
            <q-icon
              v-else-if="!checkIsOk(record[column.dataIndex])"
              name="error"
            />

            {{ record[column.dataIndex] }}
          </div>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script setup lang="ts">
import { PropType, ref, computed, onMounted } from 'vue';
import dayjs from 'dayjs';
import forEach from 'lodash-es/forEach';
import times from 'lodash-es/times';

export interface SelectFilter {
  column: string;
  selectOptions: Array<Selectbox>;
}

export interface Selectbox {
  value: string;
  label: string;
}

const props = defineProps({
  // DataTable 제목
  title: {
    type: String,
    required: false,
    default: '',
  },
  // DataTable 컬럼 (필수)
  columns: {
    type: Array,
    required: true,
    default: () => [],
  },
  // DataTable 데이터 (필수)
  data: {
    type: Array,
    required: true,
    default: () => [],
  },
  // DataTable 페이지네이션
  pagination: {
    type: Object,
    required: false,
    default: () => {
      return {
        position: ['bottomCenter'], // 페이지네이션 위치 (하단 중앙)
        hideOnSinglePage: true, // 1페이지만 존재할 경우 페이지네이션 숨김
        showSizeChanger: false, // 페이지 사이즈 변경 옵션 노출 여부
      };
    },
  },
  // Input 필터
  inputFilter: {
    type: String,
    required: false,
    default: '',
  },
  // Selectbox 필터 배열
  selectFilterArr: {
    type: Array as PropType<Array<SelectFilter>>,
    required: false,
    default: () => {
      return [];
    },
  },
  // 자동 새로고침 토글
  autoRefresh: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 생성 버튼
  addBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // Clear 버튼
  clearBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 상세 검색 버튼
  detailSearchBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
  // 새로고침 버튼
  refreshBtn: {
    type: Boolean,
    required: false,
    default: false,
  },
});

const emit = defineEmits([
  'update:input-value',
  'autoRefresh',
  'add',
  'clear',
  'detail-search',
  'refresh',
]);

// Input 필터 ref(한글 필터링을 위해 사용)
const keywordRef = ref();

// Input 필터 입력값
const searchInput = ref<string>('');

// Selectbox 필터 선택값 배열
const searchSelectArr = ref<Array<Selectbox>>([
  {
    value: 'All',
    label: 'All',
  },
]);

// 필터링된 데이터
const filteredData = computed({
  get: () => {
    const filtered = props.data.filter((d: any) => {
      // Input 필터 조건
      const inputFilterCondition = props.inputFilter
        ? d[props.inputFilter].toString().includes(searchInput.value)
        : true;

      // Selectbox 필터 조건 (전체)
      let selectFilterConditions = true;

      forEach(props.selectFilterArr, (selectFilter, idx) => {
        // Selectbox 필터 조건
        const condition =
          searchSelectArr.value[idx]?.value === 'All'
            ? true
            : d[selectFilter.column]
                .toString()
                .includes(searchSelectArr.value[idx]?.value);
        selectFilterConditions = selectFilterConditions && condition;
      });

      return inputFilterCondition && selectFilterConditions;
    });

    return filtered;
  },
  set: (newVal) => {
    emit('update:input-value', newVal);
  },
});

// 자동 새로고침 시간
let refreshTimeText = ref(dayjs().format('YYYY-MM-DD hh:mm:ss'));

// 자동 새로고침 토글
const isAutoRefresh = ref(true);

// 자동 새로고침 토글 시 호출
const onUpdateAutoRefresh = (val) => {
  console.log('onUpdateAutoRefresh val', val);
  emit('autoRefresh', val);
  // TODO API 호출 후 업데이트 하도록 변경해야 할까?
  refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
};

// 생성 버튼 클릭 시 호출
const onClickAdd = () => {
  console.log('onClickAdd');
  const param = 'param test';
  emit('add', param);
};

// Clear 버튼 클릭 시 호출
const onClickClear = () => {
  console.log('onClickClear');
  const param = 'param test';
  emit('clear', param);
};

// 상세 검색 버튼 클릭 시 호출
const onClickDetailSearch = () => {
  console.log('onClickDetailSearch');
  const param = 'param test';
  emit('detail-search', param);
};

// 새로고침 버튼 클릭 시 호출
const onClickRefresh = () => {
  console.log('onClickRefresh');
  const param = 'param test';
  emit('refresh', param);
};

onMounted(() => {
  // Input 필터 한글 필터링(IME 구성 중 v-model이 업데이트 되지 않으므로 getNativeElement() 사용)
  if (props.inputFilter) {
    const el = keywordRef.value.getNativeElement();
    el.addEventListener('input', (e) => {
      searchInput.value = e.target.value;
    });
  }

  // Selectbox 필터 선택값 배열 셋팅
  times(props.selectFilterArr.length, () => {
    const searchSelect = ref<Selectbox>({
      value: 'All',
      label: 'All',
    });
    searchSelectArr.value.push(searchSelect.value);
  });
});

function checkIsOk(statusVal: string) {
  if (statusVal === 'OK' || statusVal === 'Ready') {
    return true;
  }
  return false;
}

function checkUseProgress(percent: number) {
  if (percent && percent > 0) {
    return true;
  }
  return false;
}
</script>
