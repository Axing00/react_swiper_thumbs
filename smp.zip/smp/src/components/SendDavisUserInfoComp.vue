<template>
  <default-dialog
    ref="dialogRef"
    :title="dialogProps.dialogTitle"
    :close-btn="false"
    :persistent="true"
    @ok="sendUserInfo"
  >
    <template #body>
      <!-- <q-page padding class="page-gray main-container"> -->
      <div class="field-container y-mb40 flex">
        <!-- 아이디 입력란 -->
        <div class="field-area">
          <span class="label">{{ idTitle }}</span>
          <div class="flex items-center">
            <q-input
              v-model="inputID.inputValue"
              class="input-box"
              outlined
              :type="inputID.type"
              :maxlength="50"
              :error="inputID.error"
              :error-message="inputID.errorMessage"
              :disable="inputID.disable"
              :readonly="inputID.readonly"
              @blur="checkIdInput(inputID.inputValue)"
              @update:model-value="(newValue) => checkIdInput(newValue)"
            />
          </div>
        </div>

        <!-- 이름 입력란 -->
        <div class="field-area">
          <span class="label">{{ nameTitle }}</span>
          <div class="flex items-center">
            <q-input
              v-model="inputName.inputValue"
              class="input-box"
              outlined
              :type="inputName.type"
              :disable="inputName.disable"
              :readonly="inputName.readonly"
              :maxlength="50"
              :error="inputName.error"
              :error-message="inputName.errorMessage"
              @blur="checkNameInput(inputName.inputValue)"
              @update:model-value="checkNameInput"
            />
          </div>
        </div>

        <!-- 이메일 입력란 -->
        <div class="field-area">
          <span class="label">{{ emailTitle }}</span>
          <div class="flex items-center">
            <q-input
              v-model="inputEmail.inputValue"
              class="input-box"
              outlined
              :type="inputEmail.type"
              :disable="inputEmail.disable"
              :readonly="inputEmail.readonly"
              :maxlength="50"
              :error="inputEmail.error"
              :error-message="inputEmail.errorMessage"
              @blur="isValidEmail(inputEmail.inputValue)"
              @update:model-value="(newValue) => isValidEmail(newValue)"
            />
          </div>
        </div>

        <!-- 회원 권한 수정 select -->
        <div v-if="useDialogFor === 'userInfoChange'" class="field-area">
          <span class="label">{{ privilegeTitle }}</span>
          <div class="flex items-center">
            <q-select
              v-model="userPrivilegeObj.select.value"
              class="input-box"
              outlined
              :options="userPrivilegeObj.options"
              :select="userPrivilegeObj.select"
              :disable="userPrivilegeObj.disable"
              :error="userPrivilegeObj.error"
              :error-message="userPrivilegeObj.errorMessage"
            />
          </div>
        </div>

        <!-- 회원 비밀번호 초기화 버튼 -->
        <div v-if="popupType === 'infoChangeAdmin'" class="field-area">
          <ButtonComp
            :label="userPassInitialize"
            :icon="'refresh'"
            class="full-width"
            @click="resetPassword"
          />
        </div>

        <div v-if="dialogProps.popupType === 'signup'" class="y-mt20">{{
          '* ' + defaultPasswordMsgTitle
        }}</div>
      </div>
    </template>
  </default-dialog>
</template>

<script lang="ts" setup>
// ↑ lang과 setup 꼭 명시하기
import { useUserManager } from '@/store/admin/userManagerStore';
import dialog from '@/components/dialog';
import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';
import { QDialog } from 'quasar';
import { lang } from '@config/langConfig';
import notify from '@/config/notifyConfig';
import { ref, onMounted } from 'vue';
import { useAuthStore } from '@/store/app/useAuthStore';
import ButtonComp from './ButtonComp.vue';
import cacheHelper, {
  cacheType,
  sessionUserInfoType,
} from '@/utils/cacheHelper';

const dialogProps = defineProps({
  popupType: { type: String, required: false },
  dialogTitle: { type: String, required: false },
  changeUserInfo: { type: Object, required: false },
});

const emit = defineEmits(['ok', 'cancel']);

const authStore = useAuthStore();
const userManagerStore = useUserManager();

const nameTitle = ref<string>(lang('davisMsg.name'));
const idTitle = ref<string>(lang('davisMsg.userId'));
const emailTitle = ref<string>(lang('davisMsg.email'));
const defaultPasswordMsgTitle = ref<string>(
  lang('davisMsg.login.info.defaultPasswordMsg')
);
const privilegeTitle = ref<string>(lang('davisMsg.userPrivilege'));
const userPassInitialize = ref<string>(
  lang('davisMsg.userInfoChange.userPassInitialize')
);

const required = ref<string>(lang('common.validation.required'));
const overInput = ref<string>(lang('common.validation.lessThanFiftyWords'));
const one = ref<number>(1);
const fifty = ref<number>(50);
const dialogRef = ref(QDialog);

// Input 인터페이스
interface Input {
  inputValue: string; // value
  disable?: boolean; // 사용 가능 여부
  errorMessage: string; // 에러발생시 메세지
  placeholder?: string; //placeholder
  error?: boolean; // 에러 여부
  theme?: 'basic'; // 테마
  readonly?: boolean; // 읽기 전용 여부
  maxlength?: number; // 최대 길이 지정
  type: 'text' | 'textarea' | 'search' | 'password'; // text, textarea, search,  타입 가능 (이후 추가 필요시 내용 변경 필요)
}

// Select 객체 interface
interface SelectBox {
  options: {
    label: number | string;
    value: string | number | null;
    description?: string | null;
  }[];
  select: {
    label: string | number | null;
    value: any;
    description?: string | null;
  };
  error: boolean;
  errorMessage: string;
  disable: boolean;
}

// 유저 생성 Data 객체 Type 지정
type createUserInfoObj = {
  login_id: string;
  pwd_1: string;
  pwd_2: string;
  email: string;
  name: string;
};

// 유저 권한 select box
const userPrivilegeObj = ref<SelectBox>({
  options: [
    {
      label: 'Guest',
      value: 0,
      description: '권한 0',
    },
    {
      label: 'Admin',
      value: 1,
      description: '권한 1',
    },
    {
      label: 'Setup Admin',
      value: 2,
      description: '권한 2',
    },
  ],
  select: {
    label: null,
    value: null,
    description: null,
  },
  error: false,
  errorMessage: '',
  disable: false,
});

// 회원가입 / 기존 회원 정보 변경
let useDialogFor =
  dialogProps.dialogTitle === lang('davisMsg.userInfoChange.infoChangeTitle')
    ? 'userInfoChange'
    : 'userSignUp';

// input 아이디 객체
let inputID = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
});

// input 이름 객체
let inputName = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
});

// input 이메일 객체
let inputEmail = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
});

// 회원 가입 전송 정보
let createUserInfo: createUserInfoObj = {
  login_id: '',
  pwd_1: '',
  pwd_2: '',
  email: '',
  name: '',
};

function getUserInfo() {
  // 회원 정보 변경 dialog 일 때, 회원 정보 가져오기

  if (useDialogFor === 'userInfoChange') {
    if (dialogProps.changeUserInfo !== undefined) {
      inputID.value.inputValue = dialogProps.changeUserInfo.changeUserId;
      inputEmail.value.inputValue = dialogProps.changeUserInfo.changeUserEmail;
      inputName.value.inputValue = dialogProps.changeUserInfo.changeUserName;
      userPrivilegeObj.value.select.value =
        dialogProps.changeUserInfo.changeUserPriv;
    }

    inputID.value.readonly = true;
  }
}

async function sendUserInfo() {
  checkIdInput(inputID.value.inputValue);
  checkNameInput();
  isValidEmail(inputEmail.value.inputValue);

  if (
    inputID.value.error === false &&
    inputName.value.error === false &&
    inputEmail.value.error === false
  ) {
    if (useDialogFor === 'userSignUp') {
      // 회원 가입
      try {
        createUserInfo.login_id = inputID.value.inputValue;
        createUserInfo.pwd_1 = inputID.value.inputValue;
        createUserInfo.pwd_2 = inputID.value.inputValue;
        createUserInfo.email = inputEmail.value.inputValue;
        createUserInfo.name = inputName.value.inputValue;

        const UserCreateResult = await userManagerStore.davisCreateUser(
          createUserInfo
        );

        if (UserCreateResult == 'Created') {
          dialog.open({
            component: ConfirmDialog,

            componentProps: {
              message: lang('davisMsg.login.info.signUpOkMsg'),
              persistent: false,
              cancelBtn: false,
              position: 'top',
            },
          });

          dialogRef.value.hide();
        }
      } catch (err: unknown) {
        // console.error(err);
      }
    } else if (useDialogFor === 'userInfoChange') {
      // 회원 정보 변경
      let changeUserPriv = userPrivilegeObj.value.select.value;
      let transPriv =
        changeUserPriv == 0
          ? 'Guest'
          : changeUserPriv == 1
          ? 'Admin'
          : changeUserPriv == 2
          ? 'Setup Admin'
          : userPrivilegeObj.value.select.value.label;

      if (dialogProps.changeUserInfo !== undefined) {
        if (
          dialogProps.changeUserInfo?.changeUserPriv !==
          userPrivilegeObj.value.select.value
        ) {
          // 회원 권한 정보 수정할 때 select 값이 변할 경우 object 형태로 받아오는 문제
          changeUserPriv = JSON.stringify(changeUserPriv.value);
        }

        // 변경되는 회원 정보 없는 경우, 권한 DB number -> string 변환 && select 객체의 label, value 변환 문제 때문에 두가지 분기로 나눠 적용
        if (
          // 변경되는 회원 정보가 없을 경우 1
          dialogProps.changeUserInfo.changeUserEmail ==
            inputEmail.value.inputValue &&
          dialogProps.changeUserInfo.changeUserName ==
            inputName.value.inputValue &&
          dialogProps.changeUserInfo.changeUserPriv == changeUserPriv
        ) {
          dialog.open({
            component: ConfirmDialog,

            componentProps: {
              message: lang('davisMsg.userInfoChange.noChangedInfo'), // 변경된 회원정보가 없습니다.
              persistent: false,
              cancelBtn: false,
            },
          });
        } else if (
          // 변경되는 회원 정보가 없을 경우 2
          dialogProps.changeUserInfo.changeUserEmail ==
            inputEmail.value.inputValue &&
          dialogProps.changeUserInfo.changeUserName ==
            inputName.value.inputValue &&
          dialogProps.changeUserInfo.changeUserPriv == transPriv
        ) {
          dialog.open({
            component: ConfirmDialog,

            componentProps: {
              message: lang('davisMsg.userInfoChange.noChangedInfo'), // 변경된 회원정보가 없습니다.
              persistent: false,
              cancelBtn: false,
            },
          });
        } else if (dialogProps.changeUserInfo !== undefined) {
          // 회원 정보 변경 후 전송
          // 권한 별 등급 적용은 추후 DB로
          if (changeUserPriv == 'Guest') {
            changeUserPriv = 0;
          } else if (changeUserPriv == 'Admin') {
            changeUserPriv = 1;
          } else if (changeUserPriv == 'Setup Admin') {
            changeUserPriv = 2;
          }

          const changeDavisUserInfoObj = {
            id: dialogProps.changeUserInfo.changeUserNo,
            email: inputEmail.value.inputValue,
            name: inputName.value.inputValue,
            privilege: changeUserPriv,
          };
          try {
            // 네트워크 user 전체 목록 보여지는 문제 다시 확인 필요
            const result = await userManagerStore.changeDavisUserInfo(
              changeDavisUserInfoObj
            );

            if (result === 'OK') {
              dialog.open({
                component: ConfirmDialog,

                componentProps: {
                  title: lang('davisMsg.userInfoChange.infoChangeTitle'),
                  message:
                    `${inputID.value.inputValue}` +
                    lang('davisMsg.userInfoChange.infoChangeOk'),
                  persistent: false,
                  cancelBtn: false,
                  position: 'top',
                },
              });

              dialogRef.value.hide();

              // admin이 회원 정보를 변경하는 경우, 회원 전체 정보 업데이트
              if (dialogProps.popupType === 'infoChangeAdmin') {
                // await userManagerStore.getDavisUserList();
                if (
                  dialogProps.changeUserInfo.changeUserId == authStore.userID
                ) {
                  cacheHelper.setCache(
                    cacheType.USER_NAME,
                    inputName.value.inputValue
                  );
                }
              }

              // user 개인 정보 직접 변경일 경우 세션 값 변경
              if (dialogProps.popupType === 'infoChangeInd') {
                cacheHelper.removeCache(cacheType.USER_NAME);

                cacheHelper.setCache(
                  cacheType.USER_NAME,
                  inputName.value.inputValue
                );
              }

              authStore.userID = cacheHelper.getCache(cacheType.LOGIN_USER_ID);
              authStore.userName = cacheHelper.getCache(cacheType.USER_NAME);

              userManagerStore.davisUserList.map((a1, a2) => {
                if (dialogProps.changeUserInfo !== undefined) {
                  if (dialogProps.changeUserInfo.changeUserNo == a1.id) {
                    // 권한 별 등급 적용은 추후 DB로
                    if (changeUserPriv == 0) {
                      changeUserPriv = 'Guest';
                    } else if (changeUserPriv == 1) {
                      changeUserPriv = 'Admin';
                    } else if (changeUserPriv == 2) {
                      changeUserPriv = 'Setup Admin';
                    }

                    userManagerStore.davisUserList[a2].name =
                      inputName.value.inputValue;
                    userManagerStore.davisUserList[a2].email =
                      inputEmail.value.inputValue;
                    userManagerStore.davisUserList[a2].privilege =
                      changeUserPriv;
                  }
                }
              });

              // emit('ok');
            }
          } catch (err: unknown) {
            // console.log(err);
          }
        }
      }
    }
  }
}

// name input validation 체크
function checkNameInput() {
  const regex1 = new RegExp(`(?=.*[~\`!@#$%\\^&*()-+=]{1,50}).*[\\S]`);

  if (inputName.value.inputValue.length < one.value) {
    inputName.value.error = true;
    inputName.value.errorMessage = required.value;
  } else if (inputName.value.inputValue.length > fifty.value) {
    inputName.value.error = true;
    inputName.value.errorMessage = overInput.value;
  } else if (inputName.value.inputValue.indexOf(' ') !== -1) {
    inputName.value.error = true;
    inputName.value.errorMessage = lang(
      'davisMsg.userInfoChange.noSpaceNameChange'
    );
  } else if (regex1.test(inputName.value.inputValue)) {
    inputName.value.error = true;
    inputName.value.errorMessage = lang(
      'davisMsg.userInfoChange.noSpecialSymbolName'
    );
  } else {
    inputName.value.error = false;
  }
  return inputName.value.error;
}

// id input validation 체크
function checkIdInput(input) {
  if (input.length < one.value) {
    inputID.value.error = true;
    inputID.value.errorMessage = required.value;
  } else if (inputID.value.inputValue.indexOf(' ') !== -1) {
    inputID.value.error = true;
    inputID.value.errorMessage = lang(
      'davisMsg.userInfoChange.noSpaceIdChange'
    );
  } else if (input.length > fifty.value) {
    inputID.value.error = true;
    inputID.value.errorMessage = overInput.value;
  } else if (useDialogFor === 'userSignUp') {
    const regex1 = new RegExp(`(?=.*[~\`!@#$%\\^&*()-+=]{1,50}).*[\\S]`);
    const regex2 = new RegExp(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/);

    if (regex1.test(inputID.value.inputValue)) {
      inputID.value.error = true;
      inputID.value.errorMessage = lang(
        'davisMsg.userInfoChange.noSpecialSymbolId'
      );
    } else if (regex2.test(inputID.value.inputValue)) {
      inputID.value.error = true;
      inputID.value.errorMessage = lang('davisMsg.userInfoChange.noKoreanId');
    } else {
      inputID.value.error = false;
      inputID.value.errorMessage = '';
    }
  } else {
    inputID.value.error = false;
  }
  return inputID.value.error;
}

// email 형식 체크
function isValidEmail(input) {
  const emailPattern =
    /^(?=[a-zA-Z0-9@._%+-]{6,254}$)[a-zA-Z0-9._%+-]{1,64}@(?:[a-zA-Z0-9-]{1,63}\.){1,8}[a-zA-Z]{2,63}$/;

  if (input.length < one.value) {
    inputEmail.value.error = true;
    inputEmail.value.errorMessage = required.value;
  } else if (checkDuplicateUserID(input)) {
    inputEmail.value.error = true;
    inputEmail.value.errorMessage = lang('davisMsg.login.duplicateUserID');
  } else if (emailPattern.test(input)) {
    inputEmail.value.error = false;
  } else {
    inputEmail.value.error = true;
    inputEmail.value.errorMessage = lang('davisMsg.login.error.wrongID');
  }
  return inputEmail.value.error;
}

// 유저 store에서 유저 정보 가져와서 중복 체크 ( 사용자 정보를 admin이 등록하는 경우에 사용 )
function checkDuplicateUserID(input) {
  let error = false;
  userManagerStore.userList.forEach((item) => {
    if (item.userId === input) {
      error = true;
      return error;
    }
  });

  return error;
}

// 회원 정보 수정 -> 회원 비밀번호 초기화 버튼 클릭
const resetPassword = async () => {
  try {
    const resetPass = window.btoa(inputID.value.inputValue);

    const resetPassResult = await authStore.davisChangePassword(
      inputID.value.inputValue,
      resetPass,
      resetPass
    );

    if (resetPassResult === 'OK') {
      dialog.open({
        component: ConfirmDialog,

        componentProps: {
          title: lang('davisMsg.login.passwordChange'),
          message:
            `${inputID.value.inputValue}` +
            lang('davisMsg.passwordChange.userPwdChangeOk'),
          persistent: false,
          cancelBtn: false,
          position: 'top',
        },
      });

      dialogRef.value.hide();
    }
  } catch (e) {
    // console.error(e);
  }
};

onMounted(() => {
  getUserInfo();

  // User 개인이 회원 정보 변경 하는 경우
  if (dialogProps.popupType === 'infoChangeInd') {
    // inputPrivilege.value.disable = true;
    userPrivilegeObj.value.disable = true;
  }
});
</script>
