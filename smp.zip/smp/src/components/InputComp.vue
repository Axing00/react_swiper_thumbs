<template>
  <q-input
    ref="keywordRef"
    v-model="inputValue"
    square
    dense
    :clearable="props.type === 'search'"
    :placeholder="props.placeholder"
    :type="props.type"
    :outlined="isOutline"
    :class="classList"
    :error-message="props.errorMessage"
    :error="props.error"
    :hide-bottom-space="true"
    no-error-icon
    lazy-rules
    @change="checkValidation"
    @blur="checkValidation"
  />
</template>

<script lang="ts" setup>
import { ref, computed, onMounted } from 'vue';

// Input 인터페이스
export interface Input {
  inputValue: string; // value
  disable?: boolean; // 사용 가능 여부
  errorMessage?: string; // 에러발생시 메세지
  placeholder?: string; //placeholder
  error?: boolean; // 에러 여부
  theme?: 'basic'; // 테마
  readonly?: boolean; // 읽기 전용 여부
  maxlength?: number; // 최대 길이 지정
  type: 'text' | 'textarea' | 'search' | 'password'; // text, textarea, search,  타입 가능 (이후 추가 필요시 내용 변경 필요)
}

//emit
const emit = defineEmits(['update:inputValue', 'update:check']);

// props 기본값 설정
// 인터페이스를 다른 파일에 정의하고 불러와 사용하는 방법은 지원하지 않습니다.
const props = withDefaults(defineProps<Input>(), {
  inputValue: '',
  disable: false,
  errorMessage: '오류입니다.',
  placeholder: '',
  error: false,
  theme: 'basic',
  readonly: false,
  maxlength: undefined,
  type: 'text',
});

const inputValue = computed({
  get() {
    return props.inputValue;
  },
  set(val) {
    // console.log('inputValue val', val);
    val = val === null ? '' : val;
    emit('update:inputValue', val);
  },
});

// 한글 필터링(IME 구성 중 v-model이 업데이트 되지 않으므로 getNativeElement() 사용)
const keywordRef = ref();
onMounted(() => {
  const el = keywordRef.value.getNativeElement();
  el.addEventListener('input', (e) => {
    inputValue.value = e.target.value;
  });
});

// 유효성 체크
function checkValidation() {
  emit('update:check');
  changeClassList();
}

// 테마 확인
let classList = ref<Array<string>>();
let isOutline = ref<boolean>(true);
function checkTheme() {
  // text인 경우
  if (props.type === 'text') {
    switch (props.theme) {
      default: // basic 테마의 경우
        classList.value = ['input-basic'];
        break;
    }
    // textarea인 경우
  } else if (props.type === 'textarea') {
    switch (props.theme) {
      default: // basic 테마의 경우
        classList.value = ['input-textarea-basic'];
        break;
    }
  } else if (props.type === 'search') {
    switch (props.theme) {
      default: // basic 테마의 경우
        isOutline.value = false;
        classList.value = ['input-search-basic'];
        break;
    }
  }
}
checkTheme();

function changeClassList() {
  if (props.error === false) {
    const index = classList.value?.indexOf('input-success');
    if (index === -1) {
      classList.value?.push('input-success');
    }
  } else {
    classList.value = classList.value?.filter((el) => {
      return el !== 'input-success';
    });
  }
}
</script>
