<template>
  <q-card flat bordered square :class="classList">
    <!-- 카드 타이틀 부분 -->
    <q-card-section v-if="props.theme === 'basic'" class="card-title">
      <div class="row">
        <div class="card-title-name">
          <p>{{ props.title }}</p>
        </div>
        <!-- 설명 아이콘 버튼 -->
        <div v-if="useConfigIcon">
          <q-btn
            round
            flat
            dense
            icon="info"
            class="card-title-btn"
            @click="clickTooltip = !clickTooltip"
          />
          <!-- 설명 카드 툴팁 -->
          <q-card
            v-show="clickTooltip"
            ref="target"
            flat
            bordered
            class="card-title-tooltip"
          >
            <q-card-section>
              <div class="tooltip-top">{{ props.tooltipTitle }}</div>
            </q-card-section>

            <q-card-section horizontal class="tooltip-body">
              <q-icon name="info" />
              <div class="tooltip-text">
                <p>{{ props.configText }}</p>
              </div>
            </q-card-section>
          </q-card>
        </div>
      </div>
    </q-card-section>

    <!-- 카드 body 부분 -->
    <slot name="body" />
    <q-inner-loading
      size="30px"
      :showing="visible"
      label="loading"
      label-style="font-size: 1.1em"
    />
  </q-card>
</template>

<script lang="ts" setup>
import { ref, onMounted } from 'vue';
import { onClickOutside } from '@vueuse/core';

// 툴팁 외부 클릭 여부 판단하여 닫기
const target = ref(null);

onClickOutside(target, (event) => {
  clickTooltip.value = false;
});

const props = defineProps({
  // 카드 타이틀
  title: {
    type: String,
    default: '카드 타이틀',
    required: false,
  },
  // 키드 테마
  theme: {
    type: String,
    default: 'basic',
    required: false,
  },
  // 설명 아이콘 사용 여부
  useConfigIcon: {
    type: Boolean,
    default: true,
    required: false,
  },
  // 툴팁 타이틀
  tooltipTitle: {
    type: String,
    default: '툴팁의 타이틀란.',
    required: false,
  },
  // 카드 설명 text
  configText: {
    type: String,
    default: '이 곳은 카드에 대한 설명란입니다.',
    required: false,
  },
  // 로딩바 사용여부
  useLoading: {
    type: Boolean,
    default: false,
    required: false,
  },
});

// 툴팁 보이기 버튼 클릭시
let clickTooltip = ref<boolean>(false);

// 테마에 따라 class 변경
let classList = ref<Array<string>>();

function checkTheme() {
  switch (props.theme) {
    case 'empty':
      classList.value = ['card-empty', 'col'];
      break;

    default:
      classList.value = ['card-basic', 'col'];
      break;
  }
}
checkTheme();

// inner 로딩바
let visible = ref<boolean>(props.useLoading);

onMounted(() => {
  setTimeout(() => {
    visible.value = false;
  }, 1000);
});
</script>
