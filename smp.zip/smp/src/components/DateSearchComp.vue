<template>
  <div class="no-wrap q-pa-md drop-basic detail-search-container">
    <div class="title">
      <span>{{ props.periodTitle }}</span>
    </div>
    <div class="period-area flex" style="justify-content: space-around">
      <div class="left-area">
        <div class="title">Start time</div>
        <q-input v-model="startDate" filled readonly style="width: 240px">
          <!-- event -->
          <template #prepend>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-date
                  v-model="startDate"
                  mask="YYYY-MM-DD HH:mm:ss"
                  @update:model-value="emitReportTime()"
                >
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
          <!-- time -->
          <template #append>
            <q-icon name="access_time" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-time
                  v-model="startDate"
                  mask="YYYY-MM-DD HH:mm:00"
                  format24h
                  @update:model-value="emitReportTime()"
                >
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-time>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
      <div class="right-area">
        <div class="title">End time</div>
        <q-input v-model="endDate" filled readonly style="width: 240px">
          <!-- event -->
          <template #prepend>
            <q-icon name="event" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-date
                  v-model="endDate"
                  mask="YYYY-MM-DD HH:mm:ss"
                  @update:model-value="emitReportTime()"
                >
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
          <!-- time -->
          <template #append>
            <q-icon name="access_time" class="cursor-pointer">
              <q-popup-proxy
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-time
                  v-model="endDate"
                  mask="YYYY-MM-DD HH:mm:00"
                  format24h
                  @update:model-value="emitReportTime()"
                >
                  <div class="row items-center justify-end">
                    <q-btn v-close-popup label="Close" color="primary" flat />
                  </div>
                </q-time>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref, onUnmounted, onMounted } from 'vue';

// interface editDataVO {
//   start: { type: string; default: '--' };
//   end: { type: string; default: '--' };
// }

const props = defineProps({
  periodTitle: { type: String, default: '' },
  editDateData: { type: Object },
});

const emits = defineEmits(['getScheduleTime', 'getEndTime']);

const startDate = ref<string>('--');
const endDate = ref<string>('--');

const scheduleTime = ref({
  scheduleStart: startDate,
  scheduleEnd: endDate,
});

const storageTime = ref({
  storageStart: startDate,
  storageEnd: endDate,
});

// Emit Time
const emitReportTime = () => {
  if (props.periodTitle === 'Schedule Time') {
    emits('getScheduleTime', scheduleTime.value, 'schedule');
  } else if (props.periodTitle === 'Storage Time') {
    emits('getScheduleTime', storageTime.value, 'storage');
  }
};

onMounted(() => {
  if (props.editDateData !== undefined) {
    if (props.periodTitle === 'Schedule Time') {
      const getReportStart = props.editDateData.scheduleStart;
      const getReportEnd = props.editDateData.scheduleEnd;

      if (getReportStart) {
        startDate.value = getReportStart;
      }
      if (getReportEnd) {
        endDate.value = getReportEnd;
      }
    } else if (props.periodTitle === 'Storage Time') {
      const getStorageStart = props.editDateData.storageStart;
      const getStorageEnd = props.editDateData.storageEnd;

      if (getStorageStart) {
        startDate.value = getStorageStart;
      }
      if (getStorageEnd) {
        endDate.value = getStorageEnd;
      }
    }
  }
});

// onUnmounted(() => {
//   // 리포트 등록 창 닫을 때 기간 초기화
//   scheduleTime.value = {
//     start: '--',
//     end: '--',
//   };
//   emits('getScheduleTime', scheduleTime.value);
// });
</script>
