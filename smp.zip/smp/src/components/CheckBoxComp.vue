<template>
  <q-checkbox
    v-model="isChecked"
    flat
    dense
    :label="props.label"
    :disable="props.disable"
    @chagne="emit('change:checked', isChecked)"
  />
</template>

<script lang="ts" setup>
import { ref } from 'vue';

const emit = defineEmits(['change:checked']);

const props = defineProps({
  label: {
    type: String,
    default: '라벨명',
    required: false,
  },
  disable: {
    type: Boolean,
    default: false,
    required: false,
  },
});
let isChecked = ref<boolean>(false);
</script>
