<template>
  <q-dialog ref="dialogRef" :square="true" @hide="onDialogHide">
    <q-card class="q-dialog-plugin">
      <!-- 타이틀 부분 -->
      <q-card-section class="modal-title-basic">
        <div class="row">
          <div class="modal-title-name">
            <p>{{ props.title }}</p>
          </div>
          <q-space />
          <!-- <q-btn v-close-popup dense icon="close" class="close" flat /> -->
        </div>
      </q-card-section>

      <!-- body 부분 (확인창 아닌 경우) -->
      <slot v-if="props.theme !== 'confirm'" name="body" />

      <!-- body 부분 (확인창인 경우) -->
      <q-card v-if="props.theme === 'confirm'" class="modal-body-basic">
        <div>
          {{ props.confirmMessage }}
        </div>
      </q-card>

      <!-- buttons (버튼 리스트 있을 때에만)-->
      <q-card-actions v-if="footerButtons.length > 0" align="right">
        <button-comp
          v-for="btn in footerButtons"
          :key="btn.theme"
          :label="btn.label"
          :disable="btn.disable"
          :icon="btn.icon"
          :theme="btn.theme"
          @click:clicked="clickedButton(btn.label)"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup lang="ts">
import { ref, computed, PropType } from 'vue';
import { useDialogPluginComponent } from 'quasar';
import ButtonComp from '@components/ButtonComp.vue';

export interface FooterButton {
  label?: string; // 버튼 라벨
  theme?: 'basic' | 'pink' | 'white'; // 버튼 테마
  icon?: string; // icon명
  disable?: boolean; // disable 여부
}

export interface Modal {
  title: string;
  theme?: string;
  iconType?: string;
  moveable?: string;
  footerBtn?: Array<FooterButton>;
}

const { dialogRef, onDialogHide, onDialogOK, onDialogCancel } =
  useDialogPluginComponent();

// other methods that we used in our vue html template;
// these are part of our example (so not required)
function onOKClick() {
  // on OK, it is REQUIRED to
  // call onDialogOK (with optional payload)
  onDialogOK();
  // or with payload: onDialogOK({ ... })
  // ...and it will also hide the dialog automatically
}

// we can passthrough onDialogCancel directly
function onCancelClick() {
  onDialogCancel();
}

const props = defineProps({
  // 타이틀
  title: {
    type: String,
    default: '팝업',
    required: false,
  },
  // 팝업 테마
  theme: {
    type: String,
    default: 'basic',
    required: false,
  },
  // 타이틀 아이콘명
  iconType: {
    type: String,
    default: 'info',
    required: false,
  },
  // 팝업 이동
  moveable: {
    type: Boolean,
    default: true,
    required: false,
  },
  // Footer 버튼 리스트
  footerBtn: {
    type: Array as PropType<Array<FooterButton>>,
    default: () => [],
    required: false,
  },
  // 확인 알림창일 때의 메세지
  confirmMessage: {
    type: String,
    default: '확인하시겠습니까?',
    required: false,
  },
});

const emit = defineEmits([...useDialogPluginComponent.emits]);

let footerButtons = ref<FooterButton[]>();

if (props.theme === 'confirm') {
  footerButtons.value = [
    {
      label: '확인',
      theme: 'pink',
    },
    {
      label: '취소',
    },
  ];
} else {
  footerButtons = computed({
    get() {
      return props.footerBtn;
    },
    set() {
      return;
    },
  });
}

function clickedButton(buttonLabel: string | undefined) {
  if (buttonLabel === '취소') {
    onCancelClick();
  } else {
    emit('ok', buttonLabel);
  }
}
</script>
