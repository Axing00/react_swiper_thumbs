<template>
  <table>
    <colgroup>
      <col class="col-first" />
      <col />
    </colgroup>
    <tr v-for="row in dataRows" :key="row.label">
      <th>{{ $t(row.label) }}</th>
      <td>{{ row.value }}</td>
    </tr>
  </table>
</template>

<script lang="ts" setup>
import { PropType } from 'vue';

export interface BaseTableDataRow {
  label: string;
  value: unknown;
}

defineProps({
  dataRows: {
    type: Array as PropType<BaseTableDataRow[]>,
    required: true,
    default: () => [],
  },
});
</script>
