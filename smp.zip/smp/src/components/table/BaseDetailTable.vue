<template>
  <div class="content-wrap">
    <div class="title-wrap">
      <h3>{{ $t(title) }}</h3>
    </div>
    <base-table :data-rows="dataRows" />
  </div>
</template>

<script lang="ts" setup>
import { PropType } from 'vue';
import { BaseTableDataRow } from './BaseTable.vue';

defineProps({
  title: {
    type: String,
    required: true,
    default: () => '',
  },
  dataRows: {
    type: Array as PropType<BaseTableDataRow[]>,
    required: true,
    default: () => [],
  },
});
</script>
