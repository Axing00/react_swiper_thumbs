<template>
  <div class="bread-crumbs-container">
    <q-breadcrumbs class="bread-font-m detail-title-area">
      <template #separator>
        <q-icon size="16px" name="chevron_right" class="bread-crumb" />
      </template>
      <q-breadcrumbs-el :label="props.title" class="title" />
    </q-breadcrumbs>
  </div>
</template>
<script setup>
// import { defineProps } from 'vue';
// export default {
//   name: 'BreadBrumbs',
//   props: {
//     title: {
//         title: String,
//         default: "title11"
//     }
//   }
// }
const props = defineProps({
  title: String,
});
</script>
