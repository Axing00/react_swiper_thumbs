<template>
  <default-dialog
    ref="dialogRef"
    :title="dialogProps.dialogTitle"
    :close-btn="false"
    :persistent="true"
    @ok="sendSlaInfo"
  >
    <template #body>
      <div class="sla-edit-container y-mb40">
        <!-- Critical 입력란 -->
        <div class="field-area">
          <span class="label">{{ criticalTitle }}</span>
          <div class="flex items-center">
            <q-input
              v-model="inputCritical.inputValue"
              class="input-box"
              outlined
              :type="inputCritical.type"
              :error="inputCritical.error"
              :error-message="inputCritical.errorMessage"
              autofocus
              :maxlength="inputCritical.maxlength"
              @update:model-value="restrictCriticalVal()"
            />
          </div>
        </div>

        <!-- Major 입력란 -->
        <div class="field-area">
          <span class="label">{{ majorTitle }}</span>
          <div class="y-w80">
            <q-input
              v-model="inputMajor.inputValue"
              class="input-box"
              outlined
              :type="inputMajor.type"
              :error="inputMajor.error"
              :error-message="inputMajor.errorMessage"
              :maxlength="inputMajor.maxlength"
              @update:model-value="restrictMajorVal()"
            />
          </div>
        </div>

        <!-- Minor 입력란 -->
        <div class="field-area">
          <span class="label">{{ minorTitle }}</span>
          <div class="y-w80">
            <q-input
              v-model="inputMinor.inputValue"
              class="input-box"
              outlined
              :type="inputMinor.type"
              :error="inputMinor.error"
              :error-message="inputMinor.errorMessage"
              :maxlength="inputMinor.maxlength"
              @update:model-value="restrictMinorVal()"
            />
          </div>
        </div>

        <!-- ON / OFF 변경 toggle -->
        <div class="field-area">
          <span class="label">{{ onOffTitle }}</span>
          <div class="q-layout-padding">
            <q-toggle v-model="slaOnOffVal" color="light-blue-10" />
          </div>
        </div>
      </div>
    </template>
  </default-dialog>
</template>

<script lang="ts" setup>
// ↑ lang과 setup 꼭 명시하기
import { ref, onMounted } from 'vue';
import dialog from '@/components/dialog';
import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';
import { QDialog } from 'quasar';
import { lang } from '@config/langConfig';
import notify from '@/config/notifyConfig';
import { httpHelperV2 } from '@/utils/httpHelperV2';

const dialogProps = defineProps({
  dialogTitle: { type: String, default: '' },
  selectedSlaInfo: {
    type: Object,
    default: () => {
      return {};
    },
  },
});

const criticalTitle = 'Critical';
const majorTitle = 'Major';
const minorTitle = 'Minor';
const onOffTitle = 'ON / OFF';
const required = ref<string>(lang('common.validation.required'));
const needOverInput = ref<string>(lang('davisMsg.sla.editInfo.initNeed'));
const zero = ref<number>(0);
const dialogRef = ref(QDialog);
const emit = defineEmits(['ok', 'cancel']);

// 입력 자릿수 제한
const slaSubject: string[] = dialogProps.dialogTitle.split('(');
const currSlaSubject: string = slaSubject[1].slice(0, -1);

let slaOnOffVal = ref<boolean>(false);

// Input 인터페이스
interface Input {
  inputValue: number | string; // value
  disable?: boolean; // 사용 가능 여부
  errorMessage: string; // 에러발생시 메세지
  placeholder?: string; //placeholder
  error?: boolean; // 에러 여부
  theme?: 'basic'; // 테마
  readonly?: boolean; // 읽기 전용 여부
  maxlength?: number; // 최대 길이 지정
  type: 'number' | 'text' | 'textarea' | 'search' | 'password'; // text, textarea, search,  타입 가능 (이후 추가 필요시 내용 변경 필요)
}

interface sendSlaInfoVO {
  statusText?: string;
  id: number;
  critical: number;
  major: number;
  minor: number;
  display_flag: number;
}

// Critical input 객체
let inputCritical = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
  maxlength: 3,
});

// Critical input 객체
let inputMajor = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
  maxlength: 3,
});

// Critical input 객체
let inputMinor = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  theme: 'basic',
  readonly: false,
  disable: false,
  type: 'text',
  maxlength: 3,
});

// Sla 정보 가져오기
function setSlaInfo() {
  if (dialogProps.selectedSlaInfo !== undefined) {
    inputCritical.value.inputValue = dialogProps.selectedSlaInfo.slaCritical;
    inputMajor.value.inputValue = dialogProps.selectedSlaInfo.slaMajor;
    inputMinor.value.inputValue = dialogProps.selectedSlaInfo.slaMinor;

    dialogProps.selectedSlaInfo.slaOnOff === 0
      ? (slaOnOffVal.value = false)
      : (slaOnOffVal.value = true);
  }
}

// Critical 숫자 자릿 수 제한
const restrictCriticalVal = () => {
  if (typeof inputCritical.value.inputValue === 'string') {
    inputCritical.value.inputValue = inputCritical.value.inputValue.replace(
      /[^0-9]/g,
      ''
    );
  }

  if (currSlaSubject === '%') {
    if (inputCritical.value.inputValue > 130) {
      inputCritical.value.inputValue = 130;
    }
  } else if (currSlaSubject === 'bytes') {
    inputCritical.value.maxlength = 10;
  } else if (currSlaSubject === 'packets') {
    inputCritical.value.maxlength = 5;
  } else if (currSlaSubject === 'counts') {
    inputCritical.value.maxlength = 4;
  }
};

// Major 숫자 자릿수 제한
const restrictMajorVal = () => {
  if (typeof inputMajor.value.inputValue === 'string') {
    inputMajor.value.inputValue = inputMajor.value.inputValue.replace(
      /[^0-9]/g,
      ''
    );
  }

  if (currSlaSubject === '%') {
    if (inputMajor.value.inputValue > 130) {
      inputMajor.value.inputValue = 130;
    }
  } else if (currSlaSubject === 'bytes') {
    inputMajor.value.maxlength = 10;
  } else if (currSlaSubject === 'packets') {
    inputMajor.value.maxlength = 5;
  } else if (currSlaSubject === 'counts') {
    inputMajor.value.maxlength = 4;
  }
};

// Minor 숫자 자릿수 제한
const restrictMinorVal = () => {
  if (typeof inputMinor.value.inputValue === 'string') {
    inputMinor.value.inputValue = inputMinor.value.inputValue.replace(
      /[^0-9]/g,
      ''
    );
  }

  if (currSlaSubject === '%') {
    if (inputMinor.value.inputValue > 130) {
      inputMinor.value.inputValue = 130;
    }
  } else if (currSlaSubject === 'bytes') {
    inputMinor.value.maxlength = 10;
  } else if (currSlaSubject === 'packets') {
    inputMinor.value.maxlength = 5;
  } else if (currSlaSubject === 'counts') {
    inputMinor.value.maxlength = 4;
  }
};

async function sendSlaInfo(): Promise<void> {
  inputCritical.value.inputValue = Number(inputCritical.value.inputValue);
  inputMajor.value.inputValue = Number(inputMajor.value.inputValue);
  inputMinor.value.inputValue = Number(inputMinor.value.inputValue);
  inputMajor.value.error = false;
  inputCritical.value.error = false;
  inputMinor.value.error = false;

  if (inputCritical.value.inputValue < zero.value) {
    inputCritical.value.error = true;

    inputCritical.value.errorMessage = needOverInput.value;
  } else if (inputMajor.value.inputValue < zero.value) {
    inputMajor.value.error = true;
    inputMajor.value.errorMessage = needOverInput.value;
  } else if (inputMinor.value.inputValue < zero.value) {
    inputMinor.value.error = true;
    inputMinor.value.errorMessage = needOverInput.value;
  } else if (inputCritical.value.inputValue <= inputMajor.value.inputValue) {
    inputCritical.value.error = true;

    // 다국어 설정 필요
    inputCritical.value.errorMessage =
      'Critical 값은 Major 값과 같거나 작을 수 없습니다.';
  } else if (inputMajor.value.inputValue <= inputMinor.value.inputValue) {
    inputMajor.value.error = true;

    // 다국어 설정 필요
    inputMajor.value.errorMessage =
      'Major 값은 Minor 값과 같거나 작을 수 없습니다.';
  } else {
    inputMajor.value.error = false;
    inputCritical.value.error = false;
    inputMinor.value.error = false;
  }

  if (
    inputCritical.value.error === false &&
    inputMajor.value.error === false &&
    inputMinor.value.error === false
  ) {
    const sendChangedSlaInfo = {
      id: dialogProps.selectedSlaInfo.slaId,
      critical: inputCritical.value.inputValue,
      major: inputMajor.value.inputValue,
      minor: inputMinor.value.inputValue,
      display_flag: slaOnOffVal.value === true ? 1 : 0,
    };

    if (
      sendChangedSlaInfo.critical == dialogProps.selectedSlaInfo.slaCritical &&
      sendChangedSlaInfo.major == dialogProps.selectedSlaInfo.slaMajor &&
      sendChangedSlaInfo.minor == dialogProps.selectedSlaInfo.slaMinor &&
      sendChangedSlaInfo.display_flag == dialogProps.selectedSlaInfo.slaOnOff
    ) {
      dialog.open({
        component: ConfirmDialog,

        componentProps: {
          title: lang('davisMsg.confirmBtn'),
          message: lang('davisMsg.sla.editInfo.noChangedInfo'),
          persistent: false,
          cancelBtn: false,
        },
      });
    } else {
      try {
        const slaChangeDataResult = await httpHelperV2().put<sendSlaInfoVO>(
          '/api/sla/',
          sendChangedSlaInfo
        );
        if ((slaChangeDataResult.statusText as string) === 'OK') {
          dialog.open({
            component: ConfirmDialog,

            componentProps: {
              title: lang('davisMsg.confirmBtn'),
              message: lang('davisMsg.sla.editInfo.editSlaOk'),
              persistent: false,
              cancelBtn: false,
              position: 'top',
            },
          });

          dialogRef.value.hide();
          emit('ok', sendChangedSlaInfo);
        }
      } catch (e) {
        // console.error(e);
      }
    }
  }
}

onMounted(() => {
  setSlaInfo();
});
</script>
