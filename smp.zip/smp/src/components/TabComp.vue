<template>
  <q-tabs v-if="props.theme === 'basic'" align="left" class="tab-basic">
    <q-route-tab
      v-for="(menuObj, idx) in props.menu"
      :key="idx"
      :label="menuObj.label"
      :to="menuObj.to"
      :icon="menuObj.icon"
    />
  </q-tabs>

  <q-tabs
    v-if="props.theme === 'subtab'"
    dense
    align="justify"
    class="tab-sub"
    active-color="white"
    active-bg-color="secondary"
    indicator-color="secondary"
  >
    <q-route-tab
      v-for="(menuObj, idx) in props.menu"
      :key="idx"
      :label="String(menuObj.label)"
      :to="menuObj.to"
      :ripple="false"
      :icon="menuObj.icon"
    />
  </q-tabs>
</template>

<script lang="ts" setup>
import { PropType } from 'vue';
// import type { RouteRecordRaw } from 'vue-router';

// props로 넘어오는 menu interface
interface Menu {
  to: string;
  label: string;
  icon?: string;
}

// props 정의
const props = defineProps({
  theme: {
    type: String, // 'subtab' | 'basic'
    default: 'basic',
    required: false,
  },
  menu: {
    type: Array as PropType<Array<Menu>>,
    default: () => [],
    required: true,
  },
});

// menuList
// let menuList = ref<Array<RouteRecordRaw>>();

// let tab = ref<string>('mails');

// const emit = defineEmits<{
//   (e: 'click', tab: string): void;
// }>();

// function onClick() {
//   emit('click', tab.value);
// }
</script>
