<template>
  <q-header
    elevated
    class="header"
    height-hint="98"
    @mouseleave="onMouseLeave()"
  >
    <q-toolbar>
      <!-- 왼쪽 영역 -->
      <!-- <q-btn dense flat round icon="menu" @click="toggleLeftDrawer" /> -->
      <!-- <q-btn flat label="SmartDX" @click="router.push({ name: 'main' })" /> -->
      <!-- <div class="flex items-center"> -->
      <!-- <span class="logo-icon" @click="router.push({ name: 'main' })"></span> -->
      <!-- <span class="all-menu-icon"></span> -->
      <!-- </div> -->
      <!-- <main-menu /> -->
      <!-- <main-menu-v2 ref="mainMenuRef" /> -->
      <q-space />

      <q-item class="item-header-main items-center">
        <q-item-section>
          <q-btn
            :ripple="false"
            :menu-offset="[0, 10]"
            label="Guide"
            class="full-height user-menu-container"
            @click="onGuide"
          />
        </q-item-section>
      </q-item>

      <!-- 오른쪽 영역 -->
      <right-menu />
    </q-toolbar>
  </q-header>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
// import MainMenuV2 from './menu/MainMenuV2.vue';
import RightMenu from './menu/RightMenu.vue';
import { storeToRefs } from 'pinia';
import { useMainTypeStore } from '@/store/main/maintypeStore';

const router = useRouter();

// const emit = defineEmits(['open-guide']);
const mainTypeStore = useMainTypeStore();
const { isOpenGuidePage } = storeToRefs(mainTypeStore);

// const mainMenuRef = ref<null | InstanceType<typeof MainMenuV2>>(null);
// const openPage = ref(false);
const onGuide = () => {
  isOpenGuidePage.value = !isOpenGuidePage.value;
  console.log('onGuide: ', isOpenGuidePage.value);
};

function onMouseLeave() {
  // mainMenuRef.value?.closeMenu();
}
</script>
