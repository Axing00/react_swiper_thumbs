<template>
  <q-item class="item-header-main items-center">
    <q-btn class="icon dashboard" target="_blank">
      <q-tooltip>Dashboard</q-tooltip>
      <router-link
        exact
        :to="{ name: 'dashboard' }"
        class="absolute full-width full-height"
      />
    </q-btn>
    <!-- <q-btn class="icon report" target="_blank">
      <q-tooltip>라이센스 키 관리</q-tooltip>
      <router-link
        exact
        :to="{ name: 'licenseKey' }"
        class="absolute full-width full-height"
      />
    </q-btn> -->
    <!-- <q-btn class="icon kpi" target="_blank">
      <q-tooltip>KPI</q-tooltip>
      <router-link
        exact
        :to="{ name: 'kpi' }"
        class="absolute full-width full-height"
      />
    </q-btn> -->
    <!-- <q-btn class="icon sla" target="_blank">
      <q-tooltip>SLA</q-tooltip>
      <router-link
        exact
        :to="{ name: 'sla' }"
        class="absolute full-width full-height"
      />
    </q-btn> -->
    <q-separator dark vertical />
    <!-- <q-btn class="icon header-user" target="_blank">
      <q-tooltip>User</q-tooltip>
      <router-link
        exact
        :to="{ name: 'managerconfig.us' }"
        class="absolute full-width full-height"
      />
    </q-btn> -->
    <q-separator dark vertical />
    <q-item-section>
      <q-btn-dropdown
        class="full-height user-menu-container"
        :ripple="false"
        :menu-offset="[0, 10]"
        @click="refreshUserInfo()"
      >
        <template #label>
          <div class="row items-center no-wrap">
            <q-avatar rounded size="20px">
              <span class="user-icon"></span>
              <!-- <q-badge floating color="teal">new</q-badge> -->
            </q-avatar>
            <div class="q-pl-sm sm-title">
              {{ userName ? userName : 'NAME' }}
            </div>
          </div>
        </template>
        <q-list class="user-menu text-left">
          <!-- 회원 정보 변경 버튼 -->
          <q-item
            v-close-popup
            clickable
            class="user-area items-center"
            @click="openUserInfoChangePopup"
          >
            <q-item-section side>
              <span class="icon user"></span>
            </q-item-section>
            <q-item-section>
              <q-item-label>
                <span class="primary-color text-bold"></span>
                {{ userID ? userID : 'ID' }}
              </q-item-label>
            </q-item-section>
          </q-item>
          <!-- 회원 정보 변경 버튼 -->

          <!--화면 테마 선택 버튼 -->
          <q-expansion-item expand-separator class="theme-area">
            <template #header>
              <span class="icon theme"></span>
              <q-item-section class="title-area text-bold">
                {{ $t('common.menu.theme') }}
              </q-item-section>
            </template>
            <!-- light, dark area -->
            <div class="theme-content">
              <q-item
                v-close-popup
                clickable
                :class="[
                  'theme',
                  'theme-light',
                  dartThemeActive ? '' : 'active',
                ]"
                @click="changeTheme(ThemeType.LIGHT)"
              >
                <q-item-section class="label">Light</q-item-section>
                <q-item-section avatar>
                  <!-- <q-avatar color="teal" text-color="white" icon="bluetooth" /> -->
                  <span class="icon c-theme"></span>
                </q-item-section>
              </q-item>
              <q-item
                v-close-popup
                clickable
                :class="[
                  'theme',
                  'theme-dark',
                  dartThemeActive ? 'active' : '',
                ]"
                @click="changeTheme(ThemeType.DARK)"
              >
                <q-item-section class="label">Dark</q-item-section>
                <q-item-section avatar>
                  <!-- <q-avatar color="teal" text-color="white" icon="bluetooth" /> -->
                  <span class="icon c-theme"></span>
                </q-item-section>
              </q-item>
            </div>
          </q-expansion-item>
          <!--// light, dark area -->
          <!--화면 테마 선택 버튼 -->

          <!-- 패스워드 변경 버튼 -->
          <q-item v-close-popup clickable @click="openChangePasswordPopup">
            <q-item-section side>
              <span class="icon key"></span>
            </q-item-section>
            <q-item-section>
              <q-item-label class="text-bold">
                {{ $t('common.menu.changePW') }}
              </q-item-label>
            </q-item-section>
          </q-item>
          <!-- 패스워드 변경 버튼 -->

          <q-separator />

          <!-- 로그 아웃 버튼 -->
          <q-item v-close-popup clickable @click="logout">
            <q-item-section side>
              <span class="icon logout"></span>
            </q-item-section>
            <q-item-section>
              <q-item-label class="text-bold">
                {{ $t('common.menu.logout') }}
              </q-item-label>
            </q-item-section>
          </q-item>
          <!-- 로그 아웃 버튼 -->
        </q-list>
      </q-btn-dropdown>
    </q-item-section>
  </q-item>
</template>

<script setup lang="ts">
import PasswordChangePopup from '@/components/PasswordChangePopup.vue';
import SendDavisUserInfo from '@/components/SendDavisUserInfoComp.vue';
import dialog from '@/components/dialog';
import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';
import { useAuthStore } from '@/store/app/useAuthStore';
import { useUserManager } from '@/store/admin/userManagerStore';
import { PasswordPopupType, UserInfoPopupType } from '@enums/popupType';
import { lang } from '@config/langConfig';
import { ref, onBeforeMount, watch } from 'vue';
import { applyTheme, getTheme, setTheme, ThemeType } from '@/utils/themeHelper';
import cacheHelper, { cacheType } from '@/utils/cacheHelper';

const dartThemeActive = ref<boolean>(true);

const userManagerStore = useUserManager();
const authStore = useAuthStore();

const userID = ref<string | undefined>('');
const userName = ref<string | undefined>('');

// logout popup
const logoutPopupTitle = ref<string>(lang('davisMsg.logout.logoutTitle'));
const logoutPopupDetail = ref<string>(lang('davisMsg.logout.logoutMsg'));

// 사용자 정보 변경 저장 객체
interface changeUserInfoObj {
  changeUserNo: number;
  changeUserId: string;
  changeUserName: string;
  changeUserEmail: string;
  changeUserPriv: string;
}

// 변경 된 테마, 사용자 ID, 이름 적용
const refreshUserInfo = () => {
  // 변경된 테마 header 메뉴에 적용
  const currTheme = cacheHelper.getCache(cacheType.MY_THEME);
  dartThemeActive.value = currTheme == ThemeType.DARK;
};

async function attachUserInfo() {
  // store에 사용자 id, name 적용
  authStore.userID = cacheHelper.getCache(cacheType.LOGIN_USER_ID);
  authStore.userName = cacheHelper.getCache(cacheType.USER_NAME);

  // 헤더에 사용자 id, name 적용
  userID.value = cacheHelper.getCache(cacheType.LOGIN_USER_ID);
  userName.value = cacheHelper.getCache(cacheType.USER_NAME);
}
attachUserInfo();

// 회원 정보 변경 팝업
async function openUserInfoChangePopup() {
  const loginUserNo = cacheHelper.getCache(cacheType.USER_NO);

  const loginUserInfo = await userManagerStore.getDavisUserInd(loginUserNo);

  // 선택한 유저 정보 -> dialog
  const changeUserInfo: changeUserInfoObj = {
    changeUserNo: loginUserInfo.data.id,
    changeUserId: loginUserInfo.data.login_id,
    changeUserName: loginUserInfo.data.name,
    changeUserEmail: loginUserInfo.data.email,
    changeUserPriv: loginUserInfo.data.privilege,
  };

  dialog.open({
    component: SendDavisUserInfo,
    componentProps: {
      popupType: UserInfoPopupType.USER,
      dialogTitle: lang('davisMsg.userInfoChange.infoChangeTitle'),
      changeUserInfo: changeUserInfo,
    },
  });
}

// 비밀번호 변경 팝업
function openChangePasswordPopup() {
  dialog.open({
    component: PasswordChangePopup,
    componentProps: {
      popupType: PasswordPopupType.CHANGE,
    },
  });
}

// 로그아웃
const logout = () => {
  dialog
    .open({
      component: ConfirmDialog,
      componentProps: {
        title: logoutPopupTitle.value,
        message: logoutPopupDetail.value,
        persistent: false,
        position: 'top',
      },
    })
    .onOk(async () => {
      try {
        await authStore.davisLogout();
      } catch (err) {
        // console.error(err);
      }
    });
};

// 테마 설정
function changeTheme(myTheme: ThemeType) {
  setTheme(myTheme);
  applyTheme(myTheme);

  // dartThemeActive.value = myTheme == ThemeType.DARK;
}

watch(
  () => authStore.userName,
  (userNewName) => {
    userName.value = userNewName;
  }
);

onBeforeMount(async () => {
  try {
    const userNo = cacheHelper.getCache(cacheType.USER_NO);
    const loginIndUserInfo = await userManagerStore.getDavisUserInd(userNo);

    userManagerStore.currUserPriv = loginIndUserInfo.data?.privilege;
  } catch (e) {
    // console.error(e);
  }
});
</script>
