<template>
  <q-tabs
    v-model="tabs"
    dense
    class="header-tab"
    active-color="color-main"
    indicator-color="color-main"
    align="justify"
    no-caps
  >
    <!-- 대메뉴 -->
    <q-route-tab
      v-for="menu in menuList"
      :key="menu.menu_code"
      :name="(menu.menu_code as string)"
      :label="$t(`${menu.menu_code}.title`)"
      @click="clickMenu(menu)"
      @mouseenter="showMenuPanel(menu)"
    />
  </q-tabs>
  <!-- 열리는 서브메뉴 -->
  <q-tab-panels
    v-model="tabs"
    class="tab-panel-main"
    animated
    transition-prev="fade"
    transition-next="fade"
    @mouseleave="closeMenu()"
  >
    <q-tab-panel
      v-for="menu in menuList"
      :key="menu.menu_code"
      :name="menu.menu_code"
      class="menu"
      :class="tabs"
    >
      <div
        v-for="menuTitle in menu.children"
        :key="menuTitle.menu_code"
        class="menu-content"
      >
        <div class="menu-items menu-title" @click="clickMenu(menuTitle)">
          <span>{{ $t(`${menuTitle.menu_code}.title`) }}</span>
        </div>
        <ul v-for="subMenus in menuTitle.children" :key="subMenus.menu_code">
          <div class="menu-items depth1" @click="clickMenu(subMenus)">
            <span>{{ $t(`${subMenus.menu_code}.title`) }}</span>
          </div>
          <li
            v-for="subMenu in subMenus.children"
            :key="subMenu.menu_code"
            class="depth2"
          >
            <div class="menu-items q-px-lg" @click="clickMenu(subMenu)">
              <span>{{ $t(`${subMenu.menu_code}.title`) }}</span>
            </div>
          </li>
        </ul>
      </div>
    </q-tab-panel>
  </q-tab-panels>
</template>

<script setup lang="ts">
import { useAuthStore } from '@/store/app/useAuthStore';
import { router } from '@router';
import { MenuItem } from '@router/menu';
import { storeToRefs } from 'pinia';
import { isProxy, ref, toRaw, computed } from 'vue';

const authStore = useAuthStore();
const { menuItems } = storeToRefs(authStore);

const tabs = ref<string>();
const submenu = ref<MenuItem>();

const menuList = computed(() => {
  // dashboard 는 제외
  return menuItems?.value.filter((item) => item.menu_code !== 'dashboard');
});

const showMenuPanel = (menu: MenuItem): void => {
  tabs.value = menu.menu_code as string;
  if (menu.children?.values?.length) {
    submenu.value = menu;
  }
};

const clickMenu = (menuItem: MenuItem): void => {
  const menuItemRaw = isProxy(menuItem) ? toRaw(menuItem) : menuItem;
  const getLastMenuCode = (item: MenuItem): MenuItem => {
    // 제일 마지막 children의 첫번째 메뉴
    if (item?.type == 'title' && item?.children) {
      return getLastMenuCode(item?.children[0]);
    }
    return item;
  };

  const menu = getLastMenuCode(menuItemRaw);
  router.push({ name: menu.menu_code });

  closeMenu();
};

const closeMenu = (): void => {
  tabs.value = '';
};

defineExpose({
  closeMenu,
});
</script>
<style lang="scss"></style>
