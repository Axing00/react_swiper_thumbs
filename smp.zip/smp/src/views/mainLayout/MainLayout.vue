<template>
  <q-layout view="lHh lpR fFf">
    <!-- 헤더 -->
    <main-header />
    <!-- nav -->
    <navigation />
    <guide-navigation />
    <!-- content -->
    <q-page-container>
      <router-view />
    </q-page-container>
    <!-- 푸터 -->
    <!-- <q-footer reveal elevated class="bg-primary text-white">
    </q-footer> -->
  </q-layout>
</template>

<script setup lang="ts">
import { useAppStore } from '@/store/app/useAppStore';
import { useAuthStore } from '@/store/app/useAuthStore';
import { loadTheme } from '@/utils/themeHelper';
import MainHeader from '@views/mainLayout/header/MainHeader.vue';
import Navigation from '@views/mainLayout/navigation/Navigation.vue';
import GuideNavigation from '@views/mainLayout/navigation/GuideNavigation.vue';
import { ref, onBeforeUnmount, onMounted } from 'vue';

import { storeToRefs } from 'pinia';
import { useMainTypeStore } from '@/store/main/maintypeStore';

const mainTypeStore = useMainTypeStore();
const { isOpenGuidePage } = storeToRefs(mainTypeStore);

const authStore = useAuthStore();
const appStore = useAppStore();

// const guides = ref(false);

// const openGuide = (data) => {
//   guides.value = data;
//   console.log('openGuide: ', guides);
// };

// async function initInfo() {
//   try {
//     // await appStore.selectSystemInfo();
//     await authStore.selectUserInfo();
//   } catch (error) {
//     window.location.href = '/login';
//   }
// }

onMounted(async () => {
  // initInfo();
  loadTheme();
  console.log('MainLayout');
  console.log('onMounted: isOpenGuidePage = ', isOpenGuidePage.value);
});

onBeforeUnmount(() => {
  authStore.$reset();
});
</script>
