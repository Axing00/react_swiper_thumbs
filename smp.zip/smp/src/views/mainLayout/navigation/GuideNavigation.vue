<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <q-drawer
    v-model="isOpenGuidePage"
    side="right"
    show-if-above
    overlay
    :width="200"
    :breakpoint="700"
    behavior="desktop"
    bordered
    class="bg-grey-9"
  >
    <!-- class="bg-grey-9" -->
    <!-- class="header" -->
    <!-- :class="$q.dark.isActive ? 'bg-grey-9' : 'bg-grey-3'" -->

    <q-toolbar class="header">
      <div class="flex items-center">
        <span>Guide Menu List</span>
      </div>
    </q-toolbar>

    <!-- <q-scroll-area class="fit" :horizontal-thumb-style="{ opacity: 0 }"> -->
    <q-scroll-area style="height: calc(100% - 100px)">
      <q-list padding>
        <q-item clickable>
          <q-item-label>
            <q-tooltip>아이콘 가이드</q-tooltip>
            <router-link
              exact
              :to="{ name: 'iconGuide' }"
              class="absolute full-width full-height"
            >
              <!-- :to="{ name: 'iconGuide' }" -->
              <!-- to="/guide/IconGuidView" -->
              <span class="title">아이콘 가이드</span>
            </router-link>
          </q-item-label>
        </q-item>

        <q-item clickable>
          <q-item-section avatar>
            <q-icon name="inbox" />
            <q-tooltip>대시보드</q-tooltip>
            <router-link
              exact
              :to="{ name: 'template-dashboard' }"
              class="absolute full-width full-height"
            />
          </q-item-section>

          <q-item-section>대시보드</q-item-section>
        </q-item>

        <!-- <q-item v-ripple clickable> -->
        <q-item clickable>
          <q-item-section avatar>
            <q-icon name="inbox" />
            <q-tooltip>라이센스 키 관리</q-tooltip>
            <router-link
              exact
              :to="{ name: 'template-license-key' }"
              class="absolute full-width full-height"
            />
          </q-item-section>

          <q-item-section>라이센스 키 관리</q-item-section>
        </q-item>

        <q-separator dark />

        <!-- <q-item v-ripple clickable> -->
        <!-- <q-item clickable>
          <q-item-section avatar>
            <q-icon name="drafts" />
            <q-tooltip>알림 - 메일 이력 관리</q-tooltip>
            <router-link
              exact
              :to="{ name: 'template-alert' }"
              class="absolute full-width full-height"
            />
          </q-item-section>

          <q-item-section>알림</q-item-section>
        </q-item> -->
      </q-list>
    </q-scroll-area>
  </q-drawer>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeMount } from 'vue';
import { useRouter } from 'vue-router';
import { storeToRefs } from 'pinia';
import { useMainTypeStore } from '@/store/main/maintypeStore';

const router = useRouter();

const mainTypeStore = useMainTypeStore();
const { isOpenGuidePage } = storeToRefs(mainTypeStore);

onMounted(async () => {
  isOpenGuidePage.value = false;
});
</script>
