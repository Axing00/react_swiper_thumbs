<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <q-drawer
    v-model="drawer"
    show-if-above
    :mini="miniState"
    mini-to-overlay
    :width="200"
    :breakpoint="700"
    behavior="desktop"
    bordered
    class="bg-grey-9"
    @mouseover="miniState = false"
    @mouseout="miniState = true"
  >
    <!-- class="bg-grey-9" -->
    <!-- class="header" -->
    <!-- :class="$q.dark.isActive ? 'bg-grey-9' : 'bg-grey-3'" -->

    <q-toolbar class="header">
      <div class="flex items-center">
        <span class="logo-icon" @click="router.push({ name: 'main' })"></span>
      </div>
      <!-- <div class="flex items-center">
        <span class="logo-icon" @click="router.push({ name: 'main' })"></span>
      </div> -->
      <!-- <q-avatar class="cursor-pointer">
        <img src="https://cdn.quasar.dev/logo-v2/svg/logo.svg" />
      </q-avatar> -->
      <!-- <q-space /> -->
    </q-toolbar>

    <!-- <q-scroll-area class="fit" :horizontal-thumb-style="{ opacity: 0 }"> -->
    <q-scroll-area style="height: calc(100% - 100px)">
      <q-list padding>
        <!-- <q-item v-ripple clickable> -->
        <q-item clickable>
          <q-item-section avatar>
            <q-icon name="inbox" />
            <q-tooltip>라이센스 키 관리</q-tooltip>
            <router-link
              exact
              :to="{ name: 'licenseKey' }"
              class="absolute full-width full-height"
            />
          </q-item-section>

          <q-item-section>라이센스 키 관리</q-item-section>
        </q-item>

        <q-separator dark />

        <!-- <q-item v-ripple clickable> -->
        <q-item clickable>
          <q-item-section avatar>
            <q-icon name="drafts" />
            <q-tooltip>알림 - 메일 이력 관리</q-tooltip>
            <router-link
              exact
              :to="{ name: 'alert' }"
              class="absolute full-width full-height"
            />
          </q-item-section>

          <q-item-section>알림</q-item-section>
        </q-item>
      </q-list>
    </q-scroll-area>
  </q-drawer>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const drawer = ref(false);
const miniState = ref(true);
</script>
