<template>
  <div id="q-app">
    <q-layout view="lHh Lpr fff" class="login-container">
      <div class="login-inner">
        <q-page class="window-height window-width row justify-center">
          <!-- 배경 이미지 적용 -->
          <div class="login-bg bg-left"></div>
          <div class="login-bg bg-right"></div>
          <!-- 배경 이미지 적용 -->
          <div class="column">
            <div class="row contents">
              <div class="contents-inner">
                <div class="flex justify-between items-center">
                  <span class="txt-logo"></span>
                  <span class="icon-logo"></span>
                </div>
                <q-card-section>
                  <q-form>
                    <div class="login-id">
                      <q-input
                        v-model="userID.inputValue"
                        :maxlength="30"
                        outlined
                        :error="userID.error"
                        :error-message="userID.errorMsg"
                        :placeholder="$t('login.userId')"
                        @update:model-value="initUserID"
                        @keyup.enter="onClickLoginBtn"
                      >
                        <span class="icon"></span>
                      </q-input>
                    </div>

                    <div class="login-pw">
                      <q-input
                        v-model="password.inputValue"
                        class="text-negative"
                        :maxlength="25"
                        :placeholder="$t('login.password')"
                        outlined
                        :error="password.error"
                        :error-message="password.errorMsg"
                        type="password"
                        @update:model-value="initPassword"
                        @keyup.enter="onClickLoginBtn"
                      >
                        <span class="icon"></span>
                      </q-input>
                    </div>
                    <q-select
                      v-model="localeSelected"
                      outlined
                      :options="localeComboOpt"
                      class="y-select title-select"
                      popup-content-class="y-select-drop table-select-drop"
                      @update:model-value="onChangedLocale"
                    />
                  </q-form>
                </q-card-section>
                <div class="checkbox-area">
                  <q-checkbox
                    v-model="savedUserIDChk"
                    :label="$t('login.saveUserID')"
                  />
                  <q-btn
                    class="button"
                    style="border: 1px solid rgba(255, 255, 255, 0.2)"
                    :label="$t('davisMsg.login.signUp')"
                    @click="davisSignUpBtn"
                  />
                </div>

                <!-- 버튼 영역 -->
                <div class="y-btn-area full">
                  <q-btn
                    unelevated
                    class="full-width"
                    :label="$t('davisMsg.login.title')"
                    @click="onClickLoginBtn"
                  />
                </div>
              </div>
            </div>
          </div>
        </q-page>
      </div>
    </q-layout>
  </div>
</template>

<script lang="ts" setup>
import dialog from '@/components/dialog';
import PasswordChangePopup from '@/components/PasswordChangePopup.vue';
import davisUserCreatePopup from '@/components/SendDavisUserInfoComp.vue';
import notify from '@/config/notifyConfig';
import { Locales } from '@/enums/locales';
import { useAuthStore } from '@/store/app/useAuthStore';
import cacheHelper, {
  cacheType,
  sessionUserInfoType,
} from '@/utils/cacheHelper';
import { changeI18nLocale, lang } from '@config/langConfig';
import { PasswordPopupType, UserInfoPopupType } from '@enums/popupType';
import { router } from '@router';
import { nextTick, onMounted, ref } from 'vue';
import { loadTheme } from '@/utils/themeHelper';
import ConfirmDialog from '@/components/dialog/ConfirmDialog.vue';

// import { logManager } from '@/store/log/logManagerStore';
// import { httpHelperV2 } from '@/utils/httpHelperV2';

interface Input {
  inputValue: string;
  error: boolean;
  errorMsg: string;
}

const authStore = useAuthStore();
// const logManagerStore = logManager();
const savedUserIDChk = ref(false);

const userID = ref<Input>({
  inputValue: '',
  error: false,
  errorMsg: '',
});
const password = ref<Input>({
  inputValue: '',
  error: false,
  errorMsg: '',
});

function onClickLoginBtn(): void {
  davisLoginStart(); // Davis 로그인 버튼
}

function onChangedLocale(val): void {
  localeSelected.value = val;
  changeI18nLocale(val.value);
}

function initUserID() {
  userID.value.inputValue = userID.value.inputValue.replace(' ', '');
  userID.value.error = false;
}

function initPassword() {
  password.value.inputValue = password.value.inputValue.replace(' ', '');
  password.value.error = false;
}
// <<<<<<<<<<<< 이벤트

// >>>>>>>>>>> 언어 선택
const localeEngOpt = {
  label: 'English',
  value: Locales.EN,
  description: 'English.',
};
const localeKOOpt = {
  label: '한국어',
  value: Locales.KO,
  description: '한국어.',
};
const localeComboOpt = [localeEngOpt, localeKOOpt];
const localeSelected = ref(localeKOOpt);

// Davis 회원가입 버튼
async function davisSignUpBtn() {
  dialog.open({
    component: davisUserCreatePopup,
    componentProps: {
      popupType: UserInfoPopupType.SIGNUP,
      dialogTitle: lang('davisMsg.login.signUp'),
    },
  });
}

// davis 로그인 버튼
async function davisLoginStart() {
  userID.value.error = false;
  password.value.error = false;

  if (userID.value.inputValue == '') {
    userID.value.error = true;
    userID.value.errorMsg = lang('davisMsg.required');
    return;
  } else {
    userID.value.error = false;
  }

  if (password.value.inputValue == '') {
    password.value.error = true;
    password.value.errorMsg = lang('davisMsg.required');
    return;
  } else {
    password.value.error = false;
  }

  if (userID.value.error == false && password.value.error == false) {
    try {
      const loginData = await authStore.davisLogin(
        userID.value.inputValue,
        password.value.inputValue
      );

      if (loginData === 'INVALID_ID_OR_PWD') {
        userID.value.error = true;
        userID.value.errorMsg = lang('davisMsg.login.error.loginFailed');

        password.value.error = true;
        password.value.errorMsg = lang('davisMsg.login.error.loginFailed');
      }

      if (loginData?.statusText === 'OK') {
        // store에 유저 아이디, 이름, 권한 저장
        if (loginData.data !== undefined && loginData.data !== null) {
          authStore.userID = loginData?.data.user.login_id;
          authStore.userName = loginData?.data.user.name;
          authStore.userNo = loginData?.data.user.id;
        }
        // 아이디, 다국어 설정 저장
        saveCache();
        if (loginData?.data.user.require_chg_pwd === 1) {
          // 최초 접속 시 패스워드 변경 팝업
          // dialog.open({
          //   component: ConfirmDialog,
          //   componentProps: {
          //     message: lang('davisMsg.login.info.firstLogin'),
          //     position: 'top',
          //     persistent: false,
          //     closeBtn: false,
          //     cancelBtn: false,
          //   },
          // });
          notify.info(lang('davisMsg.login.info.firstLogin'));
          openChangePasswordPopup('first');
        } else if (loginData?.data.user.require_chg_pwd === 2) {
          // 비밀번호 변경 3개월 초과시
          openChangePasswordPopup('period');
        } else if (userID.value.inputValue == password.value.inputValue) {
          // 비밀번호를 초기화 했을경우 비밀번호 변경 -> 임시로 막아놓음
          // notify.info(lang('davisMsg.login.info.firstLogin'));
          // openChangePasswordPopup('first');
          moveToMain(); // 임시
        } else {
          moveToMain();
        }
      }
    } catch (e) {
      // console.log(e);
    } finally {
      password.value.inputValue = '';
    }
  }
}

// 최초 접속 시 비밀번호 변경 창 오픈
function openChangePasswordPopup(changeType) {
  if (changeType === 'first') {
    dialog.open({
      component: PasswordChangePopup,
      componentProps: {
        popupType: PasswordPopupType.FIRST,
      },
    });
  } else if (changeType === 'period') {
    dialog.open({
      component: PasswordChangePopup,
      componentProps: {
        popupType: PasswordPopupType.PERIOD,
      },
    });
  }
}

// 아이디, 다국어 설정값 저장
function saveCache(): void {
  if (savedUserIDChk.value) {
    cacheHelper.setCache(cacheType.USER_ID, userID.value.inputValue);
  } else {
    cacheHelper.removeCache(cacheType.USER_ID);
  }
  cacheHelper.setCache(cacheType.LOCALE, localeSelected.value.value);

  // 로그인 유저 로그인 ID, 이름, DB ID 저장
  cacheHelper.setCache(cacheType.LOGIN_USER_ID, authStore.userID);
  cacheHelper.setCache(cacheType.USER_NAME, authStore.userName);
  cacheHelper.setCache(cacheType.USER_NO, authStore.userNo);
}

function loadCache(): void {
  const id = cacheHelper.getCache(cacheType.USER_ID);
  if (id) {
    userID.value.inputValue = id;
    savedUserIDChk.value = true;
  }

  const locale = cacheHelper.getCache(cacheType.LOCALE);
  localeSelected.value = locale == Locales.EN ? localeEngOpt : localeKOOpt;
  onChangedLocale(localeSelected.value);
}

// 메인 화면으로 이동
function moveToMain() {
  router.push({
    name: 'main',
  });
}

// 해당 라이프 사이클시 동작하는 메소드 (사용 안하면 삭제)
onMounted(() => {
  // 로그인 페이지 시작시 초기화
  authStore.$reset();
  loadCache();
  loadTheme();
});
</script>
