<template>
  <div class="main-wrapper dashboard-container">
    <QPage padding class="main-container">
      <div class="top">
        <q-table
          grid
          flat
          bordered
          :rows="rows"
          row-key="name"
          hide-header
          style="width: 100%"
        >
          <template #item="props">
            <div style="width: 15%">
              <q-card flat bordered>
                <q-card-section>
                  <strong>{{ props.row.name }}</strong>
                  <q-btn push color="primary" label="Push" />
                </q-card-section>
                <q-separator />
                <q-card-section>
                  <div>{{ props.row.count }}</div>
                </q-card-section>
              </q-card>
            </div>
          </template>
        </q-table>
      </div>
      <div
        class="bottom"
        style="padding-top: 10px; display: flex; flex-wrap: wrap"
      >
        <div id="chart-container1" style="width: 800px; height: 400px" />
        <div id="chart-container2" style="width: 800px; height: 400px" />
        <div id="chart-container3" style="width: 800px; height: 400px" />
        <div id="chart-container4" style="width: 800px; height: 400px" />
      </div>
    </QPage>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUpdated, shallowRef, watch, nextTick } from 'vue';
import { useDashboardStore } from '@/store/dashboard/dashboardStore';
import { lang } from '@/config/langConfig';
import * as ECharts from 'echarts';

const dashboardStore = useDashboardStore();

const chartComp1 = shallowRef();
const chartDiv1 = shallowRef();
const chartComp2 = shallowRef();
const chartDiv2 = shallowRef();
const chartComp3 = shallowRef();
const chartDiv3 = shallowRef();
const chartComp4 = shallowRef();
const chartDiv4 = shallowRef();

const top5UseOption = {
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      // Use axis to trigger tooltip
      type: 'shadow', // 'shadow' as default; can also be 'line' or 'shadow'
    },
  },
  legend: {
    bottom: '3%',
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '10%',
    containLabel: true,
  },
  xAxis: {
    type: 'value',
  },
  yAxis: {
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
  },
  series: [
    {
      name: 'Direct',
      type: 'bar',
      stack: 'total',
      label: {
        show: true,
      },
      emphasis: {
        focus: 'series',
      },
      data: [320, 302, 301, 334, 390, 330, 320],
    },
    {
      name: 'Mail Ad',
      type: 'bar',
      stack: 'total',
      label: {
        show: true,
      },
      emphasis: {
        focus: 'series',
      },
      data: [120, 132, 101, 134, 90, 230, 210],
    },
    {
      name: 'Affiliate Ad',
      type: 'bar',
      stack: 'total',
      label: {
        show: true,
      },
      emphasis: {
        focus: 'series',
      },
      data: [220, 182, 191, 234, 290, 330, 310],
    },
    {
      name: 'Video Ad',
      type: 'bar',
      stack: 'total',
      label: {
        show: true,
      },
      emphasis: {
        focus: 'series',
      },
      data: [150, 212, 201, 154, 190, 330, 410],
    },
    {
      name: 'Search Engine',
      type: 'bar',
      stack: 'total',
      label: {
        show: true,
      },
      emphasis: {
        focus: 'series',
      },
      data: [820, 832, 901, 934, 1290, 1330, 1320],
    },
  ],
};

const realTimeUseLiscenseOption = {
  // title: {
  //   left: '3%',
  //   text: '개발부'
  // },
  tooltip: {
    trigger: 'item',
  },
  legend: {
    bottom: '5%',
    // left: '3%',
    // doesn't perfectly work with our tricks, disable it
    selectedMode: false,
  },
  series: [
    {
      name: 'Access From',
      type: 'pie',
      radius: ['40%', '70%'],
      center: ['50%', '70%'],
      // adjust the start angle
      startAngle: 180,
      label: {
        show: true,
        formatter(param) {
          // correct the percentage
          return param.name + ' (' + param.percent * 2 + '%)';
        },
      },
      data: [
        { value: 1048, name: 'Search Engine' },
        { value: 735, name: 'Direct' },
        { value: 580, name: 'Email' },
        { value: 484, name: 'Union Ads' },
        { value: 300, name: 'Video Ads' },
        {
          // make an record to fill the bottom 50%
          value: 1048 + 735 + 580 + 484 + 300,
          itemStyle: {
            // stop the chart from rendering this piece
            color: 'none',
            decal: {
              symbol: 'none',
            },
          },
          label: {
            show: false,
          },
        },
      ],
    },
  ],
};

const uselicenseOption = {
  title: {
    // text: '라이선스 사용현황'
  },
  tooltip: {
    trigger: 'axis',
  },
  legend: {
    bottom: '3%',
    data: ['Email', 'Union Ads', 'Video Ads', 'Direct', 'Search Engine'],
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '10%',
    containLabel: true,
  },
  toolbox: {
    feature: {
      // saveAsImage: {}
    },
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
  },
  yAxis: {
    type: 'value',
  },
  series: [
    {
      name: 'Email',
      type: 'line',
      stack: 'Total',
      data: [120, 132, 101, 134, 90, 230, 210],
    },
    {
      name: 'Union Ads',
      type: 'line',
      stack: 'Total',
      data: [220, 182, 191, 234, 290, 330, 310],
    },
    {
      name: 'Video Ads',
      type: 'line',
      stack: 'Total',
      data: [150, 232, 201, 154, 190, 330, 410],
    },
    {
      name: 'Direct',
      type: 'line',
      stack: 'Total',
      data: [320, 332, 301, 334, 390, 330, 320],
    },
    {
      name: 'Search Engine',
      type: 'line',
      stack: 'Total',
      data: [820, 932, 901, 934, 1290, 1330, 1320],
    },
  ],
};

const columns = [
  {
    name: 'count',
    required: true,
    align: 'left',
  },
];

const rows = [
  {
    name: '활성화된 라이선스',
    count: '100',
  },
  {
    name: '라이선스 평균 사용률',
    count: '90%',
  },
  {
    name: '갱신 예정 라이선스',
    count: '159',
  },
  {
    name: '사용중인 S/W',
    count: '600',
  },
  {
    name: '총지출 금액',
    count: '처마원',
  },
];

onMounted(() => {
  console.log('[Dashboard]onMounted');
  nextTick(() => {
    initData();
  });
  nextTick(() => {
    initDashBoard();
  });
});

onUpdated(() => {
  console.log('[Dashboard]onUpdated');
});

async function initDashBoard() {
  console.log('[Dashboard]initDashBoard');
  chartDiv1.value = document.getElementById('chart-container1');
  chartComp1.value = ECharts.init(chartDiv1.value, {
    renderer: 'canvas',
    useDirtyRect: false,
  });
  chartComp1.value.setOption(top5UseOption);

  chartDiv2.value = document.getElementById('chart-container2');
  chartComp2.value = ECharts.init(chartDiv2.value, {
    renderer: 'canvas',
    useDirtyRect: false,
  });
  chartComp2.value.setOption(top5UseOption);

  chartDiv3.value = document.getElementById('chart-container3');
  chartComp3.value = ECharts.init(chartDiv3.value, {
    renderer: 'canvas',
    useDirtyRect: false,
  });
  chartComp3.value.setOption(uselicenseOption);

  chartDiv4.value = document.getElementById('chart-container4');
  chartComp4.value = ECharts.init(chartDiv4.value, {
    renderer: 'canvas',
    useDirtyRect: false,
  });
  chartComp4.value.setOption(realTimeUseLiscenseOption);
  nextTick(() => {
    getDashBoardData();
  });
}

function initData() {
  console.log('[Dashboard]initData');
  dashboardStore.$reset();
}

async function getDashBoardData() {
  // await dashboardStore.getDashboardEntriesTopData();
}
</script>

<style scoped></style>
