/**
 * 메인 화면 > 대시보드 차트 영역 - 차트 관련 정의 파일
 * created by yoonsunsohn (2022-11-03)
 */
import { lang } from '@config/langConfig';

// 대시보드 차트 목록 - PaaS 디폴트
export const paasDefault = {
  // 클러스터 CPU (Core) - 사용량
  clsuterCpu: {
    title: lang('dashboard.paasDe.clusterCpu.title'),
    tooltipTitle: lang('dashboard.paasDe.clusterCpu.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.clusterCpu.tooltipContent'),
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'cpu',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'usage-cpu',
    refChart: 1,
    formatType: 'floor',
  },
  // 클러스터 CPU (Core) - 요청량
  clsuterCpu1: {
    title: lang('dashboard.paasDe.clusterCpu.title'),
    isTitleInvisible: true, // 대시보드 차트 selectbox 존재 시(요청량 등) 타이틀 중복 노출되지 않도록 필터링
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'quota',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'request-cpu',
    formatType: 'fracDigit2',
  },
  // 클러스터 Memory (GB) - Working set 사용량
  clsuterMemory: {
    title: lang('dashboard.paasDe.clusterMemory.title'),
    tooltipTitle: lang('dashboard.paasDe.clusterMemory.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.clusterMemory.tooltipContent'),
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'memory',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'working-set-bytes',
    refChart: 2,
    formatType: 'gib',
  },
  // 클러스터 Memory (GB) - Cache 사용량
  clsuterMemory1: {
    title: lang('dashboard.paasDe.clusterMemory.title'),
    isTitleInvisible: true,
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'memory',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'usage-bytes',
    formatType: 'gib',
  },
  // 클러스터 Memory (GB) - 요청량
  clsuterMemory2: {
    title: lang('dashboard.paasDe.clusterMemory.title'),
    isTitleInvisible: true,
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'quota',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'request-memory',
    formatType: 'gib',
  },
  // 클러스터 Network (MBPS) - Ingress
  clsuterNetwork: {
    title: lang('dashboard.paasDe.clusterNetwork.title'),
    tooltipTitle: lang('dashboard.paasDe.clusterNetwork.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.clusterNetwork.tooltipContent'),
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'network',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'inbound',
    refChart: 1,
    formatType: 'clusterNetwork',
  },
  // 클러스터 Network (MBPS) - Egress
  clsuterNetwork1: {
    title: lang('dashboard.paasDe.clusterNetwork.title'),
    isTitleInvisible: true,
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'network',
    resultType: 'transition',
    metricName: 'cluster',
    measure: 'outbound',
    formatType: 'clusterNetwork',
  },
  // 서비스 맵 CPU 사용 TOP 5(Core)
  servicemapCpu: {
    title: lang('dashboard.paasDe.cpuUsageTopFive.title'),
    tooltipTitle: lang('dashboard.paasDe.cpuUsageTopFive.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.cpuUsageTopFive.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-dashboard',
    metricType: 'control-dashboard-servicemap-cpu-top',
    resultType: 'transition',
    metricName: 'service-map',
    formatType: 'floor',
  },
  // 서비스 맵 Memory 사용 TOP 5(GB)
  servicemapMemory: {
    title: lang('dashboard.paasDe.memoryUsageTopFive.title'),
    tooltipTitle: lang('dashboard.paasDe.memoryUsageTopFive.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.memoryUsageTopFive.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-dashboard',
    metricType: 'control-dashboard-servicemap-memory-top',
    resultType: 'transition',
    metricName: 'service-map',
    formatType: 'gib',
  },
  // Network Storage 사용률 TOP 5(%)
  networkStorage: {
    title: lang('dashboard.paasDe.networkUsage.title'),
    tooltipTitle: lang('dashboard.paasDe.networkUsage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.networkUsage.tooltipContent'),
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'storage-class',
    resultType: 'current',
  },
  // Block Storage Volume 사용률 TOP 5(%)
  blockStorage: {
    title: lang('dashboard.paasDe.blockStorage.title'),
    tooltipTitle: lang('dashboard.paasDe.blockStorage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasDe.blockStorage.tooltipContent'),
    versionType: 'v2',
    targetType: 'clusters',
    metricType: 'volume',
    resultType: 'current',
  },
};

// 대시보드 차트 목록 - PaaS 클러스터
export const paasCluster = {
  // 최소 여유 CPU 노드
  nodeCpu: {
    title: lang('dashboard.paasCl.minFreeCpu.title'),
    tooltipTitle: lang('dashboard.paasCl.minFreeCpu.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.minFreeCpu.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-cpu-usage',
    resultType: 'transition',
    areaStyle: true,
  },
  // 최소 여유 디스크 노드
  nodeDisk: {
    title: lang('dashboard.paasCl.minFreeDisk.title'),
    tooltipTitle: lang('dashboard.paasCl.minFreeDisk.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.minFreeDisk.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-disk-usage',
    resultType: 'transition',
    areaStyle: true,
  },
  // 최소 여유 메모리 노드
  nodeMemory: {
    title: lang('dashboard.paasCl.minFreeMemory.title'),
    tooltipTitle: lang('dashboard.paasCl.minFreeMemory.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.minFreeMemory.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-memory-usage',
    resultType: 'transition',
    areaStyle: true,
  },
  // API 서버 요청-응답 시간 (10분 평균)
  httpRequest: {
    title: lang('dashboard.paasCl.requestTime.title'),
    tooltipTitle: lang('dashboard.paasCl.requestTime.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.requestTime.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-http-request-duration',
    resultType: 'transition',
    formatType: 'multiply3',
    areaStyle: true,
  },
  // 다시 시작된 Pod 증가율 (2분)
  podRestart: {
    title: lang('dashboard.paasCl.restartPod.title'),
    tooltipTitle: lang('dashboard.paasCl.restartPod.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.restartPod.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-pod-restart',
    resultType: 'transition',
    areaStyle: true,
  },
  // CPU 시스템 부하 (코어 평균)
  nodeLoad: {
    title: lang('dashboard.paasCl.cpuSystemLoad.title'),
    tooltipTitle: lang('dashboard.paasCl.cpuSystemLoad.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.cpuSystemLoad.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-load',
    resultType: 'transition',
    metricName: 'node',
    measure: 'load1',
  },
  // 메모리 사용량 (GiB)
  nodeMemoryUsageGib: {
    title: lang('dashboard.paasCl.memoryUsage.title'),
    tooltipTitle: lang('dashboard.paasCl.memoryUsage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.memoryUsage.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-memory-usage',
    resultType: 'transition',
    metricName: 'node',
    measure: 'used',
    formatType: 'gib',
  },
  // CPU 유휴 시간 평균 (%)
  nodeCpuUsagePercent: {
    title: lang('dashboard.paasCl.cpuIdleAvg.title'),
    tooltipTitle: lang('dashboard.paasCl.cpuIdleAvg.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.cpuIdleAvg.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-cpu-usage',
    resultType: 'transition',
    metricName: 'node',
    formatType: 'idle',
  },
  // 디스크 사용량 (GiB)
  nodeDiskUsageGib: {
    title: lang('dashboard.paasCl.diskUsage.title'),
    tooltipTitle: lang('dashboard.paasCl.diskUsage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.diskUsage.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-disk-usage',
    resultType: 'transition',
    metricName: 'node device',
    metricSymbol: ' ',
    measure: 'available',
    formatType: 'gib',
  },
  // 디스크 I/O 속도
  nodeDiskIo: {
    title: lang('dashboard.paasCl.diskIO.title'),
    tooltipTitle: lang('dashboard.paasCl.diskIO.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.diskIO.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-disk-io',
    resultType: 'transition',
    metricName: 'node_device',
    metricSymbol: '_',
  },
  // 메모리 사용 상위 Pod (GiB)
  podMemory: {
    title: lang('dashboard.paasCl.memoryIntensePod.title'),
    tooltipTitle: lang('dashboard.paasCl.memoryIntensePod.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.memoryIntensePod.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-pod-memory-top',
    resultType: 'transition',
    metricName: 'pod',
    formatType: 'gib',
  },
  // CPU 사용 상위 컨테이너
  podCpu: {
    title: lang('dashboard.paasCl.cpuContainer.title'),
    tooltipTitle: lang('dashboard.paasCl.cpuContainer.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.cpuContainer.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-pod-cpu-top',
    resultType: 'transition',
    metricName: 'pod',
    formatType: 'fracDigit2',
  },
  // Pod 상태별 실행 수
  podRunning: {
    title: lang('dashboard.paasCl.podRuningCnt.title'),
    tooltipTitle: lang('dashboard.paasCl.podRuningCnt.tooltipTitle'),
    tooltipContent: lang('dashboard.paasCl.podRuningCnt.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-pod-running',
    resultType: 'transition',
    metricName: 'phase',
  },
};

// 대시보드 차트 목록 - PaaS 노드
export const paasNode = {
  // CPU 사용량 (%)
  nodeCpuUsage: {
    title: lang('dashboard.paasNo.cpuUsage.title'),
    tooltipTitle: lang('dashboard.paasNo.cpuUsage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpuUsage.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-cpu-usage',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // CPU 시스템 부하 (1분 평균)
  nodeCpuload1: {
    title: lang('dashboard.paasNo.cpuOneLoad.title'),
    tooltipTitle: lang('dashboard.paasNo.cpuOneLoad.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpuOneLoad.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-load',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // CPU 시스템 부하 (5분 평균)
  nodeCpuload5: {
    title: lang('dashboard.paasNo.cpuFiveLoad.title'),
    tooltipTitle: lang('dashboard.paasNo.cpuFiveLoad.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpuFiveLoad.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-load',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // 메모리 사용량 (%)
  nodeMemoryUsage: {
    title: lang('dashboard.paasNo.memoryUsage.title'),
    tooltipTitle: lang('dashboard.paasNo.memoryUsage.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.memoryUsage.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-memory-usage',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // 최소 여유 파일 시스템
  nodeDiskMinUsage: {
    title: lang('dashboard.paasNo.minFreeFileSystem.title'),
    tooltipTitle: lang('dashboard.paasNo.minFreeFileSystem.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.minFreeFileSystem.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-disk-usage',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // 최대 사용 파일 시스템
  nodeDiskMaxUsage: {
    title: lang('dashboard.paasNo.maxUsedFileSystem.title'),
    tooltipTitle: lang('dashboard.paasNo.maxUsedFileSystem.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.maxUsedFileSystem.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-disk-usage',
    resultType: 'transition',
    metricName: 'node',
    areaStyle: true,
  },
  // 사용된 메모리 (GiB)
  nodeUsedMemory: {
    title: lang('dashboard.paasNo.usedMemory.title'),
    tooltipTitle: lang('dashboard.paasNo.usedMemory.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.usedMemory.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-memory-usage',
    resultType: 'transition',
    measure: 'used',
    formatType: 'gib',
  },
  // 사용된 메모리 (%)
  nodeUsedMemoryRatio: {
    title: lang('dashboard.paasNo.usedMemoryPer.title'),
    tooltipTitle: lang('dashboard.paasNo.usedMemoryPer.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.usedMemoryPer.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-memory-usage',
    resultType: 'transition',
    measure: 'used-ratio',
    formatType: 'multiply2',
  },
  // 네트워크 사용량 (k8s)
  nodeNetworkUsage: {
    title: lang('dashboard.paasNo.usageNetwork.title'),
    tooltipTitle: lang('dashboard.paasNo.usageNetwork.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.usageNetwork.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-traffic-by-device',
    resultType: 'transition',
    metricName: 'device measure',
    metricSymbol: ' ',
    formatType: 'nodeNetworkUsage',
  },
  // CPU 사용량 (%)
  nodeLineCpuUsage: {
    title: lang('dashboard.paasNo.cpuUsagePer.title'),
    tooltipTitle: lang('dashboard.paasNo.cpuUsagePer.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpuUsagePer.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-cpu-usage-by-mode',
    resultType: 'transition',
    metricName: 'mode',
    modeNot: 'idle',
    formatType: 'multiply2',
  },
  // CPU 부하 (1분, 5분, 15분)
  nodeCpuLoad: {
    title: lang('dashboard.paasNo.cpuLoad.title'),
    tooltipTitle: lang('dashboard.paasNo.cpuLoad.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpuLoad.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-kubernetes',
    metricType: 'control-kubernetes-node-load',
    resultType: 'transition',
    metricName: 'measure',
  },
  // CPU 사용 빈도 (%)
  nodeCpuUsageFrequency: {
    title: lang('dashboard.paasNo.cpubusy.title'),
    tooltipTitle: lang('dashboard.paasNo.cpubusy.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.cpubusy.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-cpu-usage-by-mode',
    resultType: 'transition',
    mode: 'idle',
    formatType: 'multiply2',
  },
  // 사용된 디스크 공간 (GiB)
  nodeDiskUsage: {
    title: lang('dashboard.paasNo.usedDisk.title'),
    tooltipTitle: lang('dashboard.paasNo.usedDisk.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.usedDisk.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-disk-usage',
    resultType: 'transition',
    measure: 'used',
    formatType: 'gib',
  },
  // 사용 가능한 디스크 공간 (%)
  nodeDiskUsageRatio: {
    title: lang('dashboard.paasNo.freeDiskSpace.title'),
    tooltipTitle: lang('dashboard.paasNo.freeDiskSpace.tooltipTitle'),
    tooltipContent: lang('dashboard.paasNo.freeDiskSpace.tooltipContent'),
    versionType: 'v4',
    targetType: 'controls-nodes',
    metricType: 'control-node-disk-usage',
    resultType: 'transition',
    measure: 'available_ratio',
    formatType: 'nodeDiskUsageRatio',
  },
};

// 대시보드 차트 목록 - IaaS 디폴트
export const iaasDeafult = {
  vendorGuestOs: {
    title: 'Vendor and Guest OS Chart',
  },
};
