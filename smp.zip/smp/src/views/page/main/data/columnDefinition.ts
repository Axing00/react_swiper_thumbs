/**
 * 메인 화면 > 테이블 형태 Contents 영역 - 데이터테이블 컬럼 정의 파일
 * created by yoonsunsohn (2022-08-23)
 */
import { h } from 'vue';
// import { ColumnsType, ColumnType } from 'ant-design-vue/lib/table';
import dialog from '@/components/dialog';
import IaaSDetailPopup from '@views/page/main/components/IaaSDetailPopup.vue';
import { nextTick } from 'process';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import 'dayjs/locale/ko';
import { i18n, lang } from '@config/langConfig';
import { Locales } from '@/enums/locales';

// 바이트 포맷터
export const formatBytes = (bytes, decimals = 0) => {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

const textRenderer = (data, text = '') => {
  return h('text', {
    innerHTML: `${data.value} ${text}`,
  });
};

const nameIconTextRenderer = (data) => {
  // 인스턴스일 경우는 type 컬럼이 다른 데이터를 나타내므로 emsId로 판별
  const type = data.record.emsId !== undefined ? 'instance' : data.record.type;
  let iconType = '';
  switch (type) {
    case 'cloud':
      iconType = 'cloud';
      break;
    case 'PaaS':
      iconType = 'paas';
      break;
    case 'IaaS/PaaS':
      iconType = 'ps-is';
      break;
    case 'Master':
      iconType = 'node_m';
      break;
    case 'Worker':
      iconType = 'node_w';
      break;
    case 'pod':
      iconType = 'pod';
      break;
    case 'instance':
      iconType = 'iaas';
      break;
    default:
      iconType = '';
      break;
  }

  // 클라우드/인스턴스일 경우에는 심각도 정보 표시하지 않음
  let severity = '';
  if (type !== 'cloud' && type !== 'instance') {
    const delegate = data.record?.event?.delegate;
    switch (delegate) {
      case 'critical':
        severity = '_cr';
        break;
      case 'major':
        severity = '_mj';
        break;
      case 'minor':
        severity = '_mn';
        break;
      case 'warning':
        severity = '_wr';
        break;
      default:
        severity = '';
        break;
    }
  }
  return h('fragment', { class: 'flex items-center no-wrap flex-icon' }, [
    h('i', {
      class: `name-icon ${iconType}${severity}`,
      style: 'margin-right: 10px;',
    }),
    h('text', {
      innerHTML: data.value,
      title: data.value,
      style:
        'padding-right: 5px; max-width: 90%; text-overflow: ellipsis; overflow: hidden; line-height: 20px',
    }),
  ]);
};

const iconTextRenderer = (data) => {
  // RUNNING - 클러스터
  // True - 노드
  // Running - 파드
  const normalCondition =
    data.value === 'RUNNING' ||
    data.value === 'True' ||
    data.value === 'Running';
  const statusIocn = normalCondition
    ? 'status-icon ready'
    : 'status-icon n-ready';
  let dataText = data.value;
  if (data.record.ready !== undefined) {
    // 노드일 경우
    dataText = data.value === 'True' ? 'Ready' : 'Not Ready';
  }
  return h('fragment', { class: 'flex items-center no-wrap' }, [
    h('i', {
      class: statusIocn,
      style: 'margin-right: 10px',
      innerHTML: '',
    }),
    h('text', {
      innerHTML: dataText,
      class: 'txt',
    }),
  ]);
};

const ageRenderer = (value) => {
  dayjs.extend(relativeTime);
  if (i18n.global.locale.value == Locales.KO) {
    dayjs.locale('ko');
  } else if (i18n.global.locale.value == Locales.EN) {
    dayjs.locale('en');
  }
  return dayjs().from(dayjs(value), true);
};

const bytesRenderer = (data, decimals = 0) => {
  return h('text', {
    innerHTML: formatBytes(data.value, decimals),
  });
};

const cpuRenderer = (data, decimal = 0) => {
  let cpuCore = data.value;
  switch (decimal) {
    case 1:
      cpuCore = Math.floor(data.value / 100) / 10;
      break;
    case 2:
      cpuCore = Math.floor(data.value / 10) / 100;
      break;
    case 3:
      cpuCore = Math.floor(data.value) / 1000;
      break;
    default:
      cpuCore = Math.floor(data.value * 10) / 10;
      break;
  }
  return h('text', {
    innerHTML: `${cpuCore} Core`,
  });
};

// 팝업창 이용
const showDialog = (param) => {
  dialog.open({
    component: IaaSDetailPopup,
    componentProps: {
      title: `${lang('main.co.detailInfo')}(IaaS)`, // 상세 정보(IaaS)
      iaasInfo: param,
    },
  });
  nextTick(() => {
    setClass('y-lg');
  });
};

// 팝업 클래스 적용
export default function setClass(className) {
  const popup = document.getElementsByClassName('popup-container')[0];
  popup.className = popup.className + ' ' + className;
}

// 클라우드 목록 (PaaS)
// export const cloudColumns: ColumnsType = [
//   {
//     title: lang('main.co.name'), // 이름
//     dataIndex: 'name',
//     customRender: (data) => nameIconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.name < b.name) return -1; // asc
//         else if (a.name > b.name) return 1; // desc
//         else return 0; // default
//       },
//     },
//   },
//   {
//     title: lang('main.co.organizationName'), // 조직 이름
//     dataIndex: 'organizationName',
//   },
//   {
//     title: lang('main.co.cluster'), // 클러스터
//     dataIndex: 'cluster',
//     customRender: (data) => {
//       return h('text', {
//         innerHTML: data.record.cluster.length,
//       });
//     },
//   },
//   {
//     title: lang('main.co.description'), // 설명
//     dataIndex: 'description',
//   },
// ];

// 클러스터 목록 (PaaS) = 클러스터 목록 (IaaS/PaaS)
// export const paasClusterColumns: ColumnsType = [
//   {
//     title: lang('main.co.name'), // 이름
//     dataIndex: 'name',
//     customRender: (data) => nameIconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.name < b.name) return -1; // asc
//         else if (a.name > b.name) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 2, // 정렬 우선순위
//     },
//   },
//   { title: lang('main.co.provider'), dataIndex: 'providerCodeName' }, // 제공자
//   {
//     title: lang('main.co.status'), // 상태
//     dataIndex: 'state',
//     customRender: (data) => iconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.state < b.state) return -1; // asc
//         else if (a.state > b.state) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 1, // 정렬 우선순위
//     },
//   },
//   {
//     title: lang('main.co.resourceAllocationType'), // 자원 할당 유형
//     dataIndex: 'clusterTenancy',
//   },
//   {
//     title: lang('main.co.nodeCount'), // 노드 수
//     dataIndex: 'readyNodeCount',
//     customRender: (data) => {
//       return h('text', {
//         innerHTML: `${data.value} / ${data.record.desiredNodeCount}`,
//       });
//     },
//   },
//   { title: lang('main.co.region'), dataIndex: 'regionCode' }, // 지역
//   {
//     title: lang('main.co.clusterResource'), // 클러스터 자원
//     children: [
//       {
//         title: 'CPU',
//         dataIndex: 'capacityCpu',
//         customRender: (data) => textRenderer(data, 'Core'),
//       },
//       {
//         title: 'Memory',
//         dataIndex: 'totalMemUsage',
//         customRender: (data) => bytesRenderer(data),
//       },
//       {
//         title: 'Storage',
//         dataIndex: 'volumeRequestCapacity',
//         customRender: (data) => textRenderer(data, 'GB'),
//       },
//     ],
//   },
// ];

// 노드 목록 (PaaS) = 노드 목록 (IaaS/PaaS)
// export const nodeColumns: ColumnsType = [
//   {
//     title: lang('main.co.name'), // 이름
//     dataIndex: 'name',
//     customRender: (data) => nameIconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.name < b.name) return -1; // asc
//         else if (a.name > b.name) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 2, // 정렬 우선순위
//     },
//   },
//   { title: 'IP', dataIndex: 'internalIp' },
//   {
//     title: lang('main.co.status'), // 상태
//     dataIndex: 'ready',
//     customRender: (data) => iconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.ready < b.ready) return -1; // asc
//         else if (a.ready > b.ready) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 1, // 정렬 우선순위
//     },
//   },
//   {
//     title: 'CPU',
//     children: [
//       {
//         title: lang('main.co.totalCapacity'), // 총량
//         dataIndex: 'cpuCapacity',
//         customRender: (data) => cpuRenderer(data),
//       },
//       {
//         title: lang('main.co.amountRequested'), // 요청량
//         dataIndex: 'cpuRequests',
//         customRender: (data) => cpuRenderer(data, 1),
//       },
//       {
//         title: lang('main.co.usage'), // 사용량
//         dataIndex: 'cpuUsage',
//         customRender: (data) => cpuRenderer(data),
//       },
//     ],
//   },
//   {
//     title: 'Memory',
//     children: [
//       {
//         title: lang('main.co.totalCapacity'), // 총량
//         dataIndex: 'memoryCapacity',
//         customRender: (data) => bytesRenderer(data, 1),
//       },
//       {
//         title: lang('main.co.amountRequested'), // 요청량
//         dataIndex: 'memoryRequests',
//         customRender: (data) => bytesRenderer(data, 1),
//       },
//       {
//         title: lang('main.co.usage'), // 사용량
//         dataIndex: 'memoryUses',
//         customRender: (data) => bytesRenderer(data, 1),
//       },
//     ],
//   },
//   {
//     title: 'Disk',
//     children: [
//       {
//         title: lang('main.co.totalCapacity'), // 총량
//         dataIndex: 'diskCapacity',
//         customRender: (data) => bytesRenderer(data, 1),
//       },
//       {
//         title: lang('main.co.usage'), // 사용량
//         dataIndex: 'diskUsed',
//         customRender: (data) => bytesRenderer(data, 1),
//       },
//     ],
//   },
//   {
//     title: `${lang('main.co.instance')}(Pod)`, // 인스턴스(Pod)
//     dataIndex: 'instance',
//     customRender: (data) => {
//       return h('text', {
//         innerHTML: `${data.record.podNormalCount} / ${data.record.podTotalCount}`,
//       });
//     },
//   },
// ];

// 노드 목록 (IaaS/PaaS)일 경우 해당 컬럼 concat
// export const nodeIaaSDetailcolumn: ColumnType = {
//   title: `IaaS ${lang('main.co.detailInfo')}`, // IaaS 상세 정보
//   dataIndex: 'iaasDetail',
//   customRender: (data) => {
//     return h('a', {
//       innerHTML: '<i class="detail-iaas-icon"></i>',
//       onClick: () => {
//         // IaaS 상세 정보 팝업 오픈
//         showDialog(data.record.instance);
//       },
//     });
//   },
// };

// 파드 목록 (PaaS) = 파드 목록 (IaaS/PaaS)
// export const podColumns: ColumnsType = [
//   {
//     title: lang('main.co.name'), // 이름
//     dataIndex: 'name',
//     align: 'left',
//     customRender: (data) => nameIconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.name < b.name) return -1; // asc
//         else if (a.name > b.name) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 2, // 정렬 우선순위
//     },
//   },
//   {
//     title: lang('main.co.status'), // 상태
//     dataIndex: 'podStatus',
//     customRender: (data) => iconTextRenderer(data),
//     width: 150,
//     sorter: {
//       compare: (a, b) => {
//         if (a.podStatus < b.podStatus) return -1; // asc
//         else if (a.podStatus > b.podStatus) return 1; // desc
//         else return 0; // default
//       },
//       multiple: 1, // 정렬 우선순위
//     },
//   },
//   {
//     title: `CPU ${lang('main.co.usage')}`, // CPU 사용량
//     dataIndex: 'cpuUsage',
//     customRender: (data) => textRenderer(data, 'mCore'),
//     width: 150,
//   },
//   {
//     title: `Memory ${lang('main.co.usage')}`, // Memory 사용량
//     dataIndex: 'memUsage',
//     customRender: (data) => bytesRenderer(data),
//     width: 150,
//   },
//   { title: lang('main.co.restart'), dataIndex: 'restartCnt', width: 100 }, // 재시작
//   {
//     title: 'Age',
//     dataIndex: 'startTime',
//     customRender: (data) => ageRenderer(data.value),
//     width: 100,
//   },
//   { title: lang('main.co.namespaceName'), dataIndex: 'namespace' }, // 네임스페이스 명
// ];

// 인스턴스 목록 (IaaS)
// export const instanceColumns: ColumnsType = [
//   {
//     title: 'Name',
//     dataIndex: 'name',
//     customRender: (data) => nameIconTextRenderer(data),
//     sorter: {
//       compare: (a, b) => {
//         if (a.name < b.name) return -1; // asc
//         else if (a.name > b.name) return 1; // desc
//         else return 0; // default
//       },
//     },
//   },
//   { title: 'Power State', dataIndex: 'powerState' },
//   { title: 'Raw Power State', dataIndex: 'rawPowerState' },
//   { title: 'Connection State', dataIndex: 'connectionstate' },
//   /*{ title: 'EMS ID', dataIndex: 'emsId' },*/
//   { title: 'Vendor', dataIndex: 'vendor' },
//   { title: 'State Changed On', dataIndex: 'stateChangedOn' },
// ];
