<!-- 
  메인 화면
  created by yoonsunsohn (2022-07-25)
 -->
<template>
  <div class="main-wrapper origin-main">
    <!-- main-content -->
    <div class="main-content">
      <!-- <span>main</span> -->
      <dashboardView />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onBeforeUnmount, onMounted } from 'vue';
import dashboardView from '@dashboard/DashboardView.vue';

onMounted(() => {
  // mount
});

onBeforeUnmount(() => {
  // unmount
});
</script>
