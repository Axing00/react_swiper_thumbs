<template>
  <div
    class="main-wrapper origin-main"
    :class="isCollapse ? 'collapse-active' : ''"
  >
    <!-- main-content -->
    <div class="main-content">
      <div class="tree-viewer-container">
        <div class="tree-viewer-inner beautiful-scroll">
          <div class="title-area">
            <p class="title">Tree Viewer</p>
            <p class="icon refresh">
              <button class="refresh-btn-v2"> </button>
            </p>
          </div>
          <div class="tree-view-area">
            <div class="q-pa-md q-gutter-sm">
              <q-tree
                v-model:selected="selectedKey"
                :nodes="simple"
                node-key="label"
                no-connectors
                icon="chevron_right"
              />
            </div>
          </div>
        </div>
      </div>
      <!--PaaS card-container -->
      <div v-if="isPaasCard" class="card-container">
        <div class="card-inner">
          <div class="title-area">
            <p class="title">Smart DX</p>
            <div class="icon-area">
              <span
                class="icon card-icon"
                :class="isCardIcon ? 'active' : 'nonactive'"
                @click="cardIcon()"
              ></span>
              <span
                class="icon table-icon"
                :class="isTableIcon ? 'active' : 'nonactive'"
                @click="cardIcon()"
              ></span>
              <button
                class="collapse-icon"
                :class="isCollapse ? 'active' : 'nonactive'"
                @click="collapseBtn()"
              >
              </button>
            </div>
          </div>
          <!-- card list -->
          <div class="card-list" :class="isCardList ? 'active' : 'nonactive'">
            <!-- 데이터 없을 때 -->
            <div v-if="isCardNodata" class="nodata-area">
              <span class="icon-nodata"></span>
              <span class="desc">No Data</span>
            </div>
            <!-- 데이터 있을 때  -->
            <div v-else>
              <p class="card-title">클러스터 목록</p>
              <ul class="beautiful-scroll">
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card error">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">1</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card error">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">1</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card error">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">1</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card">
                    <div class="util-area">
                      <p class="util-icon"></p>
                      <div class="view-icon">
                        <q-tooltip
                          anchor="center right"
                          self="top middle"
                          class="main-card-tooltip"
                        >
                          <div class="q-pb-xs">
                            노드 수 <span>0</span>/<span>2</span>
                          </div>
                          <div>노드 수 <span>5</span></div>
                        </q-tooltip>
                      </div>
                    </div>
                    <div class="title">tech3-cluster</div>
                    <div class="alarm-area">
                      <span class="alarm-icon"></span>
                      <span class="alarm-count">0</span>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <!--// card list  -->
          <!-- table list -->
          <div class="table-list" :class="isTableList ? 'active' : 'nonactive'">
            <!-- 데이터 없을 때 -->
            <div v-if="isTableNodata" class="nodata-area">
              <span class="icon-nodata"></span>
              <span class="desc">No Data</span>
            </div>
            <div v-else>
              <p class="card-title">클러스터 목록</p>
              <!-- 목록 정보 -->
              <data-table2
                :title="''"
                :columns="sampleColumns"
                :data="sampleDatas"
                class="beautiful-scroll"
              />
            </div>
          </div>

          <!--// chart list  -->
        </div>
      </div>
      <!--//PaaS card-container -->
      <!--Iaas card-container -->
      <div v-else class="card-container iaas-container">
        <div class="card-inner">
          <div class="title-area">
            <p class="title">SMART DX</p>
            <div class="icon-area">
              <!-- <span
                class="icon card-icon"
                :class="isCardIcon ? 'active' : 'nonactive'"
                @click="cardIcon()"
              ></span> -->
              <span class="icon table-icon active cursor-inherit"></span>
              <button
                class="collapse-icon"
                :class="isCollapse ? 'active' : 'nonactive'"
                @click="collapseBtn()"
              >
              </button>
            </div>
          </div>
          <p class="card-title">
            IaaS 상세 <span class="primary-color y-f20 y-ml10">B-1-mn3</span>
          </p>
          <!-- chart list -->
          <div class="table-list">
            <div class="table-container detail">
              <div>
                <div class="table-area beautiful-scroll">
                  <ul class="table-content">
                    <li>
                      <div class="content-wrap">
                        <table class="y-t-fixed">
                          <colgroup>
                            <col class="col-first" />
                            <col />
                            <col class="col-first" />
                            <col />
                          </colgroup>
                          <tr>
                            <th>Name</th>
                            <td colspan="3">B-1mn3</td>
                          </tr>
                          <tr>
                            <th>ID</th>
                            <td>45</td>
                            <th>Power State</th>
                            <td>unknown</td>
                          </tr>
                          <tr>
                            <th>Raw Power State</th>
                            <td>unknown</td>
                            <th>Connection State</th>
                            <td>unknown</td>
                          </tr>
                          <tr>
                            <th>EMS ID</th>
                            <td colspan="3">-</td>
                          </tr>
                          <tr>
                            <th>EMS ref</th>
                            <td colspan="3">
                              'abcd66b7-asd545-1564-fdgb4f5d-d4s58f4ds8sdfg4v5sdabcd66b7-asd545-1564-fdgb4f5d-d4s58f4ds8sdfg4v5sdabcd66b7'
                            </td>
                          </tr>
                          <tr>
                            <th>Type</th>
                            <td colspan="3">
                              'MnagelQ::Providers::Openstack::Vm'
                            </td>
                          </tr>
                          <tr>
                            <th>Vendor</th>
                            <td>openstack</td>
                            <th>State Changed On</th>
                            <td>2022-09-16T07:09:56Z</td>
                          </tr>
                          <tr>
                            <th>Created On</th>
                            <td>2022-09-16T07:09:56Z</td>
                            <th>Updated On</th>
                            <td>2022-09-16T07:09:56Z</td>
                          </tr>
                          <tr>
                            <th>Availability Zone ID</th>
                            <td>1</td>
                            <th>Template</th>
                            <td>false</td>
                          </tr>
                          <tr>
                            <th>Flavor ID</th>
                            <td>8</td>
                            <th>Host ID</th>
                            <td></td>
                          </tr>
                          <tr>
                            <th>Cloud Tenant ID</th>
                            <td>1</td>
                            <th>Cloud</th>
                            <td>true</td>
                          </tr>
                          <tr>
                            <th>Tenant ID</th>
                            <td colspan="3">2022-09-16T07:09:56Z</td>
                          </tr>
                          <tr>
                            <th>GUID</th>
                            <td colspan="3">
                              86139366-96ea-4739-9f01-6d2e524761d0
                            </td>
                          </tr>
                        </table>
                      </div>
                    </li>
                    <!--// table3 -->
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!--// chart list  -->
        </div>
      </div>
      <!--//Iaas card-container -->
      <div class="tree-detail-container beautiful-scroll">
        <div class="tree-detail-inner">
          <!-- chart area -->
          <div class="chart-container">
            <div class="title-area">
              <p class="title">CPU 유후 시간 평균 (%)</p>
              <div class="flex items-center">
                <!-- 자동 새로고침 토글 -->
                <q-toggle
                  v-model="isAutoRefresh"
                  label="자동 새로고침"
                  class="auto-new"
                  @update:model-value="onUpdateAutoRefresh"
                />
                <!-- <div><span></span>자동 새로고침</div> -->
                <span class="icon setting" @click="setting = true"></span>
                <q-dialog v-model="setting" persistent>
                  <q-card class="popup-container">
                    <div class="y-title-area">
                      <span class="title">View Edit</span>
                      <span v-close-popup class="close-btn"> </span>
                    </div>
                    <div class="content-container">
                      <div class="content-area radio beautiful-scroll">
                        <q-radio
                          v-model="shape"
                          val="line"
                          label="API 연결 (2분 , cps) / 다시 시작된 Pod 목록"
                        />
                        <q-radio
                          v-model="shape"
                          val="val1"
                          label="최소 여유 CPU 노드 / 최소 여유 디스크 노드"
                        />
                        <q-radio
                          v-model="shape"
                          val="val2"
                          label="최소 여유 메모리 노드 / API 서버 요청 (10분 평균)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val3"
                          label="다시 시작된 Pod 증가율 (2분)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val4"
                          label="CPU 시스템 부하 (코어 평균)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val5"
                          label="메모리 사용량 (GiB)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val6"
                          label="CPU 유후 시간 평균 (%)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val7"
                          label="디스크 사용량 (GiB)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val8"
                          label="디스크 I/O 속도"
                        />
                        <q-radio
                          v-model="shape"
                          val="val9"
                          label="메모리 사용 상위 Pod (GiB)"
                        />
                        <q-radio
                          v-model="shape"
                          val="val10"
                          label="CPU 사용 상위 컨테이너"
                        />
                        <q-radio
                          v-model="shape"
                          val="val11"
                          label="Pod 상태별 실행 수"
                        />
                        <q-radio
                          v-model="shape"
                          val="val12"
                          label="Pod 상태별 실행 수"
                        />
                        <q-radio
                          v-model="shape"
                          val="val13"
                          label="Pod 상태별 실행 수"
                        />
                      </div>
                    </div>
                  </q-card>
                </q-dialog>
              </div>
            </div>
            <!-- chart 높이는 임의로 설정해두었습니다. -->
            <div class="chart-area">
              <!-- chart 데이터 없을 때 -->
              <div v-if="isChartNodata" class="nodata-area">
                <span class="icon-nodata"></span>
                <span class="desc">No Data</span>
              </div>
              <div v-else class="chart-inner"> </div>
            </div>
          </div>
          <!-- alarm area -->
          <div class="alarm-container">
            <div class="title-area">
              <p class="title">Alarm</p>
              <p class="alarm-count">총 <span class="count">2</span> 건</p>
            </div>
            <div class="table-container">
              <!-- alarm 데이터 없을 때 -->
              <div v-if="isAlarmNodata" class="nodata-area">
                <span class="icon-nodata"></span>
                <span class="desc">No Data</span>
              </div>
              <div v-else>
                <data-table2
                  :title="''"
                  :columns="sampleColumns2"
                  :data="sampleDatas2"
                  class="beautiful-scroll"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- bottom eventview -->
    <div class="bottom-eventview-container">
      <!-- event view -->
      <div class="event-view-area">
        <div class="flex align-center justify-between">
          <div class="title">Current Alarm Viewer</div>
          <div class="txt count cursor-pointer" @click="openEventPopup('')">
            <span>{{ '총 ' + allCount + $t('common.label.count') }}</span>
          </div>
        </div>
        <div class="bottom">
          <div class="current-alarm-container">
            <div class="current-alarm-area">
              <div class="contents cr-area" @click="openEventPopup('critical')">
                <span class="label-area"></span>
                <span class="count-area">{{ criticalCount }}</span>
              </div>
              <div class="contents mj-area" @click="openEventPopup('major')">
                <span class="label-area"></span>
                <span class="count-area">{{ majorCount }}</span>
              </div>
              <div class="contents mn-area" @click="openEventPopup('minor')">
                <span class="label-area"></span>
                <span class="count-area">{{ minorCount }}</span>
              </div>
              <div class="contents wr-area" @click="openEventPopup('warning')">
                <span class="label-area"></span>
                <span class="count-area">{{ warningCount }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- event progress -->
      <div class="event-progress-area flex">
        <!-- CPU -->
        <div class="progress-inner flex cpu">
          <div class="title-area flex justify-between">
            <p class="flex align-center">
              <i class="icon"></i>
              <span class="progress-title">CPU</span>
            </p>
            <div class="progress-number flex">
              <p class="txt"><span>20</span>%</p>
            </div>
          </div>
          <div class="progress-chart">
            <span class="progress-percent" style="width: 20%"></span>
          </div>
        </div>
        <!-- MEMORY -->
        <div class="progress-inner flex memory">
          <!-- title -->
          <div class="title-area flex justify-between">
            <p class="flex align-center">
              <i class="icon"></i>
              <span class="progress-title">MEMORY</span>
            </p>
            <div class="progress-number flex">
              <p class="txt"><span>3.37</span></p>
              <p>&nbsp;/&nbsp;<span>7.78</span>GB</p>
            </div>
          </div>
          <!-- progress -->
          <div class="progress-chart">
            <span class="progress-percent" style="width: 43%"></span>
          </div>
        </div>
        <!-- STORAGE -->
        <div class="progress-inner flex storage">
          <!-- title -->
          <div class="title-area flex justify-between">
            <p class="flex align-center">
              <i class="icon"></i>
              <span class="progress-title">STORAGE</span>
            </p>
            <div class="progress-number flex">
              <p class="txt"><span>22.4</span></p>
              <p>&nbsp;/&nbsp;<span>177.0</span>GB</p>
            </div>
          </div>
          <!-- progress -->
          <div class="progress-chart">
            <span class="progress-percent" style="width: 13%"></span>
          </div>
        </div>
      </div>
      <!-- event point -->
      <div class="event-point-area flex">
        <!-- PaaS -->
        <div class="content flex pass">
          <div class="flex">
            <div class="event-title">Paas</div>
            <div class="event-card">
              <dl class="top flex">
                <dt class="txt">클러스터</dt>
                <dd class="count txt">1</dd>
              </dl>
              <div class="bottom flex">
                <p><i class="normal-icon"></i><span class="txt">1</span></p>
                <p><i class="unnormal-icon"></i><span class="txt">0</span></p>
              </div>
            </div>
          </div>
          <div class="event-card">
            <dl class="top flex">
              <dt class="txt">노드</dt>
              <dd class="count txt">6</dd>
            </dl>
            <div class="bottom flex">
              <p><i class="normal-icon"></i><span class="txt">1</span></p>
              <p><i class="unnormal-icon"></i><span class="txt">0</span></p>
            </div>
          </div>
          <div class="event-card">
            <dl class="top flex">
              <dt class="txt">파드</dt>
              <dd class="count txt">16</dd>
            </dl>
            <div class="bottom flex">
              <p><i class="normal-icon"></i><span class="txt">1</span></p>
              <p><i class="unnormal-icon"></i><span class="txt">0</span></p>
            </div>
          </div>
        </div>
        <!-- IaaS -->
        <div class="content flex iaas">
          <div class="event-title">IaaS</div>
          <div class="event-card">
            <dl class="top flex">
              <dt class="txt">인스턴스</dt>
              <dd class="count txt">1</dd>
            </dl>
            <div class="bottom flex">
              <p><i class="normal-icon"></i><span class="txt">1</span></p>
              <p><i class="unnormal-icon"></i><span class="txt">0</span></p>
            </div>
          </div>
        </div>
        <!-- SaaS -->
        <div class="content flex saas">
          <div class="event-title">SaaS</div>
          <div class="event-card">
            <dl class="top flex">
              <dt class="txt">전체</dt>
              <dd class="count txt">1</dd>
            </dl>
            <div class="bottom flex">
              <p><i class="normal-icon"></i><span class="txt">1</span></p>
              <p><i class="unnormal-icon"></i><span class="txt">0</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, h, onMounted } from 'vue';
import dayjs from 'dayjs';
import { router } from '@router';
import DataTable2 from '@components/DataTableComp2.vue';
import dialog from '@/components/dialog';
import EventViewerPopupView from '@main/components/EventViewerPopupView.vue';
import { lang } from '@config/langConfig';
// q-tree
const simple = [
  {
    clsss: 'smartdxxxx',
    label: 'Smart DX',
    img: '/ic_sdx_red.png',
    children: [
      {
        label: 'PaaS',
        children: [
          {
            img: '/ic_cloud_red.png',
            label: 'Cloud',
            children: [
              {
                img: '/ic_paas_red.png',
                label: 'tech3-cluster',
                children: [
                  {
                    img: '/ic_node_m_red.png',
                    label: '노드A',
                  },
                  {
                    img: '/ic_node_w_red.png',
                    label: '노드B',
                  },
                ],
              },
              {
                img: '/ic_ps-is_green.png',
                label: '클러스터C',
                children: [
                  {
                    img: '/ic_node_m_red.png',
                    label: '노드A',
                  },
                  {
                    img: '/ic_node_w_red.png',
                    label: '노드B',
                  },
                ],
              },
              {
                img: '/ic_ps-is_green.png',
                label: '클러스터D',
                children: [
                  {
                    img: '/ic_iaas.png',
                    label: '노드A',
                  },
                  {
                    img: '/ic_iaas.png',
                    label: '노드B',
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        label: 'IaaS',
        children: [
          {
            img: '/ic_sdx_green.png',
            label: '인스턴스A',
          },
          {
            img: '/ic_sdx_green.png',
            label: '인스턴스B',
          },
        ],
      },
    ],
  },
];

const sampleColumns = computed(() => {
  return [
    {
      title: '이름',
      dataIndex: 'name',
      // icon + link
      customRender: (data) => {
        return h(
          'fragment',
          { class: 'flex items-center no-wrap justify-center' },
          [
            h('i', {
              class: 'node-name-icon w', //추가 클래스 w or m에 따라 아이콘 변경 가능
              style: 'margin-right: 10px;',
            }),
            h('span', {
              innerHTML: data.value,
              onClick: () => {
                // TODO router param(상세정보 id) 추가
                const id = 1; // data.value.id;
                router.push({ name: 'TemplateInfoView', query: { id: id } });
              },
            }),
          ]
        );
      },
      sorter: {
        compare: (a, b) => {
          if (a.name < b.name) return -1; // asc
          else if (a.name > b.name) return 1; // desc
          else return 0; // default
        },
        multiple: 1, // 정렬 우선순위
      },
    },
    {
      title: 'IP',
      dataIndex: 'ip',
    },
    {
      title: '상태',
      dataIndex: 'status',
      align: 'center',
      // icon + text
      customRender: (data) => {
        const statusIocn =
          data.value === 'Ready' ? 'status-icon ready' : 'status-icon n-ready';
        return h('fragment', { class: 'flex items-center no-wrap' }, [
          h('i', {
            class: statusIocn,
            style: 'margin-right: 10px',
            innerHTML: '',
          }),
          h('text', {
            innerHTML: data.value,
            class: 'txt',
          }),
        ]);
      },
      sorter: {
        compare: (a, b) => {
          if (a.status < b.status) return -1; // asc
          else if (a.status > b.status) return 1; // desc
          else return 0; // default
        },
        multiple: 2, // 정렬 우선순위
      },
    },
    {
      title: 'CPU',
      children: [
        {
          title: '총량',
          dataIndex: 'cpu_total',
          align: 'center',
          // text
          customRender: (data) => {
            return `${data.value} Core`;
          },
        },
        {
          title: '요청량',
          dataIndex: 'cpu_request',
          align: 'center',
          customRender: (data) => {
            return `${data.value} Core`;
          },
        },
        {
          title: '사용량',
          dataIndex: 'cpu_usage',
          align: 'center',
          // progress (bar)
          customRender: (data) => {
            return `${data.value} Core`;
          },
        },
      ],
    },
    {
      title: 'Memory',
      children: [
        {
          title: '총량',
          dataIndex: 'memory_total',
          align: 'center',
          // text
          customRender: (data) => {
            return `${data.value} GB`;
          },
        },
        {
          title: '요청량',
          align: 'center',
          dataIndex: 'memory_request',
          // progress (bar)
          customRender: (data) => {
            return `${data.value} Core`;
          },
        },
        {
          title: '사용량',
          dataIndex: 'memory_usage',
          align: 'center',
          // progress (bar)
          customRender: (data) => {
            return `${data.value} Core`;
          },
        },
      ],
    },
    {
      title: 'Disk',
      children: [
        {
          title: '총량',
          dataIndex: 'disk_total',
          align: 'center',
          // text
          customRender: (data) => {
            return `${data.value} GB`;
          },
        },
        {
          title: '사용량',
          dataIndex: 'disk_usage',
          align: 'center',
          // text
          customRender: (data) => {
            return `${data.value} GB`;
          },
        },
      ],
    },
    {
      title: '인스턴스(Pod)',
      dataIndex: 'instance',
      align: 'center',
      // image + text
      customRender: (data) => {
        return h('fragment', [
          // h('img', {
          //   src: 'https://raw.githubusercontent.com/grafana/grafana/master/public/img/logo_transparent_400x.png',
          //   alt: 'Sample Image',
          //   style: 'height: 20px; margin-right: 5px;',
          // }),
          h('text', {
            innerHTML: data.value,
          }),
        ]);
      },
    },
    {
      title: 'iaasdetail',
      dataIndex: 'iaasdetail',
      align: 'center',
      // icon + text
      customRender: (data) => {
        return h('fragment', { class: 'flex items-center no-wrap' }, [
          h('i', {
            class: 'detail-iaas-icon',
            innerHTML: '',
          }),
          h('text', {
            innerHTML: data.value,
            class: 'txt',
          }),
        ]);
      },
    },
  ];
});

// DataTable 데이터
const sampleDatas = [
  {
    name: '노드A',
    ip: '192.168.60.211',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.5,
    cpu_usage: 0.8,
    memory_total: 15.6,
    memory_request: 1.6,
    memory_usage: 4.2,
    disk_total: 215.6,
    disk_usage: 129.3,
    instance: '16/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.212',
    status: 'Not Ready',
    cpu_total: 8,
    cpu_request: 2.2,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 2.7,
    memory_usage: 3.1,
    disk_total: 69.4,
    disk_usage: 36.8,
    instance: '16/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.213',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 3.9,
    cpu_usage: 0.6,
    memory_total: 15.6,
    memory_request: 5.0,
    memory_usage: 2.5,
    disk_total: 69.7,
    disk_usage: 35.9,
    instance: '20/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.214',
    status: 'Not Ready',
    cpu_total: 8,
    cpu_request: 3.5,
    cpu_usage: 0.6,
    memory_total: 15.6,
    memory_request: 3.7,
    memory_usage: 2.6,
    disk_total: 69.4,
    disk_usage: 38.5,
    instance: '16/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.215',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 1.4,
    cpu_usage: 0.3,
    memory_total: 15.6,
    memory_request: 1.3,
    memory_usage: 1.5,
    disk_total: 69.3,
    disk_usage: 34.9,
    instance: '15/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.216',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.0,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 3.7,
    memory_usage: 2.4,
    disk_total: 69.3,
    disk_usage: 41.2,
    instance: '15/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.211',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.5,
    cpu_usage: 0.8,
    memory_total: 15.6,
    memory_request: 1.6,
    memory_usage: 4.2,
    disk_total: 215.6,
    disk_usage: 129.3,
    instance: '16/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.212',
    status: 'Not Ready',
    cpu_total: 8,
    cpu_request: 2.2,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 2.7,
    memory_usage: 3.1,
    disk_total: 69.4,
    disk_usage: 36.8,
    instance: '16/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.215',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 1.4,
    cpu_usage: 0.3,
    memory_total: 15.6,
    memory_request: 1.3,
    memory_usage: 1.5,
    disk_total: 69.3,
    disk_usage: 34.9,
    instance: '15/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.216',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.0,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 3.7,
    memory_usage: 2.4,
    disk_total: 69.3,
    disk_usage: 41.2,
    instance: '15/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.216',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.0,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 3.7,
    memory_usage: 2.4,
    disk_total: 69.3,
    disk_usage: 41.2,
    instance: '15/110',
  },
  {
    name: '노드A',
    ip: '192.168.60.216',
    status: 'Ready',
    cpu_total: 8,
    cpu_request: 2.0,
    cpu_usage: 0.7,
    memory_total: 15.6,
    memory_request: 3.7,
    memory_usage: 2.4,
    disk_total: 69.3,
    disk_usage: 41.2,
    instance: '15/110',
  },
];

const sampleColumns2 = computed(() => {
  return [
    {
      title: '알림명',
      dataIndex: 'alarm_name',
    },
    {
      title: '심각도',
      dataIndex: 'status',
    },
    {
      title: '위치',
      dataIndex: 'location',
    },
    {
      title: '발생일시',
      dataIndex: 'time',
    },
  ];
});

// DataTable 데이터
const sampleDatas2 = [
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
  {
    alarm_name: 'Event Warning',
    status: 'Warning',
    location: 'K8s/클러스터A',
    time: '2022 - 08 - 15',
  },
];

// Datatable 페이지네이션 정의 (샘플)
const samplePagination = {
  position: ['bottomCenter'], // 페이지네이션 위치 (하단 중앙)
  hideOnSinglePage: true, // 1페이지만 존재할 경우 페이지네이션 숨김
  // pageSizeOptions: ['10', '20', '30', '40'], // 페이지 사이즈 변경 옵션
  // showSizeChanger: true, // 페이지 사이즈 변경 옵션 노출 여부
  // showQuickJumper: true, // 퀵 점퍼(페이지 번호로 이동) 노출 여부
  // showTotal: (total) => `Total ${total} items`, // 총 건수 표시
};

const props = defineProps({
  // 자동 새로고침 토글
  autoRefresh: {
    type: Boolean,
    required: false,
    default: false,
  },
  refreshTime: {
    type: Number,
    required: false,
    default: 60000,
  },
});

const emit = defineEmits([
  'update:input-value',
  'autoRefresh',
  'add',
  'clear',
  'detail-search',
  'refresh',
]);

// 자동 새로고침 시간
let refreshTimeText = ref(dayjs().format('YYYY-MM-DD hh:mm:ss'));

// 자동 새로고침 토글
const isAutoRefresh = ref(true);

let timer = ref(
  setInterval(() => {
    emit('autoRefresh');
    refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
  }, props.refreshTime)
);

// 자동 새로고침 토글 시 호출
const onUpdateAutoRefresh = (val: boolean) => {
  if (val) {
    timer.value = setInterval(() => {
      emit('autoRefresh');
      refreshTimeText.value = dayjs().format('YYYY-MM-DD hh:mm:ss');
    }, props.refreshTime);
  }
  if (!val && timer.value) {
    clearInterval(timer.value);
  }
};

// Selectbox 옵션 - 이름 (샘플)
const selectNameOptions = ref([
  {
    value: 'All',
    label: 'All',
  },
  {
    value: '유희관',
    label: '유희관',
  },
  {
    value: '이정구',
    label: '이정구',
  },
  {
    value: '손윤선',
    label: '손윤선',
  },
  {
    value: '박희준',
    label: '박희준',
  },
  {
    value: '황유선',
    label: '황유선',
  },
]);
// Selectbox 옵션 - 상태 (샘플)
const selectReadyOptions = ref([
  {
    value: 'All',
    label: 'All',
  },
  {
    value: 'Not Ready',
    label: 'Not Ready',
  },
  {
    value: 'Ready',
    label: 'Ready',
  },
]);

// Input 필터 정보 (샘플)
// const inputFilter = 'name'; // 컬럼 필드
const inputFilter = 'user_name'; // 컬럼 필드

// Selectbox 필터 배열 정보 (샘플)
const selectFilterArr = [
  {
    column: 'user_name', // 컬럼 필드
    selectOptions: selectNameOptions.value, // Selectbox 옵션
  },
  {
    column: 'status', // 컬럼 필드
    selectOptions: selectReadyOptions.value, // Selectbox 옵션
  },
  {
    column: 'status', // 컬럼 필드
    selectOptions: selectReadyOptions.value, // Selectbox 옵션
  },
  {
    column: 'status', // 컬럼 필드
    selectOptions: selectReadyOptions.value, // Selectbox 옵션
  },
];

interface SelectBox {
  options: {
    label: string;
    value: string | number | null;
    description: string | null;
  }[];
  select: {
    label: string;
    value: string | number | null;
    description: string | null;
  };
  error: boolean;
  errorMessage: string;
}

// card, table toggle
let isCardIcon = ref<boolean>(true);
let isCardList = ref<boolean>(true);
let isTableIcon = ref<boolean>(false);
let isTableList = ref<boolean>(false);
//collapse
let isCollapse = ref<boolean>(false);

//card container pass or iaas
let isPaasCard = ref<boolean>(true);

// 선택된 노드 키 (색상 표시)
let selectedKey = ref<string>('');

//모달창 관련
const setting = ref<boolean>(false);

// radio button
let shape = ref<string>('line');
const alarmStore = '';

const allCount = ref<number>();
const warningCount = ref<number>();
const minorCount = ref<number>(0);
const majorCount = ref<number>(0);
const criticalCount = ref<number>();

// 데이터 없을 때
const isCardNodata = ref<boolean>(true);
const isTableNodata = ref<boolean>(false);
const isChartNodata = ref<boolean>(false);
const isAlarmNodata = ref<boolean>(false);

function cardIcon() {
  if (isCardIcon.value) {
    isCardIcon.value = false;
    isCardList.value = false;
    isTableIcon.value = true;
    isTableList.value = true;
  } else {
    isCardIcon.value = true;
    isCardList.value = true;
    isTableIcon.value = false;
    isTableList.value = false;
  }
}

function collapseBtn() {
  if (isCollapse.value) {
    isCollapse.value = false;
  } else {
    isCollapse.value = true;
  }
}

const openEventPopup = (type) => {
  console.log(type);
  let param = {
    type: type,
    title: lang('event.cu.title'),
  };
  dialog
    .open({
      component: EventViewerPopupView,
      componentProps: param,
    })
    .onOk(async (result) => {
      console.log('onOk');
    })
    .onCancel(() => {
      console.log('cancel!!!');
    });
};

function setSummary(data) {
  allCount.value = Number(data.summary.totalCount);
  warningCount.value = Number(data.summary.warningCount);
  criticalCount.value = Number(data.summary.criticalCount);
}

async function getCurrentAlarm() {
  let params = {
    searchAll: '',
    start: '',
    end: '',
    alarmName: '',
    severity: '',
    pageNumber: '1',
    pageSize: '10',
  };

  // let alarmInfo = await alarmStore.selectCurrentAlarm(params);
  // await setSummary(alarmInfo);
}

// 해당 라이프 사이클시 동작하는 메소드 (사용 안하면 삭제)
onMounted(async () => {
  try {
    await getCurrentAlarm();
  } catch (err) {
    // console.log(err);
  }
});
</script>
<style></style>
