<!-- 
  메인 화면 > 현재 알람 영역 - 현재 알람 팝업
  created by hkyoo (2022-10-25)
 -->
<template>
  <default-dialog
    ref="dialogRef"
    persistent
    medium
    :title="title"
    @ok="clickOkBtn"
  >
    <template #body>
      <!-- 그룹명 -->
      <div class="popup-table-top">
        <!-- warning evnet case -->
        <div
          v-if="type != ''"
          class="warning-event flex items-center justify-between txt"
        >
          <div class="flex items-center">
            <span :class="['alarm', alarmClass]"></span>
            <span class="title">{{ alarmType }}</span>
            <span class="count">{{
              alarmCount + ' ' + $t('common.label.count')
            }}</span>
          </div>
          <q-input
            ref="keywordRef"
            v-model="searchInput"
            :placeholder="lang('event.cu.table.name')"
            :maxlength="50"
            outlined
            class="y-search"
            @update:model-value="updateTable('update')"
          >
            <template #prepend>
              <q-icon name="search" />
            </template>
            <template #append>
              <q-icon
                name="close"
                class="cursor-pointer"
                @click="updateTable('clear')"
              />
            </template>
          </q-input>
        </div>
        <!-- 전체 case-->
        <div v-else class="total-event flex items-center txt">
          <div class="flex items-center">
            <span class="alarm"></span>
            <span class="title">{{ alarmType }}</span>
            <span class="count">{{
              alarmCount + ' ' + $t('common.label.count')
            }}</span>
          </div>
          <q-input
            ref="keywordRef"
            v-model="searchInput"
            :placeholder="lang('event.cu.table.name')"
            :maxlength="50"
            outlined
            class="y-search"
            @update:model-value="updateTable('update')"
          >
            <template #prepend>
              <q-icon name="search" />
            </template>
            <template #append>
              <q-icon
                name="close"
                class="cursor-pointer"
                @click="updateTable('clear')"
              />
            </template>
          </q-input>
        </div>
      </div>
      <div>
        <data-table2 :columns="columns" :data="filteredData" />
      </div>
    </template>
  </default-dialog>
</template>

<script lang="ts" setup>
// ↑ lang과 setup 꼭 명시하기
import { ref, h, computed, onMounted } from 'vue';
import { lang } from '@config/langConfig';
import { QDialog } from 'quasar';
import DefaultDialog from '@components/dialog/DefaultDialog.vue';
import DataTable2 from '@components/DataTableComp2.vue';
import filter from 'lodash-es/filter';
import setClass from '@/views/page/main/data/columnDefinition';
import cloneDeep from 'lodash-es/cloneDeep';

interface DataItem {
  key: number;
  alarmId: string;
  alarmKey: string;
  alarmName: string;
  cleared: boolean;
  cluster: string;
  container: string;
  description: string;
  end: string;
  namespace: string;
  pod: string;
  receivedAt: string;
  resources: string;
  severity: string;
  start: string;
  status: string;
  workload: string;
}

const tableData = ref<DataItem[]>([]);
const dialogRef = ref(QDialog);
const emit = defineEmits(['ok', 'cancel']);
const total = ref<number>(0);
const alarmType = ref<string>('');
const alarmCount = ref<number>(0);
const alarmClass = ref<string>('');
// Input 필터 입력값
const searchInput = ref<string>('');
// 테이블에 표시할 필터된 데이터
const filteredData = ref<DataItem[]>([]);
// Input 필터 ref(한글 필터링을 위해 사용)
const keywordRef = ref();

const props = defineProps({
  // 타이틀
  title: {
    type: String,
    default: '',
    required: false,
  },
  // 알람 심각도 타입(critical/major/minor/warning/''(총))
  type: {
    type: String,
    default: '',
    required: false,
  },
  // 현재 알람 정보
  alaramInfo: {
    type: Object,
    default: () => {
      return {};
    },
    required: true,
  },
  // 현재 알람 전체 리스트
  eventList: {
    type: Array,
    default: () => {
      return [];
    },
    required: true,
  },
});

const columns = computed(() => {
  return [
    {
      title: lang('event.cu.table.name'),
      dataIndex: 'alarmName',
      key: 'alarmName',
      align: 'left',
      customRender: (data) => {
        return h('text', {
          value: data.record.alarmName,
          innerHTML: `${data.record.alarmName}`,
          title: `${data.record.alarmName}`,
        });
      },
    },
    {
      title: lang('event.cu.table.severity'),
      dataIndex: 'severity',
      key: 'severity',
      align: 'left',
      customRender: (data) => {
        return h('fragment', [
          h('div', {
            innerHTML: data.value,
            class:
              data.record.cleared == 1
                ? 'alarm-bage clear'
                : data.value == 'critical'
                ? 'alarm-bage critical'
                : data.value == 'major'
                ? 'alarm-bage major'
                : data.value == 'minor'
                ? 'alarm-bage minor'
                : data.value == 'warning'
                ? 'alarm-bage warning'
                : '',
          }),
        ]);
      },
    },
    {
      title: lang('event.cu.table.position'),
      dataIndex: 'pod',
      key: 'pod',
      align: 'left',
      width: '40%',
      customRender: (data) => {
        return h('text', {
          value: data.record.pod,
          innerHTML: `${data.record.pod}`,
          title: `${data.record.pod}`,
        });
      },
    },
    {
      title: lang('event.cu.table.occurrenceTime'),
      dataIndex: 'receivedAt',
      key: 'receivedAt',
      align: 'left',
    },
  ];
});

function clickOkBtn() {
  emit('ok');
  dialogRef.value.hide();
}

function makeAlarmList(alarmList) {
  tableData.value = [];
  filteredData.value = [];

  let obj = {
    key: 0,
    alarmId: '',
    alarmKey: '',
    alarmName: '',
    cleared: false,
    cluster: '',
    container: '',
    description: '',
    end: '',
    namespace: '',
    pod: '',
    receivedAt: '',
    resources: '',
    severity: '',
    start: '',
    status: '',
    workload: '',
  };

  const severityAlarmList = filter(alarmList, (alarm) => {
    return props.type === '' ? true : alarm.severity === props.type;
  });

  let alarmListData: DataItem[] = [];

  if (severityAlarmList.length > 0) {
    severityAlarmList.forEach((item, index) => {
      obj = {
        key: 0,
        alarmId: '',
        alarmKey: '',
        alarmName: '',
        cleared: false,
        cluster: '',
        container: '',
        description: '',
        end: '',
        namespace: '',
        pod: '',
        receivedAt: '',
        resources: '',
        severity: '',
        start: '',
        status: '',
        workload: '',
      };
      obj.key = index + 1;
      obj.alarmId = item.alarmId;
      obj.alarmKey = item.alarmKey;
      obj.alarmName = item.alarmName;
      obj.cleared = item.cleared;
      obj.cluster = item.cluster;
      obj.container = item.container;
      obj.description = item.description;
      obj.end = item.end;
      obj.namespace = item.namespace;
      obj.pod =
        item.cloudName != '' &&
        item.clusterName != '' &&
        item.node != '' &&
        item.pod != ''
          ? '/' +
            item.cloudName +
            '/' +
            item.clusterName +
            '/' +
            item.node +
            '/' +
            item.pod
          : item.cloudName != '' && item.clusterName != '' && item.node != ''
          ? '/' + item.cloudName + '/' + item.clusterName + '/' + item.node
          : item.cloudName != '' && item.clusterName != ''
          ? '/' + item.cloudName + '/' + item.clusterName
          : item.cloudName != ''
          ? '/' + item.cloudName
          : '';
      obj.receivedAt = item.receivedAt;
      obj.resources = item.resources;
      obj.severity = item.severity;
      obj.start = item.start;
      obj.status = item.status;
      obj.workload = item.workload;
      alarmListData.push(obj);
    });
    tableData.value = alarmListData;
    filteredData.value = alarmListData;
  }
}

async function getCurrentAlarm() {
  let alarmInfo = cloneDeep(props.alaramInfo);
  await setSummary(alarmInfo);
  await makeAlarmList(props.eventList);
}

function setSummary(data) {
  total.value = Number(data.summary?.noPagingCount);
  alarmCount.value =
    props.type == 'critical'
      ? Number(data.summary?.criticalCount)
      : props.type == 'major'
      ? 0
      : props.type == 'minor'
      ? 0
      : props.type == 'warning'
      ? Number(data.summary?.warningCount)
      : Number(data.summary?.totalCount);
}

function setAlarmType() {
  alarmType.value =
    props.type == 'critical'
      ? 'Critical'
      : props.type == 'major'
      ? 'Major'
      : props.type == 'minor'
      ? 'Minor'
      : props.type == 'warning'
      ? 'Warning'
      : 'Total';

  alarmClass.value =
    props.type == 'critical'
      ? 'critical'
      : props.type == 'major'
      ? 'major'
      : props.type == 'minor'
      ? 'minor'
      : 'warning';
}

// 알람 목록 필터 검색시 테이블 업데이트
function updateTable(type) {
  const filterType = 'alarmName';
  if (type == 'clear') {
    searchInput.value = '';
  }
  const filtered = tableData.value.filter((d: DataItem) => {
    // Input 필터 조건
    const inputFilterCondition = filterType
      ? d[filterType].toString().includes(searchInput.value)
      : true;
    return inputFilterCondition;
  });
  filteredData.value = filtered;
}

onMounted(async () => {
  await setAlarmType();
  await getCurrentAlarm();
  // 알람 검색 한글
  const el = keywordRef.value.getNativeElement();
  el.addEventListener('input', (e) => {
    searchInput.value = e.target.value;
    updateTable('update');
  });
  setClass('table-type');
});
</script>
