<!-- 
  메인 화면 > 테이블 형태 Contents 영역 - IaaS 상세 정보 팝업
  created by yoonsunsohn (2022-08-03)
 -->
<template>
  <default-dialog
    ref="dialogRef"
    :title="title"
    @ok="onOKClick"
    @cancel="onCancelClick"
  >
    <template #body>
      <div>
        <data-table :columns="instanceColumns" :data="iaasDetailData" />
      </div>
    </template>
  </default-dialog>
</template>

<script setup lang="ts">
import DefaultDialog from '@components/dialog/DefaultDialog.vue';
import { ref, computed } from 'vue';
import { QDialog } from 'quasar';
import DataTable from '@/components/DataTableComp2.vue';
import { instanceColumns } from '@/views/page/main/data/columnDefinition';

const props = defineProps({
  // 타이틀
  title: {
    type: String,
    default: '',
    required: false,
  },
  iaasInfo: {
    type: Object,
    default: () => {
      return {};
    },
    required: true,
  },
});

const iaasDetailData = computed(() => {
  return [props.iaasInfo];
});

const dialogRef = ref(QDialog);

const emit = defineEmits(['ok', 'cancel']);
function onOKClick() {
  emit('ok', { type: 'ok' });
  dialogRef.value.hide();
}

function onCancelClick() {
  emit('cancel');
}
</script>
