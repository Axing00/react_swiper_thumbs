<!-- 
  메인 화면 > 선택한 트리 아이템(하위 포함)에 해당하는 현재 알람 영역
  created by yoonsunsohn (2022-10-19)
 -->
<template>
  <div class="alarm-container">
    <div class="title-area">
      <p class="title">
        <!--
          알람 ([아이템 이름])
          ex) 알람 (cloud-a)
              알람 (a-1-mn1)
        -->
        {{ lang('main.co.alarm') }}
        (
        <span class="desc-title">{{ selectedInfo.name }}</span>
        )
        <q-tooltip anchor="bottom middle" self="top middle" :offset="[0, 0]">
          {{ selectedInfo.name }}
        </q-tooltip>
      </p>
      <p class="alarm-count">
        <!-- 총 x 건 -->
        {{ lang('common.label.total') }}
        <span class="count">{{ currentEventArr.length }}</span>
        {{ lang('common.label.count') }}
      </p>
    </div>
    <div class="table-container">
      <data-table
        :title="''"
        :columns="eventListColumns"
        :data="currentEventArr"
        :pagination="{
          position: ['bottomCenter'], // 페이지네이션 위치 (하단 중앙)
          hideOnSinglePage: true, // 1페이지만 존재할 경우 페이지네이션 숨김
          showSizeChanger: false, // 페이지 사이즈 변경 옵션 노출 여부
        }"
      />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, h } from 'vue';
import DataTable from '@/components/DataTableComp2.vue';
import { lang } from '@config/langConfig';
import filter from 'lodash-es/filter';

const props = defineProps({
  // 트리 뷰어 영역의 선택된 트리 아이템
  selectedNode: {
    type: Object,
    required: true,
    default: () => {
      return {};
    },
  },
  // 현재 알람 정보
  eventList: {
    type: Array,
    default: () => {
      return [];
    },
    required: true,
  },
});

// 현재 선택된 아이템 정보
const selectedInfo = computed(() => {
  // 선택된 아이템 (트리)
  const selectedItem = props.selectedNode;

  let title = lang('common.label.all'); // 알람 영역 상단 타이틀에 노출되는 선택된 아이템 타입(전체/클라우드/클러스터/노드/파드)
  if (selectedItem.type === 'cloud') {
    title = lang('main.co.cloud'); // 클라우드
  } else if (
    selectedItem.type === 'PaaS' ||
    selectedItem.type === 'IaaS/PaaS'
  ) {
    title = lang('main.co.cluster'); // 클러스터
  } else if (selectedItem.type === 'Master' || selectedItem.type === 'Worker') {
    title = lang('main.co.node'); // 노드
  } else if (selectedItem.type === 'pod') {
    title = lang('main.co.pod'); // 파드
  }

  return {
    title: title,
    name: selectedItem.label,
  };
});

// 현재 알람 위치 컬럼 셋팅
const getAlarmPosition = (record) => {
  const position =
    record.cloudName != '' &&
    record.clusterName != '' &&
    record.node != '' &&
    record.pod != ''
      ? '/' +
        record.cloudName +
        '/' +
        record.clusterName +
        '/' +
        record.node +
        '/' +
        record.pod
      : record.cloudName != '' && record.clusterName != '' && record.node != ''
      ? '/' + record.cloudName + '/' + record.clusterName + '/' + record.node
      : record.cloudName != '' && record.clusterName != ''
      ? '/' + record.cloudName + '/' + record.clusterName
      : record.cloudName != ''
      ? '/' + record.cloudName
      : '';

  return position;
};

// 현재 알람 목록 컬럼
const eventListColumns = computed(() => {
  return [
    {
      title: lang('event.cu.table.name'),
      dataIndex: 'alarmName',
      align: 'center',
      customRender: (data) => {
        return h('text', {
          innerHTML: data.value,
          title: data.value,
        });
      },
    },
    {
      title: lang('event.cu.table.severity'),
      dataIndex: 'severity',
      align: 'center',
      customRender: (data) => {
        return h('fragment', [
          h('div', {
            innerHTML: data.value,
            class:
              data.record.cleared == 1
                ? 'alarm-bage clear'
                : data.value == 'critical'
                ? 'alarm-bage critical'
                : data.value == 'major'
                ? 'alarm-bage major'
                : data.value == 'minor'
                ? 'alarm-bage minor'
                : data.value == 'warning'
                ? 'alarm-bage warning'
                : '',
          }),
        ]);
      },
    },
    {
      title: lang('event.cu.table.position'),
      dataIndex: 'pod',
      align: 'center',
      customRender: (data) => {
        return h('text', {
          innerHTML: getAlarmPosition(data.record),
          title: getAlarmPosition(data.record),
        });
      },
    },
    {
      title: lang('event.cu.table.occurrenceTime'),
      dataIndex: 'receivedAt',
      align: 'center',
    },
  ];
});

// PaaS/IaaS일 경우는 자식이 있어야만, 클라우드/클러스터/노드는 전부
const depth0Condition = computed(() => {
  return (
    !!props.selectedNode.children && props.selectedNode.children.length > 0
  );
});
const etcCondition = computed(() => {
  return props.selectedNode.depth > 0;
});

// 현재 알람 목록 필터링된 데이터
const currentEventArr = computed(() => {
  const initCondition = depth0Condition.value || etcCondition.value;
  if (initCondition) {
    const itemType =
      props.selectedNode.type === 'PaaS_TOP'
        ? '' // PaaS(PaaS_TOP) 선택 시 전체 이벤트 노출되어야 함
        : props.selectedNode.type === 'cloud'
        ? 'cloudName'
        : props.selectedNode.type === 'PaaS' ||
          props.selectedNode.type === 'IaaS/PaaS'
        ? 'clusterName'
        : props.selectedNode.type === 'Master' ||
          props.selectedNode.type === 'Worker'
        ? 'node'
        : props.selectedNode.type === 'pod'
        ? 'pod'
        : '';

    return filter(props.eventList, (event) => {
      return itemType === ''
        ? true
        : event[itemType] === props.selectedNode.label;
    });
  } else {
    return [];
  }
});
</script>
