<template>
  <div class="main-wrapper user-management-container">
    <q-page padding class="main-container user-info-area">
      <div class="table-type-content">
        <div class="list">
          <!-- 타이틀 <START> -->
          <div class="list__title-area">
            <div> {{ title }} </div>
          </div>
          <!-- 타이틀 <END> -->
          <!-- 탭 <START> -->
          <div id="q-app">
            <div class="q-pa-md">
              <div class="q-gutter-y-md">
                <q-card>
                  <q-tabs
                    v-model="tab"
                    dense
                    class="text-grey"
                    active-color="primary"
                    indicator-color="primary"
                    align="justify"
                    narrow-indicator
                  >
                    <q-tab name="mails" label="메일" />
                    <q-tab name="alarms" label="알림" />
                  </q-tabs>

                  <q-separator />

                  <q-tab-panels v-model="tab" animated>
                    <q-tab-panel name="mails">
                      <!-- 메일 검색 <START> -->
                      <div class="q-pa-md">
                        <div
                          class="q-gutter-y-md column"
                          style="max-width: 300px"
                        >
                          <q-input
                            v-model="inputSearchText.inputValue"
                            filled
                            class="bg-blue-grey-4"
                          >
                            <template #append>
                              <q-icon
                                v-if="inputSearchText.inputValue !== ''"
                                name="close"
                                class="cursor-pointer"
                                @click="inputSearchText.inputValue = ''"
                              />
                              <q-icon name="search" />
                            </template>
                          </q-input>
                        </div>
                      </div>
                      <!-- 메일 검색 <END> -->
                      <!-- 메일 테이블 <START> -->
                      <div class="list__content-area">
                        <div class="table-area">
                          <q-table
                            v-model:selected="selected"
                            v-model:pagination="pagination"
                            class="my-sticky-virtscroll-table"
                            :rows="mailList"
                            :columns="tableColumns"
                            :visible-columns="visibleColumns"
                            :rows-per-page-options="[0]"
                            :virtual-scroll-sticky-size-start="48"
                            row-key="id"
                            selection="multiple"
                            virtual-scroll
                          />
                        </div>
                      </div>
                      <!-- 메일 테이블 <END> -->
                    </q-tab-panel>

                    <q-tab-panel name="alarms">
                      <!-- 알림 검색 <START> -->
                      <div class="q-pa-md">
                        <div
                          class="q-gutter-y-md column"
                          style="max-width: 300px"
                        >
                          <q-input
                            v-model="inputSearchText.inputValue"
                            filled
                            class="bg-blue-grey-4"
                          >
                            <template #append>
                              <q-icon
                                v-if="inputSearchText.inputValue !== ''"
                                name="close"
                                class="cursor-pointer"
                                @click="inputSearchText.inputValue = ''"
                              />
                              <q-icon name="search" />
                            </template>
                          </q-input>
                        </div>
                      </div>
                      <!-- 알림 검색 <END> -->
                      <!-- 알림 테이블 <START> -->
                      <div class="list__content-area">
                        <div class="table-area">
                          <q-table
                            v-model:selected="selected"
                            v-model:pagination="pagination"
                            class="my-sticky-virtscroll-table"
                            :rows="alertList"
                            :columns="tableColumns"
                            :visible-columns="visibleColumns"
                            :rows-per-page-options="[0]"
                            :virtual-scroll-sticky-size-start="48"
                            row-key="id"
                            selection="multiple"
                            virtual-scroll
                          />
                        </div>
                      </div>
                      <!-- 알림 테이블 <END> -->
                    </q-tab-panel>
                  </q-tab-panels>
                </q-card>
              </div>
            </div>
          </div>
          <!-- 탭 <END> -->
        </div>
      </div>
    </q-page>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { QTableProps } from 'quasar';

interface selectedValueVO {
  id: number;
  login_id: string;
  name: string;
  privilege: string | number;
  email: string;
  created_time: Date | string;
  latest_login_time: Date | string;
}

// input 객체 interface
interface Input {
  inputValue: string | number | null; // value
  disable?: boolean; // 사용 가능 여부
  errorMessage: string; // 에러발생시 메세지
  placeholder?: string; //placeholder
  error?: boolean; // 에러 여부
  theme?: string; // 테마
  readonly?: boolean; // 읽기 전용 여부
  maxlength?: number; // 최대 길이 지정
  type: 'text' | 'textarea' | 'search' | 'password'; // text, textarea, search,  타입 가능 (이후 추가 필요시 내용 변경 필요)
}

const tab = ref('mails');
const title = ref('메일 이력 관리');
const selected = ref<selectedValueVO[]>([]);
const required = ref<string>('검색할 항목 / 단어를 입력해주세요');

// 검색 input object
const inputSearchText = ref<Input>({
  inputValue: '',
  error: false,
  errorMessage: required.value,
  readonly: false,
  disable: false,
  type: 'text',
  theme: '',
});

// 테이블 공통 - 컬럼 전체
const tableColumns: QTableProps['columns'] = [
  {
    name: 'alertId',
    label: '아이디',
    field: 'id',
  },
  {
    name: 'alertType',
    label: '종류',
    field: 'type',
    style: 'width: 10%',
  },
  {
    name: 'senderName',
    label: '보낸사람',
    field: 'name',
    style: 'width: 10%',
  },
  {
    name: 'senderEmail',
    label: '이메일',
    field: 'email',
    style: 'width: 15%',
  },
  {
    name: 'alertTitle',
    label: '제목',
    field: 'title',
    style: 'width: 40%',
  },
  {
    name: 'receivedDate',
    label: '수신일',
    field: 'date',
    style: 'width: 15%',
  },
  {
    name: 'buttonArea',
    label: '',
    field: 'buttonArea',
    style: 'width: 10%',
  },
];

// 테이블 공통 - 보이는 컬럼
const visibleColumns: Array<string> = [
  'alertType',
  'senderName',
  'senderEmail',
  'alertTitle',
  'receivedDate',
  'buttonArea',
];

// 메일 데이터
let mailList = ref([
  {
    id: 1,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    title: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 2,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 3,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 4,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 5,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    title: '새로운 VOC가 등록되었습니다.',
    date: '2023-09-27',
  },
  {
    id: 6,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    title: '계정 신규 신청 내용입니다.',
    date: '2023-10-04',
  },
  {
    id: 7,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-10-04',
  },
  {
    id: 8,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-10-04',
  },
  {
    id: 9,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    title: '라이선스 초과 사용 중입니다.',
    date: '2023-10-04',
  },
  {
    id: 10,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    title: '새로운 VOC가 등록되었습니다.',
    date: '2023-10-04',
  },
]);

// 알림 데이터
let alertList = ref([
  {
    id: 111,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 112,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 113,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 114,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 115,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '새로운 VOC가 등록되었습니다.',
    date: '2023-09-27',
  },
  {
    id: 116,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 117,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 118,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 119,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 120,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '새로운 VOC가 등록되었습니다.',
    date: '2023-09-27',
  },
  {
    id: 121,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 122,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 123,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 124,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 125,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '새로운 VOC가 등록되었습니다.',
    date: '2023-09-27',
  },
  {
    id: 126,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 127,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 128,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 129,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 130,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '새로운 VOC가 등록되었습니다.',
    date: '2023-09-27',
  },
  {
    id: 131,
    type: '계정',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '계정 신규 신청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 132,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 신규 발급 요청 내용입니다.',
    date: '2023-09-27',
  },
  {
    id: 133,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '30일 뒤에 라이선스가 만료됩니다.',
    date: '2023-09-27',
  },
  {
    id: 134,
    type: '라이선스',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '라이선스 초과 사용 중입니다.',
    date: '2023-09-27',
  },
  {
    id: 135,
    type: 'VOC',
    name: '사용자',
    email: 'envkt@example.com',
    detail: '새로운 VOC가 등록되었습니다.',
    date: '2023-10-04',
  },
]);

const pagination = ref({
  sortBy: 'receivedDate',
  descending: true,
  // page: 1,
  rowsPerPage: 0,

  // rowsNumber: xx if getting data from a server
});
</script>
