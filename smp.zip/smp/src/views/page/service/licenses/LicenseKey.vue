<template>
  <div class="main-wrapper">
    <q-page padding class="main-container licenseKey-container">
      <!-- <BreadCrumbs :title="title" /> -->
      <div class="table-type-content" style="border: 1px solid red">
        <!-- 개별 software -->
        <div class="list y-mb20">
          <div class="list__content-area">
            <div class="software-detail y-f25">
              <span class="software-img">
                <img src="@assets/images/ic_dashboard_1.png" />
              </span>
              <span class="software-txt"> 소프트웨어 이름 </span>
            </div>
            <div class="software-detail">
              <span class="software-img"></span>
              <span class="software-txt"> 소프트웨어 설명 1 </span>
            </div>
            <div class="software-detail">
              <span class="software-img"></span>
              <span class="software-txt">
                소프트웨어 설명 2 소프트웨어 설명 2 소프트웨어 설명 2 소프트웨어
                설명 2 소프트웨어 설명 2 소프트웨어 설명 2 소프트웨어 설명 2
                소프트웨어 설명 2 소프트웨어 설명 2
              </span>
            </div>
            <q-expansion-item
              expand-separator
              icon="reorder"
              label="software licenses list"
            >
              <div class="q-pa-md">
                <q-table
                  v-model:pagination="pagination"
                  style="height: 300px"
                  flat
                  bordered
                  :rows="licenseList"
                  :column="licenseColumns"
                  row-key="index"
                  :sortable="false"
                />
              </div>
              <div class="q-pa-lg flex flex-center">
                <!-- pagination max는 계산해서 적용 -->
                <q-pagination
                  v-model="pagination.page"
                  :max="2"
                  direction-links
                  boundary-links
                  icon-first="skip_previous"
                  icon-last="skip_next"
                  icon-prev="fast_rewind"
                  icon-next="fast_forward"
                  :ellipses="true"
                />
              </div>
            </q-expansion-item>
          </div>
        </div>
        <!-- -------------------- -->
        <div class="list y-mb20">
          <div class="list__content-area">
            <q-expansion-item expand-separator icon="reorder" />
          </div>
        </div>
      </div>
    </q-page>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { onMounted } from 'vue';
import { httpHelperV2 } from '@/utils/httpHelperV2';

const pagination = ref({
  sortBy: 'licenseName',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});

const licenseColumns = [
  {
    name: 'licenseNo',
    required: true,
    label: 'NO',
    field: 'no',
  },
  {
    name: 'licenseName',
    required: true,
    label: 'name',
    field: (row) => row.name,
    format: (val) => `${val}`,
    sortable: false,
  },
  {
    name: 'calories',
    align: 'center',
    label: 'Calories',
    field: 'calories',
  },
  { name: 'fat', label: 'Fat (g)', field: 'fat' },
  { name: 'carbs', label: 'Carbs (g)', field: 'carbs' },
];

const licenseList = [
  {
    no: 0,
    'license name': 'Frozen Yogurt',
    calories: 159,
    fat: 6.0,
    carbs: 24,
  },
  {
    no: 1,
    'license name': 'Ice cream sandwich',
    calories: 237,
    fat: 9.0,
    carbs: 37,
  },
  {
    no: 2,
    'license name': 'Eclair',
    calories: 262,
    fat: 16.0,
    carbs: 23,
  },
  {
    no: 3,
    'license name': 'Cupcake',
    calories: 305,
    fat: 3.7,
    carbs: 67,
  },
  {
    no: 4,
    'license name': 'Gingerbread',
    calories: 356,
    fat: 16.0,
    carbs: 49,
  },
  {
    no: 5,
    'license name': 'Jelly bean',
    calories: 375,
    fat: 0.0,
    carbs: 94,
  },
  {
    no: 6,
    'license name': 'Lollipop',
    calories: 392,
    fat: 0.2,
    carbs: 98,
  },
];

onMounted(async () => {
  const res = await httpHelperV2().get('/v1/dashboard/entries-top');

  console.log(res);
});
</script>
