<template>
  <div class="not-found-page relative-position">
    <div class="not-found--inner absolute-center text-center">
      <p class="m-title txt y-mb5">Error Not Found</p>
      <p class="s-title txt y-mb30">{{ $t('common.404.notFound') }}</p>
      <q-btn class="y-btn primary" @click="gotoLoginPage()">
        {{ $t('common.404.moveToLogin') }}
      </q-btn>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { loadTheme } from '@/utils/themeHelper';
import { router } from '@router';
import { onMounted } from 'vue';

function gotoLoginPage() {
  router.push({
    name: 'Login',
  });
}

// 해당 라이프 사이클시 동작하는 메소드 (사용 안하면 삭제)
onMounted(() => {
  loadTheme();
});
</script>
