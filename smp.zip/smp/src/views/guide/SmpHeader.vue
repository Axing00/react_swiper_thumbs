<template>
  <!-- 231012: crumbs가 들어갈 시 .is-crumbs 클래스 추가 -->
  <div class="smp-header" :class="isBreadCrumb ? 'is-crumbs' : ''">
    <div class="left">
      <div v-if="isBreadCrumb" class="bread-crumbs-container">
        <i class="y-location-icon"></i>
        <!-- 231012 phr: li 늘어추가되면 '>' 자동 추가 됨 -->
        <ul>
          <li>알림</li>
          <!-- <li>VOC &amp; 지원 요청 / FAQ</li> -->
        </ul>
      </div>
      <h3 :title="props.title">{{ props.title }}</h3>
    </div>
    <ul class="right">
      <!-- 231012: dashboard 화면에 접근 시 .active클래스 적용 -->
      <li>
        <a href="#none" class="dash" :class="isDashboard ? 'active' : ''"></a>
      </li>
      <!-- 231012: theme light dark에 따라 .theme-light / .theme-dark로 클래스 변경 -->
      <li>
        <a
          href="#none"
          class="theme-light"
          :class="currentThemeClass"
          @click="toggleTheme"
        ></a>
      </li>
      <li>
        <a href="#none" class="alarm"></a>
        <span class="count">5</span>
      </li>
      <li><a href="#none" class="user"></a> </li>
      <li><a href="#none" class="logout"></a> </li>
    </ul>
  </div>
</template>
<script lang="ts" setup>
import { ref, computed } from 'vue';
import { applyTheme, getTheme, setTheme, ThemeType } from '@/utils/themeHelper';

//[시작] 231012 phr: 클릭에 따라 Theme 변경
const currentTheme = ref(getTheme());

// Function to toggle the theme
function toggleTheme() {
  if (currentTheme.value === ThemeType.LIGHT) {
    setTheme(ThemeType.DARK);
    applyTheme(ThemeType.DARK);
  } else {
    setTheme(ThemeType.LIGHT);
    applyTheme(ThemeType.LIGHT);
  }
  currentTheme.value = getTheme();
}
//[끝] 231012 phr: 클릭에 따라 Theme 변경

//[시작] 231012 phr: isbreadcrumb
// DataTable 페이지네이션 여부

const props = defineProps({
  title: {
    type: String,
    required: false,
    default: () => {
      return 'Title';
    },
  },
  isDashboard: {
    type: Boolean,
    required: false,
    default: () => {
      return false;
    },
  },
  isBreadCrumb: {
    type: Boolean,
    required: false,
    default: () => {
      return true;
    },
  },
});
//[끝] 231012 phr: isbreadcrumb

// Computed property to determine the theme class based on the current theme
const currentThemeClass = computed(() => {
  return currentTheme.value === ThemeType.LIGHT ? 'theme-dark' : 'theme-light';
});
</script>
