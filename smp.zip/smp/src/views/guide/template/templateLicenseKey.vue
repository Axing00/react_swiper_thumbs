<template>
  <div class="license-key-container">
    <div class="y-page-container-30">
      <div class="y-table-container">
        <div class="flex items-center justify-between y-mb20">
          <h4>총 4 건</h4>
          <div class="search-input-area">
            <q-input
              v-model="searchInput"
              outlined
              type="text"
              class="y-text"
              placeholder="검색어를 입력해주세요"
            />
            <span class="search-input-icon"></span>
          </div>
        </div>
        <!-- content area -->
        <ul class="card-area">
          <li
            v-for="(item, index) in softwareItems"
            :key="index"
            class="y-page-container-20"
          >
            <div class="flex justify-between reverse-border-1 card-top">
              <div class="flex items-start">
                <img
                  src="../../../assets/images/ic_license_logo.png"
                  :alt="item.name"
                />
                <div class="y-ml10">
                  <h3 class="y-mb10 txt">{{ item.name }}</h3>
                  <h4>{{ item.description }}</h4>
                </div>
              </div>
              <span>{{ item.keyFeatures }}</span>
            </div>
            <div class="card-bottom">
              <p class="flex items-center justify-between reverse-bg-3">
                <span>라이센스 목록</span>
                <span
                  class="y-arrow-up"
                  :class="{ down: toggledContainers.includes(index) }"
                  @click="toggleContainer(index)"
                ></span>
              </p>
              <div
                class="y-page-container-20-2"
                :class="{ active: toggledContainers.includes(index) }"
              >
                <q-table
                  v-model:pagination="pagination"
                  flat
                  :rows="item.licenseList"
                  :columns="tableColumns1"
                  row-key="index"
                  :sortable="false"
                  :no-hover="true"
                  :row-pointer="false"
                  :bordered="false"
                  @row-click="showLicenseInfo(index)"
                />
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <!-- popup -->
    <LicenseDetailPopup v-model="alertDialogVisible" />
  </div>
</template>

<script setup lang="ts">
import { loadTheme } from '@/utils/themeHelper';
import { onMounted, ref } from 'vue';

import { storeToRefs } from 'pinia';
import { useGuideStore } from '@/store/guide/guideStore';

//license detail popup
import LicenseDetailPopup from './templateLicenseDetailPopup.vue';

const guideStore = useGuideStore();
const { title } = storeToRefs(guideStore);

title.value = '라이센스 관리';
// 231012 phr: mount되면 기본 dark스타일
onMounted(async () => {
  // initInfo();
  loadTheme();
});

const softwareItems = ref([
  {
    name: '소프트웨어 이름 0001',
    description: '소프트웨어 대한 설명 0001',
    keyFeatures: '주요 기능 0001',
    licenseList: [
      {
        number: '1',
        license_type: 'Premium',
        count: '10',
        info1: '기타 정보 1',
        info2: '기타 정보 1',
      },
    ],
  },
  {
    name: '소프트웨어 이름 0002',
    description: '소프트웨어 대한 설명 0002',
    keyFeatures: '주요 기능 0001',
    licenseList: [
      {
        number: '1',
        license_type: 'Premium',
        count: '10',
        info1: '기타 정보 1',
        info2: '기타 정보 1',
      },
    ],
  },
  {
    name: '소프트웨어 이름 0003',
    description: '소프트웨어 대한 설명 0003',
    keyFeatures: '주요 기능 0003',
    licenseList: [
      {
        number: '1',
        license_type: 'Premium',
        count: '10',
        info1: '기타 정보 1',
        info2: '기타 정보 1',
      },
    ],
  },
  {
    name: '소프트웨어 이름 0004',
    description: '소프트웨어 대한 설명 0004',
    keyFeatures: '주요 기능 0004',
    licenseList: [
      {
        number: '1',
        license_type: 'Premium',
        count: '10',
        info1: '기타 정보 1',
        info2: '기타 정보 1',
      },
    ],
  },
]);

const searchInput = ref<string>('');

const toggledContainers = ref<number[]>([]); // 토글된 요소를 추적하기 위한 배열

// 함수를 만들어 y-arrow-up 클릭 시 호출할 수 있도록 합니다.
const toggleContainer = (index: number) => {
  if (toggledContainers.value.includes(index)) {
    toggledContainers.value = toggledContainers.value.filter(
      (i) => i !== index
    );
  } else {
    toggledContainers.value.push(index);
  }
};

//[시작] table data
const pagination = ref({
  descending: false,
  page: 1,
  rowsPerPage: 3,
});

const tableColumns1 = [
  {
    name: 'number',
    label: '번호',
    field: 'number',
    align: 'center',
  },
  {
    name: 'license_type',
    label: '라이센스 종류',
    field: 'license_type',
    align: 'center',
  },
  {
    name: 'count',
    label: '발급수량',
    field: 'count',
    align: 'center',
  },
  {
    name: 'info1',
    label: '기타정보1',
    field: 'info1',
    align: 'center',
  },
  {
    name: 'info2',
    label: '기타정보2',
    field: 'info2',
    align: 'center',
  },
];
//[끝] table data

// TABLE ROW 클릭 시 라이센스 상세 정보 popup 노출
const alertDialogVisible = ref(false); // 상태 변수 추가
const showLicenseInfo = (rowIndex: number) => {
  // const item = softwareItems.value[rowIndex];
  // const licenseInfo = `
  //   소프트웨어 이름: ${item.name}
  //   설명: ${item.description}
  //   주요 기능: ${item.keyFeatures}
  //   라이센스 종류: ${item.licenseList[0].license_type}
  //   발급수량: ${item.licenseList[0].count}
  //   기타 정보1: ${item.licenseList[0].info1}
  //   기타 정보2: ${item.licenseList[0].info2}
  // `;

  // alert(licenseInfo);
  console.log(rowIndex);
  alertDialogVisible.value = true;
};
</script>

<style lang="scss" scoped>
.y-page-container-20 {
  padding: 0;
}
.card-area {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  .card-top,
  .card-bottom {
    padding: 20px;
  }
  > li {
    width: calc(50% - 10px);
    h3 {
      font-size: 16px;
      line-height: 20px;
      font-weight: 700;
    }
    h4 {
      font-size: 13px;
      font-weight: 400;
      line-height: 16px;
      color: #999;
      letter-spacing: -0.52px;
    }
    span {
      color: #000;
      font-size: 13px;
      font-weight: 400;
      line-height: 16px;
      letter-spacing: -0.52px;
    }
  }
}
.reverse-bg-3 {
  padding: 10px 20px;
  border-radius: 4px;
}
.y-page-container-20-2 {
  display: none;
  &.active {
    display: block;
  }
}
/* #=========================================# 
| DARK MODE
| #=========================================# */
body {
  &.body--dark {
    .card-area {
      > li {
        h4 {
          color: #bbb;
        }
        span {
          color: #fff;
        }
      }
    }
  }
}
</style>
