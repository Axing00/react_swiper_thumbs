<template>
  <div class="main-dashboard-container">
    <ul class="content-top">
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>라이선스 평균 사용률</h3>
            <i></i>
          </div>
          <div class="content-area">
            <div class="flex items-center">
              <span class="img chart"></span>
              <!-- 5자리 초과 시 title 로 대체 -->
              <h4 title="83%"><span>83</span>%</h4>
            </div>
            <div>
              <span class="bage purple">274</span>
              <span class="bage d-gray">56</span>
            </div>
          </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>구독 갱신 30일전</h3>
            <i></i>
          </div>
          <div class="content-area">
            <div class="flex items-center">
              <span class="img calendar"></span>
              <!-- 5자리 초과 시 title 로 대체 -->
              <h4 title="7"><span>6</span></h4>
            </div>
            <div>
              <span class="bage yellow">5</span>
              <span class="bage gray">13</span>
            </div>
          </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>구독 갱신 30일전</h3>
            <i></i>
          </div>
          <div class="content-area">
            <div class="flex items-center">
              <span class="img check"></span>
              <!-- 5자리 초과 시 title 로 대체 -->
              <h4 title="25"><span>25</span></h4>
            </div>
            <div>
              <span class="bage purple">12</span>
              <span class="bage gray">8</span>
            </div>
          </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>VOC 신규 현황</h3>
            <i></i>
          </div>
          <div class="content-area">
            <div class="flex items-center">
              <span class="img new"></span>
              <!-- 5자리 초과 시 title 로 대체 -->
              <h4 title="555556"><span>555556</span></h4>
            </div>
            <div>
              <span class="bage purple">3</span>
              <span class="bage gray">12</span>
            </div>
          </div>
        </a>
      </li>
      <li class="total-pay">
        <a href="#none">
          <div class="title-area">
            <h3>총 지출금액</h3>
            <i></i>
          </div>
          <div class="content-area">
            <div class="flex items-center">
              <span class="img pay"></span>
              <!-- 4자리 초과 시 title 로 대체 -->
              <h4 title="5.0 ₩">
                <span>5.0</span><span class="unit">₩</span>
              </h4>
            </div>
            <div>
              <span>단위 : 천 원</span>
            </div>
          </div>
        </a>
      </li>
    </ul>
    <ul class="content-bottom">
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>라이선스 사용 TOP 5</h3>
            <i class="right-arrow"></i>
          </div>
          <div class="chart-area"> </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>부서별 라이선스 사용 TOP 5</h3>
            <i class="right-arrow"></i>
          </div>
          <div class="chart-area"> </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>라이선스 사용 현황</h3>
            <i class="right-arrow"></i>
          </div>
          <div class="chart-area"> </div>
        </a>
      </li>
      <li>
        <a href="#none">
          <div class="title-area">
            <h3>실시간 라이선스 사용 현황</h3>
            <i class="right-arrow"></i>
          </div>
          <div class="chart-area"> </div>
        </a>
      </li>
    </ul>
  </div>
</template>
<script setup lang="ts">
import { loadTheme } from '@/utils/themeHelper';
import { onMounted } from 'vue';

import { storeToRefs } from 'pinia';
import { useGuideStore } from '@/store/guide/guideStore';

const guideStore = useGuideStore();
const { title, isDashboard } = storeToRefs(guideStore);
//  231012 phr: 메인에서는 crumb 불필요
// const isCrumb = false;

title.value = 'Dashboard';
isDashboard.value = true;

// 231012 phr: mount되면 기본 dark스타일
onMounted(async () => {
  // initInfo();
  loadTheme();
});
</script>
