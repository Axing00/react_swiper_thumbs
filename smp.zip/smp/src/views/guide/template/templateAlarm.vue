<template>
  <div class="alarm-layout-container y-page-container-30 y-mb30">
    <q-tabs v-model="AlarmTab" class="y-mb10 justify-start tab-area y-mb20">
      <q-tab name="tableType1" class="tab"> tableType1 </q-tab>
      <q-tab name="tableType2" class="tab"> tableType2 </q-tab>
    </q-tabs>
    <q-tab-panels v-model="AlarmTab">
      <!-- tableType1 -->
      <q-tab-panel name="tableType1">
        <div class="y-table-container">
          <div class="flex items-center justify-between y-mb20">
            <h4 class="total-title">총 10 건</h4>
            <div class="search-input-area">
              <q-input
                v-model="searchInput"
                outlined
                type="text"
                class="y-text"
                placeholder="검색어를 입력해주세요"
              />
              <span class="search-input-icon"></span>
            </div>
          </div>
          <div>
            <q-table
              v-model:pagination="pagination"
              flat
              :rows="tableList1"
              :columns="tableColumns1"
              row-key="index"
              :sortable="false"
              :no-hover="true"
              :row-pointer="false"
              :bordered="false"
            >
              <template #body-cell-icon="props">
                <!-- props.row.icon에 저장된 아이콘 정보를 사용하여 아이콘을 렌더링합니다 -->
                <td>
                  <span class="y-see-more-icon-t"> </span>
                </td>
              </template>
              <!-- 제목(Title) 열에 클릭 이벤트 리스너 연결 -->
              <template #body-cell-title="props">
                <td class="clickable" @click="onTitleColumnClick">
                  {{ props.row.title }}
                </td>
              </template>
            </q-table>
          </div>
          <!-- 팝업 -->
          <q-dialog
            v-model="persistent"
            persistent
            transition-show="scale"
            transition-hide="scale"
          >
            <div class="popup-container">
              <div class="title-area">
                <div>
                  <h3 class="title">계정 신규 신청 내용입니다.</h3>
                </div>
                <span v-close-popup class="close-icon"></span>
              </div>
              <div class="content-area">
                <div class="flex justify-between y-mb20">
                  <div class="y-txt"> 사용자 100 &lt;sand@example.com&gt; </div>
                  <div class="y-txt">2023-08-24 14:32</div>
                </div>
                <q-input
                  v-model="text"
                  class="y-full-w"
                  :rows="1"
                  outlined
                  type="textarea"
                />
              </div>
              <div class="footer-area flex justify-end">
                <q-btn class="y-btn" roun>확인</q-btn>
              </div>
            </div>
          </q-dialog>
        </div>
      </q-tab-panel>
      <!-- tableType2 -->
      <q-tab-panel name="tableType2"> tableType2 </q-tab-panel>
    </q-tab-panels>
  </div>
</template>
<script lang="ts" setup>
import { loadTheme } from '@/utils/themeHelper';
import { onMounted, ref } from 'vue';

import { storeToRefs } from 'pinia';
import { useGuideStore } from '@/store/guide/guideStore';

const guideStore = useGuideStore();
const { title, isDashboard } = storeToRefs(guideStore);

// 231012 phr: mount되면 기본 dark스타일
onMounted(async () => {
  // initInfo();
  loadTheme();
});

// 231012 phr: title props
title.value = 'Dashboard';
isDashboard.value = false;
// 231012 phr: tab
const AlarmTab = ref<string>('tableType1');

// 231012 phr: tableType1 검색 input
const searchInput = ref<string>('');

const onTitleColumnClick = () => {
  persistent.value = true;
};

// table data
const pagination = ref({
  descending: false,
  page: 1,
  rowsPerPage: 10,
});

const tableColumns1 = [
  {
    name: 'type',
    label: '종류',
    field: 'type',
    align: 'left',
  },
  {
    name: 'sender',
    label: '보낸사람',
    field: 'sender',
    align: 'left',
  },
  {
    name: 'email',
    label: '이메일',
    field: 'email',
    align: 'left',
  },
  {
    name: 'title',
    label: '제목',
    field: 'title',
    align: 'left',
  },
  {
    name: 'receivedDate',
    label: '수신일',
    field: 'receivedDate',
    align: 'left',
  },
  {
    name: 'icon',
    label: '',
    field: 'icon',
    align: 'left',
  },
];

const tableList1 = [
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
  {
    type: '계정',
    sender: '사용자 100',
    email: '01@example.com',
    title: '계정 신규 신청 내용입니다.',
    receivedDate: '2023-08-24 10:00',
  },
];

// popup textarea
let text = ref('');

// 231012 phr: popoup
const persistent = ref(false);
const popTitle = ref('popup');
</script>
<style lang="scss" scopped>
.q-table {
  thead {
    tr {
      th {
        &:nth-child(4) {
          width: 39%;
        }
      }
    }
  }
  tbody {
    tr {
      td {
        // 제목 폰트 스타일
        &:nth-child(4) {
          font-weight: 700;
          color: #6c7ce3;
          cursor: pointer;
        }
      }
    }
  }
}
.q-textarea {
  min-height: 250px;
}
/* #=========================================# 
| DARK MODE
| #=========================================# */
body {
  &.body--dark {
    .q-table {
      tbody {
        tr {
          td {
            // 제목 폰트 스타일
            &:nth-child(4) {
              color: #6c7ce3;
            }
          }
        }
      }
    }
  }
}
</style>
