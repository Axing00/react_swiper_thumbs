<template>
  <!--[시작] License Detail Popup -->
  <q-dialog
    v-model="visible"
    persistent
    transition-show="scale"
    transition-hide="scale"
  >
    <!--231017 phr: popup-container .y-lg > 1000px -->
    <div class="popup-container y-lg license-detail-popup">
      <!--[시작] Title area -->
      <div class="title-area">
        <div class="flex items-center">
          <h3 class="title y-mr10">라이선스 상세 정보</h3>
          <span class="sub-title">소프트웨어명 0001</span>
        </div>
        <span v-close-popup class="close-icon" @click="close"></span>
      </div>
      <!--[끝] Title area -->

      <!--[시작] Content -->
      <div class="content-area">
        <div class="explanation-card y-page-container-20 y-mb20 y-txt">
          소프트웨어 대한 설명 001 소프트웨어 대한 설명 001소프트웨어 대한 설명
          001소프트웨어 대한 설명 001소프트웨어 대한 설명 001소프트웨어 대한
          설명 001소프트웨어 대한 설명 001소프트웨어 대한 설명 001 두줄까지 표시
        </div>
        <ul class="top-card-area y-mb30">
          <li
            v-for="(card, index) in topCardData"
            :key="index"
            class="reverse-bg-4"
          >
            <h3 class="y-txt">{{ card.title }}</h3>
            <p class="y-txt">{{ card.value }}</p>
          </li>
        </ul>
        <!--[시작] 전체 라이선스 KEY 목록 / 부서별 라이선스 KEY 사용 현황 -->
        <div class="flex bottom-detail">
          <div class="y-table-container">
            <h3 class="y-txt">전체 라이선스 KEY 목록</h3>
            <q-table
              v-model:pagination="pagination"
              flat
              :rows="tableList1"
              :columns="tableColumns1"
              row-key="index"
              :sortable="false"
              :no-hover="true"
              :row-pointer="false"
              :bordered="false"
            >
              <!-- props.row.icon에 저장된 아이콘 정보를 사용하여 아이콘을 렌더링합니다 -->
              <!-- KEY 할당 -->
              <template #body-cell-icon="props">
                <td>
                  <span class="y-see-more-icon-t" @click="onShow(props.row)">
                  </span>
                </td>
                <td>
                  <span class="y-see-more-icon-t" @click="onShow(props.row)">
                  </span>
                </td>
                <td>
                  <span class="y-see-more-icon-t" @click="onShow(props.row)">
                  </span>
                </td>
              </template>
            </q-table>
            pagination
          </div>
          <div class="chart-container">
            <h3 class="y-txt">부서별 라이선스 KEY 사용 현황</h3>
            <div class="reverse-bg-2 y-txt chart-area"> chart area </div>
          </div>
        </div>
        <!--[끝] 전체 라이선스 KEY 목록 / 부서별 라이선스 KEY 사용 현황 -->
      </div>
      <!--[끝] Content -->

      <!--[시작] Footer -->
      <div class="footer-area flex justify-end">
        <q-btn class="y-btn" round>확인</q-btn>
      </div>
      <!--[끝] Footer -->
    </div>
  </q-dialog>
  <!--[끝] License Detail Popup -->
</template>

<script setup lang="ts">
import { ref } from 'vue';

const visible = ref(false);

// key 수량 Data
const topCardData = ref([
  { title: '전체 라이선스 KEY 수량', value: '00' },
  { title: '활성화된 라이선스 KEY 수량', value: '00' },
  { title: '비활성화된 라이선스 KEY 수량', value: '00' },
  { title: '만료된 라이선스 KEY 수량', value: '00' },
]);

//[시작] 전체 라이선스 KEY 목록 Table Data
const pagination = ref({
  descending: false,
  page: 1,
  rowsPerPage: 5,
});

const tableColumns1 = [
  {
    name: 'license_key',
    label: '라이선스 KEY',
    field: 'license_key',
    align: 'center',
  },
  {
    name: 'user',
    label: '현재 사용자',
    field: 'user',
    align: 'center',
  },
  {
    name: 'period',
    label: '사용 기간',
    field: 'period',
    align: 'center',
  },
  {
    name: 'status',
    label: '상태',
    field: 'status',
    align: 'center',
  },
  {
    name: 'key_assignment',
    label: 'KEY 할당',
    field: 'key_assignment',
    align: 'left',
  },
  {
    name: 'key_collect',
    label: 'KEY 회수',
    field: 'key_collect',
    align: 'left',
  },
  {
    name: 'record',
    label: '이력 확인',
    field: 'record',
    align: 'left',
  },
];

const tableList1 = [
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
  {
    license_key: 'abcfbg12B',
    user: '사용자 A',
    period: '2023-10-12 ~ 2024-10-11',
    status: '활성화',
    key_assignment: '',
  },
];

//[끝] 전체 라이선스 KEY 목록 Table Data

const onShow = (row) => {
  console.log(row);
};

// 팝업 닫기
const close = () => {
  visible.value = false;
};
</script>
<style lang="scss" scopped>
.license-detail-popup {
  .explanation-card {
    font-size: 14px;
    font-weight: 400;
    letter-spacing: -0.56px;
    line-height: 18px;
  }
  .top-card-area {
    display: flex;
    gap: 10px;
    li {
      flex: 1;
      padding: 10px 20px;
      border-radius: 10px;
      h3 {
        margin-bottom: 7px;
        font-size: 14px;
        font-weight: 400;
        letter-spacing: -0.56px;
        line-height: 18px;
      }
      p {
        font-size: 20px;
        font-weight: 700;
        line-height: 25px;
      }
    }
  }
  //bottom-detail
  .bottom-detail {
    gap: 20px;
    flex: nowrap;
    h3 {
      margin-bottom: 20px;
      font-size: 16px;
      font-weight: 500;
      line-height: 20px;
    }
    .y-table-container {
      width: calc(100% - 330px);
    }
    .chart-container {
      width: 310px;
      .chart-area {
        height: 314px;
        padding: 20px;
        border-radius: 6px;
      }
    }
  }
}
</style>
