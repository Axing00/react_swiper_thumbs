<template>
  <div class="smp-container">
    <!-- aside -->
    <AsideView />
    <!-- right side -->
    <div class="right-side-container">
      <SmpHeader />
      <!-- content -->
    </div>
  </div>
</template>
<script setup lang="ts">
import { loadTheme } from '@/utils/themeHelper';
import AsideView from '@views/guide/AsideView.vue';
import SmpHeader from '@views/guide/SmpHeader.vue';
import { onMounted } from 'vue';

onMounted(async () => {
  // initInfo();
  loadTheme();
});
</script>
