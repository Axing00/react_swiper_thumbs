<template>
  <div>
    <div class="main-wrapper">
      <q-page padding class="page-gray main-container">
        <div class="y-mb20">
          <h2 class="guide-title txt y-smt-f y-mb10">아이콘</h2>
          <div class="flex items-center">
            <q-btn class="y-download-btn" @click="downloadBtn" />
            <button class="refresh-btn y-ml10" @click="onClickRefresh"></button>
            <span class="info-icon y-ml10"></span>
            <!-- edit 디폴트 주황색 -->
            <span class="y-icon-edit y-ml10"></span>
            <span class="y-icon-edit-w y-ml10"></span>
            <span class="y-icon-pencil y-ml10"></span>
            <button class="y-btn-play y-ml10"></button>
            <button class="y-btn-stop y-ml10"></button>
            <button class="y-btn-see-detail y-ml10"></button>
            <span class="y-goto-link-btn y-ml10"></span>
          </div>
        </div>
        <div class="y-mb20">
          <h2 class="guide-title txt y-smt-f y-mb10">버튼</h2>
          <!-- 뒤로/앞으로가기 -->
          <q-btn
            class="y-btn line"
            label="&lt;&nbsp;&nbsp;뒤로"
            @click="onClickBackTab"
          />
          <q-btn
            class="y-btn line y-ml10"
            label="앞으로&nbsp;&nbsp;&gt;"
            @click="onClickGoTab"
          />
          <!--// 뒤로/앞으로가기 -->
          <q-btn class="y-btn primary y-ml10" label="삭제" />
          <q-btn class="y-btn gray-d y-ml10" label="other button" />
          <q-btn class="y-btn y-ml10" label="취소" />
          <q-btn class="y-btn gray-w y-ml10" label="button" />
          <!-- minus -->
          <span
            class="material-icons y-btn minus-icon y-ml10"
            @click="onClickRemove"
          >
            remove
          </span>
          <!-- add -->
          <q-btn
            class="y-btn add-icon y-ml10"
            :icon="`add`"
            @click="onClickAdd"
          />
          <!-- edit -->
          <q-btn class="y-btn primary add-icon y-ml10" :icon="`edit`" />
        </div>
        <!-- 상태값 -->
        <div class="y-mb20">
          <h2 class="guide-title txt y-smt-f y-mb10">상태</h2>
          <span class="y-status-icon y-bg-green y-mr10">ready</span>
          <span class="y-status-icon y-bg-red y-mr10">unready</span>
          <span class="y-status-icon y-bg-purple">complete</span>
        </div>
        <!-- 테이블 관련 -->
        <div>
          <h2 class="guide-title txt y-smt-f y-mb10">테이블 내 사용</h2>
          <div class="flex items-center">
            <div class="y-editing-area">
              <span class="y-icon-edit-w y-mr5"></span>
              편집 중인 항목이 있습니다.
            </div>
            <span class="y-gray-label y-ml10">
              서비스 명 : [a]cocktail-system
            </span>
          </div>
        </div>
      </q-page>
    </div>
  </div>
</template>
<script lang="ts" setup>
const downloadBtn = (): void => {
  console.log('download');
};
const onClickRefresh = (): void => {
  console.log('refresh');
};
const onClickBackTab = (): void => {
  console.log('back');
};
const onClickGoTab = (): void => {
  console.log('go');
};
const onClickRemove = (): void => {
  console.log('remove');
};
const onClickAdd = (): void => {
  console.log('add');
};
</script>
<style lang="scss" scoped></style>
