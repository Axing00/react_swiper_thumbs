<template>
  <aside class="left-aside">
    <div class="sidebar-inner">
      <h1>
        <img src="../../assets/images/smp_logo_main.png" alt="main" />
      </h1>
      <ul class="depth1">
        <li>
          <a href="#none">
            <span class="img-area mypage"> </span>
            <span class="right_arrow"></span>
          </a>
          <ul class="depth2">
            <li>
              <span>마이페이지</span>
              <ul class="depth3">
                <li><a href="#none">라이선스 현황</a></li>
                <li><a href="#none">라이선스 신청</a></li>
                <li><a href="#none">라이선스 사용량</a></li>
                <li><a href="#none">VOC 목록</a></li>
              </ul>
            </li>
          </ul>
        </li>
        <li>
          <a href="#none">
            <span class="img-area license"> </span>
            <span class="right_arrow"></span>
          </a>
          <ul class="depth2">
            <li>
              <span>서비스 관리</span>
              <ul class="depth3">
                <li><a href="#none">계약 관리</a></li>
                <li><a href="#none">신청 관리</a></li>
                <li><a href="#none">라이선스 관리</a></li>
              </ul>
            </li>
          </ul>
        </li>
        <li>
          <a href="#none">
            <span class="img-area supports"> </span>
          </a>
          <ul class="depth2">
            <li><span>장애 접수 (VOC)</span></li>
          </ul>
        </li>
        <li>
          <a href="#none">
            <span class="img-area monitor"> </span>
            <span class="right_arrow"></span>
          </a>
          <ul class="depth2">
            <li>
              <span>모니터링</span>
              <ul class="depth3">
                <li><a href="#none">사용량 추이 분석</a></li>
                <li><a href="#none">실시간 사용 현황</a></li>
              </ul>
            </li>
          </ul>
        </li>
        <li>
          <a href="#none">
            <span class="img-area setting"> </span>
            <span class="right_arrow"></span>
          </a>
          <ul class="depth2">
            <li>
              <span>관리자 설정</span>
              <ul class="depth3">
                <li><a href="#none">계정 신청</a></li>
                <li><a href="#none">사용자 관리</a></li>
                <li><a href="#none">그룹 관리</a></li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </aside>
</template>
<script lang="ts" setup></script>
<style lang="scss"></style>
