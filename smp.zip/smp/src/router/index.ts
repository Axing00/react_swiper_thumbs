import notify from '@/config/notifyConfig';
import { useAuthStore } from '@/store/app/useAuthStore';
import routesDefault from '@router/routesDefault';
import guideRoutes from './guideRoutes';
import type { App } from 'vue';
import type { RouteLocationNormalized, Router } from 'vue-router';
import { createRouter, createWebHistory } from 'vue-router';
import { changeI18nLocale } from '@/config/langConfig';
import cacheHelper, { cacheType } from '@/utils/cacheHelper';

import { lang } from '@config/langConfig';
import dialog from '@/components/dialog';
import { useUserManager } from '@/store/admin/userManagerStore';

export const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: makeRoutes(),
  strict: true,
  scrollBehavior: () => ({ left: 0, top: 0 }),
});

// routes 목록 생성
function makeRoutes() {
  // for (let i = 0, len = routesDefault.length; i < len; i++) {
  //   const item = routesDefault[i];
  //   // if (item.name == 'MainLayout') {
  //   //   item.children = item.children?.concat(guideRoutes);

  //   //   // if (import.meta.env.DEV) {
  //   //   //   item.children = item.children?.concat(guideRoutes);
  //   //   // }
  //   //   break;
  //   // }
  // }
  // item.children = item.children?.concat(guideRoutes);

  return routesDefault.concat(guideRoutes);
}

/**
 * 페이지 로딩 라우터 가드
 *  - 브라우저 갱신을 할 경우 다국어가 변경이 안되는 경우가 있어 페이지 이동 전 다국어를 설정함
 * @param router
 */
function createPageLoadingGuard(router: Router) {
  setLocale();
  router.beforeEach(async (to: RouteLocationNormalized) => {
    // const result = await checkAllowedMenu(to);
    await checkAllowedMenu(to);

    // console.log('Loading Guard check menu result : ', result);

    // return result;
  });
  router.afterEach(async (then: RouteLocationNormalized) => {
    const isMainPage = document.getElementsByClassName('dashboard-container');

    if (then.fullPath == '/main') {
      // 최초 로그인 이후 main화면에 대시보드가 제대로 로딩되지 않는 경우 작동
      setTimeout(() => {
        if (isMainPage.length == 0) {
          // router.push({
          //   name: 'main',
          // });
          location.reload();
        }
      }, 1000);
    }

    return true;
  });
}

function setLocale() {
  const locale = cacheHelper.getCache(cacheType.LOCALE);
  changeI18nLocale(locale);
}

interface MetaAuth {
  isRequiredCheckMenu: boolean;
  code?: string;
}

/**
 * 메뉴 접속 권한 체크 API
 * @param menuCode
 * @returns
 */
// async function checkAllowedMenuAPI(menuCode: string) {
//   if (menuCode == '') {
//     return false;
//   }

//   const authStore = useAuthStore();
//   try {
//     const result = await authStore.checkAllowedMenu(menuCode);
//     return result.result;
//   } catch (error) {
//     return false;
//   }
// }

/**
 * 메뉴 접속 권한 체크
 * @param to
 * @returns
 */
async function checkAllowedMenu(to: RouteLocationNormalized): Promise<void> {
  // const userManagerStore = useUserManager();
  // routing 정보 파악
  // const auth = to.meta?.auth as MetaAuth;
  // const authStore = useAuthStore();
  // const userPriv = userManagerStore.currUserPriv;
  // 라우팅 할 때마다 세션 유무, 현재 메뉴가 접근 권한이 필요한지 여부 파악
  // const isRequiredCheckMenu = auth.isRequiredCheckMenu;
  // 라우터 이동 할 때마다 session-check 기능 작동하도록 설정
  // const isUserAuthCheck = await authStore.authCheck();
  // const loginUserId = cacheHelper.getCache(cacheType.LOGIN_USER_ID);
  /**
   * 세션 유무로 라우팅 제한 - 커밋할 때 주석 처리
   */
  // 인증이 필요한 페이지 && 인증 정보 없음
  // if (isRequiredCheckMenu == true && isUserAuthCheck == false) {
  // console.log('인증이 필요한 페이지, 인증 정보 없음, 로그인 화면으로 이동');
  // notify.error(lang('davisMsg.login.error.sessionFail'));
  // authStore.davisLogout();
  // }
  // 로그인 페이지 && 인증 정보 있음
  // if (to.fullPath === '/login' && isUserAuthCheck == true) {
  //   // console.log('로그인 인증 정보 있음, 메인 화면으로 이동');
  //   router.push({
  //     name: 'main',
  //   });
  // }
}

export function setupRouter(app: App) {
  createPageLoadingGuard(router);
  app.use(router);
}
