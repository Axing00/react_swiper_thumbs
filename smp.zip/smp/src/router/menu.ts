import type { RouteRecordRaw } from 'vue-router';
// import routes from '@router/routes';

const setMenu = (menusData: Array<RouteRecordRaw>): Array<RouteRecordRaw> => {
  const filteredMenu: Array<RouteRecordRaw> = [];
  //대메뉴에 표시할 메뉴
  menusData.forEach((menus: RouteRecordRaw) => {
    if (menus.name == 'MainLayout' && menus.children) {
      menus.children.forEach((menu: RouteRecordRaw) => {
        if (
          menu.name !== 'Dashboard' &&
          menu.name !== 'MainView' &&
          menu.name !== 'HelpDocument'
        ) {
          filteredMenu.push(menu);
        }
      });
    }
  });
  return filteredMenu;
};

// export const mainMenus: Array<RouteRecordRaw> = setMenu(routes);
// export const allMenus: Array<RouteRecordRaw> = routes;

export interface MenuItem {
  menu_code: string;
  type: string;
  order: number;
  level?: number;
  children?: MenuItem[];
}

export function createMenuData(rawMenus: MenuItem[]): MenuItem[] {
  // 메뉴의 menu_code를 키로 갖는 map 생성 - 부모 키 값을 사용하여 MenuItem을 찾기위한 임시 용도
  const tempMenuMap = new Map<string, MenuItem>();
  // 부모 키 반환 ex) iaas.cm.cl.pr -> iaas.cm.cl
  const getParentCodeFn = (menuCode: string) =>
    menuCode.substring(0, menuCode.lastIndexOf('.'));

  // 1. 데이터 초기화
  // 2. 데이터 정렬
  // 3. 부모 메뉴 검색 -> children 추가
  // 4. level이 1인 최상위 부모 메뉴만 반환
  return rawMenus
    .map((item) => {
      item.level = item.menu_code.split('.').length; // ex) iaas > 1 / iaas.cm > 2 / iaas.cm.cl > 3
      item.children = [];
      return item;
    })
    .sort((a, b) => (a.level ?? 0) - (b.level ?? 0) || a.order - b.order)
    .flatMap((item) => {
      const parentCode = getParentCodeFn(item.menu_code);
      tempMenuMap
        .set(item.menu_code, item) // 메뉴 검색 용도로 Map에 저장
        .get(parentCode)
        ?.children?.push(item); // 부모메뉴가 있는 경우 children에 추가
      return item;
    })
    .filter((item) => item.level == 1);
}
