import type { RouteRecordRaw } from 'vue-router';

const guideRoutes: Array<RouteRecordRaw> = [
  {
    path: '/guide',
    name: 'iconGuide',
    component: () =>
      import(/* webpackChunkName: "GuideView" */ '@guide/IconGuideView.vue'),
    meta: {
      auth: {
        isRequiredCheckMenu: false,
      },
    },
    children: [],
  },
  {
    path: '/guide',
    name: 'MainLayoutGuide', // 메인 레이아웃
    // redirect: '/login',
    component: () =>
      import(/* webpackChunkName: "MainLayout" */ '@guide/main/MainLayout.vue'),
    meta: {},
    children: [
      // Guide Main
      {
        path: '/guide-main',
        name: 'mainGuide',
        component: () =>
          import(
            /* webpackChunkName: "MainView" */ '@guide-main/MainLayout.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: false,
          },
        },
      },
      // 대시보드
      {
        path: '/template/dashboard',
        name: 'template-dashboard',
        component: () =>
          import(
            /* webpackChunkName: "" '@/views/guide/template/templateDashboard.vue' */ '@template/templateDashboard.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: false,
          },
        },
      },
      //라이선스 키 관리
      {
        path: '/template/license-key',
        name: 'template-license-key',
        component: () =>
          import(
            /* webpackChunkName: "templateLicenseKey" */ '@template/templateLicenseKey.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: false,
          },
        },
      },
      // //알림
      {
        path: '/template/alarm',
        name: 'template-alarm',
        component: () =>
          import(
            /* webpackChunkName: "" '@/views/guide/template/templateAlert.vue' */ '@template/templateAlarm.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: false,
          },
        },
      },
    ],
  },
];
export default guideRoutes;
