import type { RouteRecordRaw } from 'vue-router';
/**
 * meta 속성
    auth: {
      isRequiredCheckMenu: true, // 권한 체크 필요 확인
      code: 'managerconfig.au', // 권한 체크 코드
    },

   -  title_path: { // 메뉴 경로 정보를 표시할때 사용
          parent: 'iaas.cm.cl',  // 부모 메뉴 name
          link: 'iaas.cm.cl.pr',  // 상세 페이지 등에서 목록으로 이동할때 메뉴 name
        }        
 */

const routesDefault: Array<RouteRecordRaw> = [
  {
    path: '/:pathMatch(.*)*',
    name: '404',
    component: () =>
      import(/* webpackChunkName: "404" */ '@/views/etc/404.vue'),
    meta: {
      isRequiredCheckMenu: true,
      auth: {
        isRequiredCheckMenu: false,
      },
    },
  },
  {
    path: '/login', // Davis Login
    name: 'Login',
    component: () =>
      // import(/* webpackChunkName: "LoginView" */ '@login/LoginView.vue'),
      import(/* webpackChunkName: "LoginView" */ '@login/LoginDev.vue'),
    meta: {
      auth: {
        isRequiredCheckMenu: false,
      },
    },
  },
  {
    path: '/',
    name: 'MainLayout', // 메인 레이아웃
    redirect: '/login',
    component: () =>
      import(
        /* webpackChunkName: "MainLayout" */ '@views/mainLayout/MainLayout.vue'
      ),
    meta: {},
    children: [
      // Davis Main
      {
        path: '/main',
        name: 'main',
        component: () =>
          import(/* webpackChunkName: "MainView" */ '@main/MainView.vue'),
        meta: {
          auth: {
            isRequiredCheckMenu: true,
          },
        },
      },
      // Davis Main2
      {
        path: '/main2',
        name: 'main2',
        component: () =>
          import(/* webpackChunkName: "MainView2" */ '@main/MainView2.vue'),
        meta: {
          auth: {
            isRequiredCheckMenu: true,
          },
        },
      },
      // Davis DashBoard
      {
        path: '/dashboard',
        name: 'dashboard',
        component: () =>
          import(
            /* webpackChunkName: "DashboardView" */ '@dashboard/DashboardView.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: true,
            code: 'dashboard',
          },
        },
      },
      // SMP Service > Licenses
      {
        path: '/key',
        name: 'licenseKey',
        component: () =>
          import(
            /* webpackChunkName: "LicenseKey" */ '@service/licenses/LicenseKey.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: true,
          },
        },
      },
      // [SMP] 메일 이력 관리
      {
        path: '/alert',
        name: 'alert',
        component: () =>
          import(
            /* webpackChunkName: "MailHistoryManagementView" */ '@/views/page/alert/mailHistoryManagement/mailHistoryView.vue'
          ),
        meta: {
          auth: {
            isRequiredCheckMenu: true,
            code: 'alert',
          },
        },
      },
    ],
  },
];

export default routesDefault;
