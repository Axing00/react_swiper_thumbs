import davisMsgKO from './lang/davisMsgKO.json';
import davisMsgEN from './lang/davisMsgEN.json';

import { Locales } from '@enums/locales';

const messagesEN = {
  ...davisMsgEN,
};
const messagesKO = {
  ...davisMsgKO,
};

export const messages = {
  [Locales.EN]: messagesEN,
  [Locales.KO]: messagesKO,
};

export const numberFormats = {};
