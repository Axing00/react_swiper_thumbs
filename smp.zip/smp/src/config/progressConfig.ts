import { Loading, QSpinnerBall } from 'quasar';

const progressConfig = {
  show() {
    Loading.show({
      spinner: QSpinnerBall,
      spinnerColor: 'primary',
      // text: 'loading...',
    });
  },
  hide() {
    Loading.hide();
  },
};

export default progressConfig;
