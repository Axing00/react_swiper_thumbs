/**
 * Quasar 이용한 알림(Notify) Util
 * https://quasar.dev/quasar-plugins/notify#timeout-progress
 */
import { Notify } from 'quasar';
import { lang } from './langConfig';

const NOTIFY_POSITION = 'bottom-right';

// 공통으로 사용 할 타입 미리 지정하는 함수
export function initNotifyTypes() {
  Notify.registerType('info', {
    icon: 'info',
    progress: true,
    color: 'info',
    textColor: 'white',
    multiLine: true,
    // classes: 'glossy',
    position: NOTIFY_POSITION,
  });
  Notify.registerType('warning', {
    icon: 'warning',
    progress: true,
    color: 'warning',
    textColor: 'black',
    multiLine: true,
    // classes: 'glossy',
    position: NOTIFY_POSITION,
  });
  Notify.registerType('negative', {
    icon: 'notification_important',
    progress: true,
    color: 'negative',
    textColor: 'white',
    multiLine: true,
    // classes: 'glossy',
    position: NOTIFY_POSITION,
  });
}

type notifyType = 'info' | 'warning' | 'negative';
function openNotify(notifyType: notifyType, message: string): void {
  Notify.create({
    type: notifyType,
    message: lang(message),
  });
}

const notify = {
  info(message: string): void {
    openNotify('info', message);
  },
  error(message: string): void {
    openNotify('negative', message);
  },
  warning(message: string): void {
    openNotify('warning', message);
  },
};
export default notify;

// const notifyConfig = {
//   // notify 오픈 함수
//   open(notifyInfo) {
//     Notify.create({
//       type: notifyInfo.type || 'info',
//       message: notifyInfo.message || '메세지를 입력해주세요',
//     });
//   },
// };
// export default notifyConfig;
