import type { App } from 'vue';
import { createI18n } from 'vue-i18n';
import { messages, numberFormats } from '@locales';
import { Locales } from '@enums/locales';

export const i18n = createI18n({
  locale: Locales.KO, // 나라 변경시 이 부분 바꾸기
  legacy: false, // Compositon API
  globalInjection: true,
  messages,
  numberFormats,
  fallbackLocale: Locales.KO,
});

/**
 * 언어 변환
 *
 * ex) formatter
 *        val str = 'test- {0} : {1}'
 *        lang(str, [1, 2]) -> test- 1 : 2
 * @param message 다국어 키
 * @returns
 */
export function lang(message: string, params?: any): string {
  if (params == undefined) {
    return i18n.global.t(message);
  } else {
    return i18n.global.t(message, params);
  }
}

/**
 * 다국어 국가 설정
 * @param langType Locales
 */
export function changeI18nLocale(langType: Locales): void {
  i18n.global.locale.value = langType;
}

export function setupLanguage(app: App<Element>) {
  app.use(i18n);
}
