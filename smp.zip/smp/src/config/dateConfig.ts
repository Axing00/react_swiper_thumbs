import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone'; // dependent on utc plugin

dayjs.extend(utc);
dayjs.extend(timezone);
// const timeZone = (locale: string) => {
//   if (locale) {
//     return locale;
//   }
//   return TimeZone.UTC;
// };

// /**
//  * 기본 타임존 설정 (필요시 사용)
//  */
// export function setupTimeZone() {
//   // 언어 설정에 따른 timeZone 변경
//   //   console.log(moment.tz.names());
//   const locale = getTimeZone(i18n.global.locale.value);
//   if (locale) {
//     timeZone(locale.timeZone);
//     moment.tz.setDefault(locale.timeZone);
//   } else {
//     // 현재 접속한 위치 기준 timeZone 설정
//     //   const timeZone = moment.tz.guess();
//     moment.tz.setDefault(moment.tz.guess());
//   }
// }

// export { moment };
