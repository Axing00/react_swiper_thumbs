import type { App } from 'vue';
import progressConfig from '@config/progressConfig';
import { initNotifyTypes } from '@config/notifyConfig';

export function setupProvide(app: App<Element>) {
  // notify 기본 타입 지정
  initNotifyTypes();
  // helper들 등록
  app.provide('progressConfig', progressConfig);
}
