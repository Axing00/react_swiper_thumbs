/**
 * Quasar 이용 팝업 Util
 * https://quasar.dev/quasar-plugins/dialog#basic-validation
 */
import { Dialog } from 'quasar';

const popupConfig = {
  open(popupInfo) {
    const popup = Dialog.create({
      componentProps: popupInfo.options,
      component: popupInfo.component,
    });
    return popup;
  },
};

export default popupConfig;
