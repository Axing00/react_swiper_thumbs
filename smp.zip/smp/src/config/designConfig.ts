import type { App } from 'vue';

// Ant-d (빌드시간 줄이기 위해서 경로 직접 지정)
// import DatePicker from 'ant-design-vue/es/date-picker';
// import Table from 'ant-design-vue/es/table';
import { Table } from 'ant-design-vue';

export function setupAntDesign(app: App<Element>) {
  app.use(Table);
}
