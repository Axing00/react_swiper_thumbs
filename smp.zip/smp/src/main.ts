import { createApp } from 'vue';
import App from './App.vue';

import VNetworkGraph from 'v-network-graph';
import { setupRouter } from '@router';
import { setupStore } from '@store';

// import 'ant-design-vue/lib/style/index.css';
// import 'ant-design-vue/lib/table/style/index.css';
// import 'ant-design-vue/lib/pagination/style/index.css';
// import 'ant-design-vue/lib/select/style/index.css';
// import 'ant-design-vue/lib/dropdown/style/index.css';
import '@quasar/extras/material-icons/material-icons.css';
import '@quasar/extras/fontawesome-v6/fontawesome-v6.css';
// import 'quasar/src/css/index.sass';
import 'quasar/dist/quasar.prod.css';
import '@styles/index.scss';

import { setupGlobDirectives } from '@directives';
import { setupProvide } from '@config/provideConfig';
import { setupLanguage } from '@config/langConfig';
// import { setupAntDesign } from '@config/designConfig';
import { setupQuasar } from '@config/quasarConfig';

const app = createApp(App);

// vue devtools 확장앱 설정
app.config.performance = true;

// 순서 바꾸지 말기
setupLanguage(app); // set Language
setupGlobDirectives(app); // Configure directives
setupStore(app); // set Store
setupRouter(app); // set Router
// setupDesign(app); // antd & quasar 컴포넌트 등록
// setupAntDesign(app); // antd
setupQuasar(app); // Quasar

setupProvide(app); // set Provider

app.use(VNetworkGraph);
app.mount('#app');
