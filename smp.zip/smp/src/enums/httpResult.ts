export enum davisErrorCode {
  DAVIS_ERR_AUTH_1 = 'INVALID_ID_OR_PWD', // 아이디나 비밀번호가 틀릴 경우
  DAVIS_ERR_AUTH_2 = 'INVALID_SESSION', // 세션 정보가 없을 경우
  DAVIS_ERR_AUTH_3 = 'EXCEEDED_RETRY_CNT', // 로그인 시도 횟수 초과
  DAVIS_ERR_AUTH_4 = 'NO_PERMISSION', // 해당 요청을 수행할 권한 없음
  DAVIS_ERR_SIGNUP_1 = 'DUPLICATED_EXCEPTION', // 회원 가입 시 중복된 아이디
  DAVIS_ERR_PASS_1 = 'EQUALS_PREV_PWD', // 비밀번호 변경 시 이전 비밀번호와 중복
  DAVIS_ERR_COMMON_1 = 'Unprocessable Entity', // 잘못된 정보 입력

  // ERR_AUTH_1 = 'ERR-AUTH-1', // 아이디나 비밀번호가 틀릴 경우
  // ERR_REFRESH_1 = 'ERR-REFRESH-1', // 이미 강제 로그아웃된 Refresh-Token입니다.
  // ERR_COMMON_1 = 'ERR-COMMON-1', // 서버 내부 오류 발생. 0xXXXXXXXX
}

export enum LoginResultCode {
  NORMAL = 'normal', // 정상
  FIRST_LOGIN = 'firstLogin', // 첫 로그인
  EXPIRED_PASSWORD = 'expiredPassword', // 패스워드 변경 필요
}
