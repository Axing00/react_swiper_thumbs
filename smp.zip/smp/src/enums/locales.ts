import { TimeZone } from '@enums/timeZone';

export enum Locales {
  EN = 'en',
  KO = 'kr',
}

export const LocaleSupports = [
  { value: Locales.EN, caption: 'English', timeZone: TimeZone.UTC },
  { value: Locales.KO, caption: 'Korean', timeZone: TimeZone.ASIA_SEOUL },
];
