export enum PasswordPopupType {
  FIRST = 'first', // 최초 로그인
  PERIOD = 'period', // 패스워드 변경 기간
  CHANGE = 'change', // 패스워드 변경
}

export enum UserInfoPopupType {
  SIGNUP = 'signup', // 회원 가입 정보 전송
  ADMIN = 'infoChangeAdmin', // 회원 정보 변경 ( admin )
  USER = 'infoChangeInd', // 회원 정보 변경 ( 개인 회원 )
}
