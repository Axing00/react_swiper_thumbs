export enum EnumCache {
  // token key
  TOKEN_KEY = 'TOKEN__',
  // user info key
  USER_INFO_KEY = 'USER__INFO__',
  // role info key
  ROLES_KEY = 'ROLES__KEY__',
}
