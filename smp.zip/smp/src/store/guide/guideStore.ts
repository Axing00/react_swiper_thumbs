import { defineStore } from 'pinia';

export const useGuideStore = defineStore({
  id: 'guideStore',
  state: () => ({
    title: '',
    isCrumb: false,
    isDashboard: false,
  }),
  actions: {},
});
