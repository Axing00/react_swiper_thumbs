import { httpHelperV2 } from '@/utils/httpHelperV2';
import { defineStore } from 'pinia';
import notify from '@/config/notifyConfig';
// import { ref } from 'vue';

interface dashboardEntriesTopVO {
  license_usage_rate: number;
  license_count_activate: number;
  license_count_deactivate: number;
  license_before_expiration_30: number;
  license_before_expiration_60: number;
  license_before_expiration_etc: number;
  license_price_total: number;
  license_request_count: number;
  license_request_accept: number;
  license_request_end: number;
  voc_new: number;
  voc_await: number;
  voc_end: number;
}

interface dashboardLicenseUsageVO {
  software_id: number;
  software_name: string;
  license_count_activate: number;
  license_count_deactivate: number;
}

interface dashboardLicenseUsageUsergroupsVO {
  usergroup_id: number;
  usergroup_name: string;
  license_count_activate: number;
  license_count_deactivate: number;
}

interface dashboardLicenseUsageRealtimeVO {
  license_id: number;
  software_name: string;
  license_name: string;
  license_usage: number;
}

interface dashboardLicenseUsagePeriodVO {
  license_id: number;
  software_name: string;
  license_name: string;
  license_usage: Array<string>;
}

enum API {
  // 1. 라이선스 평균 사용률(라이선스 평균사용률 ,활성화 된 라이선스 수 ,비활성화 된 라이선스 수)
  // 2. 구독 갱신 30일전 (30일전, 60일전, 60일 이후)
  // 3. 총 지출금액 (모든 라이선스의 가격 합계)
  // 4. 라이선스 신청 현황 (라이선스 신청, 승인, 완료의 카운트 수)
  // 5. VOC 신규 현황 (VOC 신규,처리중,완료의 카운트 수 )
  dashboard_top = '/v1/dashboard/entries-top',
  // 라이선스 사용량 TOP-N
  dashboard_license_usage = '/v1/dashboard/license-usage',
  // 부서별 라이선스 사용량 TOP-N
  dashboard_usergroups = '/v1/dashboard/license-usage/usergroups',
  // 실시간 라이선스 사용량(모니터링-실시간 라이선스 사용량 에서 작성한 API 재사용)
  dashboard_realtime = '/v1/monitoring/license-usage/realtime',
  // 기간별 라이선스 사용량(모니터링-기간별 라이선스 사용량 에서 작성한 API 재사용)
  dashboard_period = '/v1/monitoring/license-usage/period',
}

export const useDashboardStore = defineStore({
  id: 'useDashboardStore',
  state: () => {
    return {
      dashboardEntriesTopData: {} as dashboardEntriesTopVO,
      dashboardLicenseUsageData: [] as Array<dashboardLicenseUsageVO>,
      dashboardLicenseUsageUsergroupsData:
        [] as Array<dashboardLicenseUsageUsergroupsVO>,
      dashboardLicenseUsageRealtimeData:
        [] as Array<dashboardLicenseUsageRealtimeVO>,
      dashboardLicenseUsagePeriodData:
        [] as Array<dashboardLicenseUsagePeriodVO>,
    };
  },
  actions: {
    // 대시보드 상단 데이터 조회
    async getDashboardEntriesTopData() {
      let result = 'nok';
      this.dashboardEntriesTopData = {} as dashboardEntriesTopVO;
      try {
        const response = await httpHelperV2().get(API.dashboard_top);
        result = response.result;
        console.log(response.status, response.data);
        if (result == 'ok') {
          this.dashboardEntriesTopData = response.data;
        } else {
          notify.error(response.error.error_messages);
        }
        return result;
      } catch (error: any) {
        console.log('getDashboardEntriesTopData', error);
        notify.error(error.message);
        return result;
      }
    },
    // 대시보드 라이선스 사용량 TOP-N 데이터 조회
    async getDashboardLicenseUsageData() {
      let result = 'nok';
      this.dashboardLicenseUsageData = [] as Array<dashboardLicenseUsageVO>;
      try {
        const response = await httpHelperV2().get(API.dashboard_license_usage);
        result = response.result;
        console.log(response.status, response.data);
        if (result == 'ok') {
          this.dashboardLicenseUsageData = response.data;
        } else {
          notify.error(response.error.error_messages);
        }
        return result;
      } catch (error: any) {
        console.log('getDashboardLicenseUsageData', error);
        notify.error(error.message);
        return result;
      }
    },
    // 대시보드 부서별 라이선스 사용량 TOP-N 데이터 조회
    async getDashboardLicenseUsageUsergroupsData() {
      let result = 'nok';
      this.dashboardLicenseUsageUsergroupsData =
        [] as Array<dashboardLicenseUsageUsergroupsVO>;
      try {
        const response = await httpHelperV2().get(API.dashboard_license_usage);
        result = response.result;
        console.log(response.status, response.data);
        if (result == 'ok') {
          this.dashboardLicenseUsageUsergroupsData = response.data;
        } else {
          notify.error(response.error.error_messages);
        }
        return result;
      } catch (error: any) {
        console.log('getDashboardLicenseUsageUsergroupsData', error);
        notify.error(error.message);
        return result;
      }
    },
    // 대시보드 실시간 라이선스 사용량 데이터 조회
    async getDashboardLicenseUsageRealtimeData() {
      let result = 'nok';
      this.dashboardLicenseUsageRealtimeData =
        [] as Array<dashboardLicenseUsageRealtimeVO>;
      try {
        const response = await httpHelperV2().get(API.dashboard_license_usage);
        result = response.result;
        console.log(response.status, response.data);
        if (result == 'ok') {
          this.dashboardLicenseUsageRealtimeData = response.data;
        } else {
          notify.error(response.error.error_messages);
        }
        return result;
      } catch (error: any) {
        console.log('getDashboardLicenseUsageRealtimeData', error);
        notify.error(error.message);
        return result;
      }
    },
    // 대시보드 실시간 라이선스 사용량 데이터 조회
    async getDashboardLicenseUsagePeriodData() {
      let result = 'nok';
      this.dashboardLicenseUsagePeriodData =
        [] as Array<dashboardLicenseUsagePeriodVO>;
      try {
        const response = await httpHelperV2().get(API.dashboard_license_usage);
        result = response.result;
        console.log(response.status, response.data);
        if (result == 'ok') {
          this.dashboardLicenseUsagePeriodData = response.data;
        } else {
          notify.error(response.error.error_messages);
        }
        return result;
      } catch (error: any) {
        console.log('getDashboardLicenseUsagePeriodData', error);
        notify.error(error.message);
        return result;
      }
    },
  },
});
