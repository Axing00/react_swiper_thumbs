import { defineStore } from 'pinia';

export const useMainTypeStore = defineStore({
  id: 'mainTypeStore',
  state: () => ({
    isOpenGuidePage: false,
  }),
  actions: {},
});
