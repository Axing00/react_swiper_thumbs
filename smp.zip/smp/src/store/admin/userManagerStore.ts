// import ClusterListDTO from '@/types/admin/clusterListDTO';
import GroupListDTO from '@/types/admin/groupListDTO';
import UserManagerListDTO from '@/types/admin/userManagerListDTO';
import UserManagerVO from '@/types/admin/userManagerVO';
import { httpHelperV2 } from '@/utils/httpHelperV2';
import { router } from '@router';
import { defineStore } from 'pinia';
import notify from '@/config/notifyConfig';
import { ref } from 'vue';

enum API {
  // davis Lite 사용 API
  USER_INFO_API = '/api/user/',

  // -------------------------

  UPDATE_USER = 'api/user/',
  USER_INFO = '/view/admin/user-management/user-info',
  DELETE_USER = '/view/admin/user-management/delete-user',
  CREATE_USER = '/api/user/',
  USER_LIST = '/api/user/',
  CLUSTER_LIST = '/view/admin/cluster/list',
  GROUP_LIST = '/view/admin/group-management/group-list',
  RESET_PASSWORD = '/view/admin/user-management/reset-user-password',
}

interface davisUserCreateVO {
  statusText: string;
  login_id: string;
  pwd_1: string;
  pwd_2: string;
  email: string;
  name: string;
}

interface changeDavisUserVO {
  statusText: string;
  id: number;
  email: string;
  name: string;
  privilege: number;
}

interface davisUserInfoVO {
  data?: [];
  id: number;
  login_id: string;
  name: string;
  privilege: string;
  email: string;
  created_time: Date;
  latest_login_time: Date;
}

interface davisIndUserInfoVO {
  data: {
    id: number;
    login_id: string;
    name: string;
    privilege: string;
    email: string;
    created_time: Date;
    latest_login_time: Date;
  };
}

export const useUserManager = defineStore({
  id: 'userManager',
  state: () => {
    return {
      userList: [] as UserManagerVO[],
      // davisUserList: [] as davisUserInfoVO[],
      davisUserList: ref<davisUserInfoVO[]>([]),
      currUserPriv: ref<string | number | null>(null),
    };
  },
  getters: {},
  actions: {
    // Davis 회원 생성 API
    async davisCreateUser(userVO: any): Promise<string> {
      userVO.pwd_1 = window.btoa(userVO.pwd_1);
      userVO.pwd_2 = window.btoa(userVO.pwd_2);

      const result = await httpHelperV2().post<davisUserCreateVO>(
        API.USER_INFO_API,
        userVO
      );

      return result.statusText;
    },

    // Davis 유저 전체 목록 조회
    async getDavisUserList() {
      const result = await httpHelperV2().get<davisUserInfoVO>(
        API.USER_INFO_API
      );

      // Store에 유저 list 저장
      this.davisUserList = result.data as [];
    },

    // Davis 유저 개인 조회
    async getDavisUserInd(usr_id) {
      const result = await httpHelperV2().get<davisIndUserInfoVO>(
        API.USER_INFO_API + usr_id
      );

      return result;
    },

    // Davis 유저 정보 변경
    async changeDavisUserInfo(changeInfo): Promise<string | undefined> {
      try {
        const result = await httpHelperV2().put<changeDavisUserVO>(
          API.USER_INFO_API,
          changeInfo
        );
        return result.statusText;
      } catch (err: unknown) {
        // console.log(err);
      }
    },

    async delDavisUser(usr_id) {
      const result = httpHelperV2().delete(API.USER_INFO_API + usr_id);

      return result;
    },

    // ---------------------------------- SDX -------------------------------------------

    // 유저 목록 및 유저 정보 생성
    makeUserList(list) {
      this.userList = list;
      router.push({ name: 'managerconfig.us' });
    },

    // SDX 유저 목록 조회
    async selectUserList() {
      const dto = await httpHelperV2().get<UserManagerListDTO>(API.USER_LIST);
      this.userList = dto.userManagerList.userInfos;
    },

    // SDX 유저 생성
    async createUser(userVO: any) {
      const dto = await httpHelperV2().post<UserManagerListDTO>(
        API.CREATE_USER,
        userVO
      );
      await this.makeUserList(dto.userManagerList.userInfos);
      return dto;
    },

    // SDX 유저 편집
    async updateUser(userVO: any) {
      const result = await httpHelperV2().put<UserManagerListDTO>(
        API.UPDATE_USER,
        userVO
      );
      const id = result.userManagerList.userId;
      const params = { id: id };
      const dto = await httpHelperV2().get<UserManagerListDTO>(
        API.USER_INFO,
        params
      );
      return dto;
    },

    // SDX 유저 삭제
    async userDelete(params: { id: string }) {
      await httpHelperV2().delete<UserManagerListDTO>(API.DELETE_USER, params);
      router.push({ name: 'managerconfig.us' });
    },

    // SDX 유저정보 조회
    async selectUserInfos(params: { id: string }) {
      const dto = await httpHelperV2().get<UserManagerVO>(
        API.USER_INFO,
        params
      );
      return dto;
    },

    // SDX 클러스터 목록 조회
    async selectClusterList() {
      // const dto = await httpHelperV2().get<ClusterListDTO>(API.CLUSTER_LIST);
      // // return dto.clusterList.cloud;
      // return dto.clusterList;
    },

    // SDX 그룹목록 조회
    async selectGroupList() {
      const dto = await httpHelperV2().get<GroupListDTO>(API.GROUP_LIST);
      return dto.groupInfos.groupList;
    },

    // SDX 비밀번호 초기화
    async resetPassword(params: { userid: string }) {
      const dto = await httpHelperV2().put<UserManagerListDTO>(
        API.RESET_PASSWORD,
        params
      );
      // return dto;
    },
  },
});
