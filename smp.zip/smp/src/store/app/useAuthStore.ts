import { MenuItem } from '@/router/menu';
import { httpHelperV2 } from '@/utils/httpHelperV2';
import { AxiosError } from 'axios';
import { defineStore } from 'pinia';
import cacheHelper, {
  cacheType,
  sessionUserInfoType,
} from '@/utils/cacheHelper';
import { useUserManager } from '../admin/userManagerStore';
import { router } from '@router';

enum API {
  LOGIN = '/api/auth/login',
  LOGOUT = '/api/auth/logout',
  PASSWORD_CHANGE = '/api/user/chg-pwd',
  AUTH_CHECK = '/api/auth/session-check',

  // USER_INFO = '/api/user/',
  // CLOSE_SESSION = '/view/auth/close-session',
  // CHECK_ALLOWED_MENU = '/view/auth/menu',
  // VALIDATE_ACCESS_TOKEN = '/view/auth/token-validate',
  // PASSWORD_VALIDATION_TYPE = '/view/auth/password-validation-type',
}

interface TokenInfoVO {
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
  refreshExpiresIn: number;
  isTemporary: boolean;
}

interface AuthorityVO {
  name: string;
}

interface LoginReturnVO {
  user: {
    id: number;
    login_id: string;
    email: string;
    name: string;
    privilege: 0;
    created_time: Date;
    latest_login_time: Date;
    require_chg_pwd: number;
  };
  menus: [
    {
      id: number;
      name: string;
      uri: string;
      privilege: number;
    }
  ];
}

interface LoginDTO {
  data?: LoginReturnVO;
  user?: {
    id: number;
    login_id: string;
    email: string;
    name: string;
    privilege: 0;
    created_time: Date;
    latest_login_time: Date;
    require_chg_pwd: number;
  };
  menus?: [
    {
      id: number;
      name: string;
      uri: string;
      privilege: number;
    }
  ];
  tokenInfo: TokenInfoVO;
  authority: AuthorityVO;
  loginResult: string;
  statusText: string | undefined;
}

interface HttpErrorVO {
  code: string;
  message: string;
}

interface PasswordChangeDTO {
  statusText?: string;
  data?: boolean;
  // data: 비밀번호 변경 후 return 받는 data 없이 이전 비밀번호와 중복 여부만을 파악하기 위한 true / false 로만 사용
  login_id: string;
  pwd_1: string;
  pwd_2: string;
}

const DEFAULT_ERROR_CODE = 'default_error';

export const useAuthStore = defineStore({
  id: 'useAuthStore',
  state: () => {
    return {
      userID: '' as string | undefined,
      userName: '' as string | undefined,
      userNo: 0 as number | null,
      menuItems: [] as MenuItem[],
      passwordValidationType: '0' as string,
    };
  },
  actions: {
    // 인증 정보 확인용 get 요청
    async authCheck(): Promise<boolean | undefined> {
      try {
        let result = await httpHelperV2()
          .disableShowError()
          .get(API.AUTH_CHECK);

        // 해당 요청에서 인증 정보 유무 확인은 단순 true / false 정보만 받는다.
        result = Boolean(result.data);

        return result;
      } catch (e) {
        console.error(e);
      }
    },

    /**
     * 로그인
     * @param userID
     * @param password
     * @returns
     */

    // Davis 로그인 API
    async davisLogin(userID: string, password: string): Promise<any> {
      // LoginDTO | undefined
      // 로그인 성공했을 때의 return 타입과 아이디 or 비밀번호 틀렸을 때 return 값의 타입이 달라 any로 설정

      try {
        let davisPsw = '';
        davisPsw = password;
        davisPsw = window.btoa(davisPsw);

        const res = await httpHelperV2().post<LoginDTO>(API.LOGIN, {
          login_id: userID,
          password: davisPsw,
        });

        return res;
      } catch (err: unknown) {
        // 로그인 오류 횟수 알림 및 처리는 httpHelperV2 오류 처리( afterAxiosError() )에 모아놓음
        return err;
      }
    },

    // SDX용 로그인 API
    async login(userID: string, password: string): Promise<string> {
      try {
        const dto = await httpHelperV2()
          .disableShowError() //  로그인 페이지에서 결과에 따른 메세지 처리
          .post<LoginDTO>(API.LOGIN, {
            userID: userID,
            password: password,
          });
        return dto.loginResult;
      } catch (err: unknown) {
        if (err instanceof AxiosError) {
          const result = err.response?.data as HttpErrorVO;
          return result?.code ?? DEFAULT_ERROR_CODE;
        } else {
          return DEFAULT_ERROR_CODE;
        }
      }
    },

    // 로그아웃 -> 세션(쿠키) 값 삭제 및 로그인 화면으로 이동
    async davisLogout() {
      const userManagerStore = useUserManager();

      try {
        await httpHelperV2().disableShowError().post(API.LOGOUT);
      } catch (e) {
        // console.error(e);
      } finally {
        // 헤더에 적용하기 위해 필요했던 로컬 스토리지 회원 아이디, 회원 이름 삭제
        cacheHelper.removeCache(cacheType.LOGIN_USER_ID);
        cacheHelper.removeCache(cacheType.USER_NAME);
        cacheHelper.removeCache(cacheType.USER_NO);

        router.push({
          name: 'MainLayout',
        });

        userManagerStore.davisUserList = [];
      }
    },

    // Davis 비밀번호 변경 API
    async davisChangePassword(
      currentLoginUserId: string,
      currentPassword: string,
      newPassword: string
    ): Promise<string | undefined> {
      try {
        const passwordChangeResult = await httpHelperV2()
          .disableProgress()
          .post<PasswordChangeDTO>(API.PASSWORD_CHANGE, {
            login_id: currentLoginUserId,
            pwd_1: currentPassword,
            pwd_2: newPassword,
          });

        if (passwordChangeResult.statusText === 'OK') {
          if (passwordChangeResult?.data === false) {
            return 'NOK';
          } else {
            return 'OK';
          }
        }
      } catch (err: unknown) {
        if (err instanceof AxiosError) {
          const result = err.response?.data as HttpErrorVO;
          return result.code;
        } else {
          throw err;
        }
      }
    },

    // SDX 비밀번호 변경 요청 API
    async changePassword(currentPassword: string, newPassword: string) {
      try {
        await httpHelperV2()
          .disableShowError()
          .post<string>(API.PASSWORD_CHANGE, {
            currentPassword: currentPassword,
            newPassword: newPassword,
          });

        return 'ok';
      } catch (err: unknown) {
        if (err instanceof AxiosError) {
          const result = err.response?.data as HttpErrorVO;
          return result.code;
        } else {
          throw err;
        }
      }
    },

    // async selectUserInfo(): Promise<void> {
    //   console.log(loginUserInfo.value.userID, loginUserInfo.value.userName);
    //   const loginUserInfo = await httpHelperV2()
    //     .disableShowError()
    //     .get(API.USER_INFO);
    //   console.log(loginUserInfo);
    //   const result = await httpHelperV2()
    //     .disableShowError()
    //     .get<UserInfoDTO>(API.USER_INFO);
    //   this.$patch({
    //     userID: result.userID,
    //     userName: result.userName,
    //     // menuItems: createMenuData(dto.allowedMenus),
    //   });
    // },

    /**
     * 이전 로그인 사용자 세션 닫기
     * @param userID
     * @param password
     */
    // async closeSession(userID: string, password: string): Promise<void> {
    //   await httpHelperV2().post<LoginDTO>(API.CLOSE_SESSION, {
    //     userID: userID,
    //     password: password,
    //   });
    // },

    /**
     * 토큰 검증
     * @returns
     */
    // async validateToken(): Promise<boolean> {
    //   try {
    //     const result = await httpHelperV2()
    //       .disableShowError()
    //       .get<any>(API.TEST);
    //     return result.active;
    //   } catch (error) {
    //     return false;
    //   }
    // },

    // async getPasswordValidationType() {
    //   const dto = await getPasswordValidationType();
    //   this.passwordValidationType = dto.passwordValidationType;
    //   return this.passwordValidationType;
    // },
  },
});

// if (import.meta.hot) {
//   import.meta.hot.accept(acceptHMRUpdate(useAuthStore, import.meta.hot));
// }
