import { defineStore } from 'pinia';

export const useThemeStore = defineStore({
  id: 'useThemeStore',
  state: () => {
    return {
      theme: 'dark' as string,
    };
  },
  actions: {
    async setTheme(theme: string) {
      this.theme = theme;
    },
  },
  getters: {
    getTheme(): string {
      return this.theme;
    },
  },
});
