import { httpHelperV2 } from '@/utils/httpHelperV2';
import { acceptHMRUpdate, defineStore } from 'pinia';

enum API {
  SYSTEM_INFO = '/app/system',
}

export const useAppStore = defineStore({
  id: 'useAppStore',
  state: () => {
    return {
      saasInfo: {},
    };
  },
  actions: {
    // async selectSystemInfo(): Promise<void> {
    //   const dto = await httpHelperV2()
    //     .disableShowError()
    //     .get<SystemInfoDTO>(API.SYSTEM_INFO);
    //   this.$patch({
    //     saasInfo: dto.saasInfo,
    //   });
    // },
  },
});

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useAppStore, import.meta.hot));
}
