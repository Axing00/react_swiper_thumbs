export default interface HttpErrorVO {
  code: string;
  message: string;
}
