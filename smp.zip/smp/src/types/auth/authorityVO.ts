export default interface AuthorityVO {
  name: string;
}
