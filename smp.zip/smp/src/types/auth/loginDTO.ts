import type TokenInfoVO from './tokenInfoVO';
import type AuthorityVO from './authorityVO';

export default interface LoginDTO {
  tokenInfo: TokenInfoVO;
  authority: AuthorityVO;
  loginResult: string;
}
