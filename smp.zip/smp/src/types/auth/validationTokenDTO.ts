export default interface ValidationTokenDTO {
  active: boolean;
}
