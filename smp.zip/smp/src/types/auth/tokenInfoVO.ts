export default interface TokenInfoVO {
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
  refreshExpiresIn: number;
  isTemporary: boolean;
}
