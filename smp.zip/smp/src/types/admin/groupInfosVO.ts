export default interface GroupInfosVO {
  count: string;
  groupList: [];
  menuCodeList: [];
  name: string;
  authList: [];
  users: [];
  userList: [];
  groups: [];
  desc: string;
  members: [];
  others: [];
}
