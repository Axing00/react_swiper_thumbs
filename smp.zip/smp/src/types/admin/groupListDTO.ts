import type groupInfosVO from './groupInfosVO';

export default interface GroupListDTO {
  groupInfos: groupInfosVO;
  menuInfos: groupInfosVO;
  groupInfo: groupInfosVO;
}
