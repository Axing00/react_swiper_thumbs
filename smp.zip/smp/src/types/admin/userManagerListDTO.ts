export default interface UserManagerListDTO {
  userManagerList: {
    count: string;
    userInfos: [];
    userInfo: object;
    userId: string;
  };
}
