export default interface UserManagerVO {
  userName: string;
  userId: string;
  authClass: string;
  group: string;
  lastJoin: string;
  changePWD: string;
  phoneNumber: string;
  useYn: string;
  cluster: [];
  comments: string;
  password: string;
  clusterNames: string;
}
