import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import { lang } from '@/config/langConfig';
import { i18n } from '@/config/langConfig';
import { Locales, LocaleSupports } from '@enums/locales';
import 'dayjs/locale/ko';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone'; // dependent on utc plugin

dayjs.extend(utc);
dayjs.extend(timezone);

/**
 * 타임존 UTC -> 현재 타임존으로 수정
 * @param val 날짜 데이터
 * @param format 변경할 포맷 데이터
 */
export function convertTimeZone(val: string, format: string) {
  const value = dayjs.utc(val);
  const timeZoneObj = getTimeZone();
  if (timeZoneObj) {
    return value.tz(timeZoneObj.timeZone).format(format);
  }
  return value.format(format);
}

/**
 * 현재 타임존 구하기
 */
function getTimeZone() {
  for (const localeObject of LocaleSupports) {
    if (localeObject.value === i18n.global.locale.value) {
      return localeObject;
    }
  }
  return null;
}

/**
 * 날짜 형식 변경
 * @param date 날짜
 * @returns 'yyyy/mm/dd hh:mm:ss'
 * @returns '수행안함'
 */
export function parseDateFormat(date: string | undefined) {
  return date
    ? convertTimeZone(date, 'YYYY-MM-DD HH:mm:ss')
    : lang('iaas.never');
}

/**
 * 새로고침 경과 시간 계산
 * @param lastRefreshError 에러 메시지
 * @param refreshDate 새로고침날짜
 * @returns '성공여부, 경과시간, 에러메시지'
 */
export function getLastRefreshDate(
  lastRefreshError: string | undefined,
  refreshDate: string
) {
  dayjs.extend(relativeTime);
  if (i18n.global.locale.value == Locales.KO) {
    dayjs.locale('ko');
  }
  const time = dayjs(convertTimeZone(refreshDate, 'YYYY-MM-DD')).fromNow();
  return lastRefreshError
    ? `Error - ${lang('iaas.about')} ${time} ${lastRefreshError}`
    : `Success - ${lang('iaas.about')} ${time}`;
}

/**
 * 현재시간 구하기
 * @param lastRefreshError 에러 메시지
 * @param refreshDate 새로고침날짜
 * @returns '성공여부, 경과시간, 에러메시지'
 */
export function getCurrentTime() {
  const today = new Date();

  const year = today.getFullYear(); // 년도
  const month = today.getMonth() + 1; // 월
  const date = today.getDate(); // 날짜
  const hours = today.getHours(); // 시
  const minutes = today.getMinutes(); // 분
  const seconds = today.getSeconds(); // 초
  // let milliseconds = today.getMilliseconds(); // 밀리
  const day = `${year}-${month >= 10 ? month : '0' + month}-${
    date >= 10 ? date : '0' + date
  } ${hours}:${minutes}:${seconds}`;
  return day;
}
