/**
 * 소수점 셋째자리 이하 내림 Mib (메모리) 계산
 * @param memory 메모리 byte 크기
 * @returns Mib 단위 메모리
 */
export function mibCalc(memory: number) {
  const m = Math.floor((memory / 1024 / 1024) * 1000);
  return m / 1000;
}

/**
 * byte to Core (CPU)
 * @param byteNumber 메모리 byte 크기
 * @param deciam 소수점 자리수
 * @returns GB 단위 메모리
 */
export function coreCalc(byteNumber: number, deciam: number) {
  switch (deciam) {
    case 1:
      return Math.floor(byteNumber / 100) / 10;
    case 2:
      return Math.floor(byteNumber / 10) / 100;
    case 3:
      return Math.floor(byteNumber) / 1000;
    default:
      return Math.floor(byteNumber / 100);
  }
}

/**
 * byte to GB (Memory)
 * @param byteNumber 메모리 byte 크기
 * @param deciam 소수점 자리수
 * @returns GB 단위 메모리
 */
export function gbCalc(byteNumber: number, deciam: number) {
  switch (deciam) {
    case 1:
      return Math.floor((byteNumber / 1024 / 1024 / 1024) * 10) / 10;
    case 2:
      return Math.floor((byteNumber / 1024 / 1024 / 1024) * 100) / 100;
    case 3:
      return Math.floor((byteNumber / 1024 / 1024 / 1024) * 1000) / 1000;
    default:
      return Math.floor(byteNumber / 1024 / 1024 / 1024);
  }
}

// byte to GB
export function gbCalcDeciamlOne(byteNumber: number) {
  const m = Math.floor(byteNumber / 1024 / 1024 / 1024);
  return m;
}

/**
 * byte to memory with unit
 * @param byteNumber 메모리 byte 크기
 * @param fixed 소수점 자리수
 * @returns 크기에 맞는 메모리+단위
 */
export function byteConverter(memory: number, fixed: number) {
  if (memory === 0) return '0 Byte';
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(memory) / Math.log(1024));
  return (
    parseFloat((memory / Math.pow(1024, i)).toFixed(fixed)) + ' ' + sizes[i]
  );
}

/**
 * hz to resources with unit
 * @param resource CPU 리소스 hz 크기
 * @param fixed 소수점 자리수
 * @returns 크기에 맞는 리소스+단위
 */
export function hzConverter(resource: number, fixed: number) {
  if (resource === 0) return '0 Hz';
  const sizes = ['Hz', 'KHz', 'MHz', 'GHz', 'THz'];
  const i = Math.floor(Math.log(resource) / Math.log(1000));
  return (
    parseFloat((resource / Math.pow(1000, i)).toFixed(fixed)) + ' ' + sizes[i]
  );
}
