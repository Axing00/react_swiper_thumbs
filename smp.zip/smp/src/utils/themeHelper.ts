import cacheHelper, { cacheType } from '@/utils/cacheHelper';
import { useThemeStore } from '@/store/app/useThemeStore';

const themeStore = useThemeStore();

export enum ThemeType {
  DARK = 'dark',
  LIGHT = 'light',
}

/**
 * 저장된 테마 불러오기
 * @returns : 기본값 dark
 */
export function getTheme(): ThemeType {
  const myTheme = cacheHelper.getCache(cacheType.MY_THEME);
  switch (myTheme) {
    case 'dark':
      return ThemeType.DARK;
    case 'light':
      return ThemeType.LIGHT;
    default:
      return ThemeType.DARK;
  }
}

/**
 * 테마 저장
 * @param myTheme
 */
export function setTheme(myTheme: ThemeType): void {
  cacheHelper.setCache(cacheType.MY_THEME, myTheme);
  themeStore.setTheme(getTheme());
}

/**
 * 지정된 테마 적용
 * @param myTheme
 */
export function applyTheme(myTheme: ThemeType): void {
  const bodyTag = document.getElementsByTagName('body')[0];
  if (myTheme == ThemeType.DARK) {
    bodyTag.className = bodyTag.className.replaceAll(
      'body--light',
      'body--dark'
    );
  } else {
    bodyTag.className = bodyTag.className.replaceAll(
      'body--dark',
      'body--light'
    );
  }
  setTheme(myTheme);
}

/**
 * 테마 불러오기
 */
export function loadTheme() {
  const myTheme = getTheme();
  applyTheme(myTheme);
}
