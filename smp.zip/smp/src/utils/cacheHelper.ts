/**
 * 로컬, 세션 스토리지 사용 유틸
 */

export enum cacheType {
  LOCALE = 'locale',
  USER_ID = 'userID',
  MAIN_SELECTED_NODE = 'selectedNodeKey',
  MY_THEME = 'mytheme',
  USER_NAME = 'loginUserName',
  USER_PRIV = 'loginUserPrivilege',
  USER_NO = 'loginUserNo',
  LOGIN_USER_ID = 'loginUserId',
}
export enum sessionUserInfoType {
  USER_ID = 'loginUserId',
  USER_NAME = 'loginUserName',
  USER_PRIV = 'loginUserPrivilege',
  USER_NO = 'loginUserNo',
}

class LocalCache {
  setCache(key: string, value: any) {
    if (value) {
      window.localStorage.setItem(key, JSON.stringify(value));
    }
  }

  getCache(key: string) {
    const value = window.localStorage.getItem(key);
    if (value) {
      return JSON.parse(value);
    }
  }

  removeCache(key: string) {
    window.localStorage.removeItem(key);
  }

  clearLocal() {
    window.localStorage.clear();
  }

  setSession(key: string, value: any) {
    if (value) {
      window.sessionStorage.setItem(key, JSON.stringify(value));
    }
  }

  getSession(key: string) {
    const value = window.sessionStorage.getItem(key);
    if (value) {
      return JSON.parse(value);
    }
  }

  removeSession(key: string) {
    window.sessionStorage.removeItem(key);
  }
}

export default new LocalCache();
