/**
 *
 * @param ms - 1000 - 1초
 * @returns
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
