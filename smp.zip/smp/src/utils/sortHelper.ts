export function sortAlpha(a: string, b: string) {
  if (a < b) return -1; // asc
  else if (a > b) return 1; // desc
  else return 0; // default
}
export function sortNumber(a: number, b: number) {
  return a - b;
}

// 필요시 테스트 후 적용
// sortString(a, b) {
//   return a.localeCompare(b);
// },
// sortNumChat(a, b) {
//   return new Date(a) - new Date(b);
// },

// sortDate(a, b) {
//   return new Date(a) - new Date(b);
// },
// sortBoolean(a, b) {
//   return a && !b ? -1 : !a && b ? 1 : 0;
// },
