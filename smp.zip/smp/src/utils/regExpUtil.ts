const regExpUtil = {
  /**
   * 문자열 최소/최대
   * @param pwd
   * @param min
   * @param max
   * @returns
   */
  checkMinMaxLength(str: string, min: number, max: number): boolean {
    const minReg = new RegExp(`^[\\S]{${min}}`);
    const maxReg = new RegExp(`^[\\S]{1,${max}}$`);
    // const minMax = new RegExp(`^[\\S]{${min},${max}}$`);
    return minReg.test(str) && maxReg.test(str);
  },

  /**
   * 문자열 반복 체크
   * count를 초과한 동일한 문자가 입력되는지 체크
   * @param pwd
   * @param count
   * @returns
   */
  checkOverRepeat(str: string, count: number): boolean {
    const rep = '\\1';
    const minReg = new RegExp(`(\\w)${rep.repeat(count)}`);
    return minReg.test(str);
  },

  /**
   * 최소 알파벳 1개 포함
   * @param str
   * @param min
   * @returns
   */
  checkMinAlpha(str: string): boolean {
    const minAlReg = new RegExp(`(?=.*[a-zA-Z]{1,}).*[\\S]`);
    return minAlReg.test(str);
  },

  /**
   * 최소 1개 숫자
   * @param str
   * @returns
   */
  checkMinNum(str: string): boolean {
    const minAlReg = new RegExp(`(?=.*\\d{1,}).*[\\S]`);
    return minAlReg.test(str);
  },

  /**
   * 최소 1개 특수 문자
   * @param str
   * @returns
   */
  checkMinSpecial(str: string): boolean {
    const minSpReg = new RegExp(`(?=.*[~\`!@#$%\\^&*()-+=]{1,50}).*[\\S]`);
    return minSpReg.test(str);
  },
};

export default regExpUtil;
