export const defaultPagination = {
  position: ['bottomCenter'], // 페이지네이션 위치 (하단 중앙)
  hideOnSinglePage: false, // 1페이지만 존재할 경우 페이지네이션 숨김
  showSizeChanger: true, // 페이지 사이즈 변경 옵션 노출 여부
  showQuickJumper: true, // 퀵 점퍼(페이지 번호로 이동) 노출 여부
  // showTotal: (total) => `Total ${total} items`, // 총 건수 표시
};
