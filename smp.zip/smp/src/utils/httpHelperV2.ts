/**
 * axios 사용 유틸
 */
import notify from '@/config/notifyConfig';
import { davisErrorCode } from '@/enums/httpResult';
import progressConfig from '@config/progressConfig';
import Axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { router } from '@router';
import cacheHelper, { cacheType } from '@/utils/cacheHelper';

// davis 에서 추가
import { lang } from '@/config/langConfig';
import { useAuthStore } from '@/store/app/useAuthStore';
import { useUserManager } from '@/store/admin/userManagerStore';
import { ref } from 'vue';
// ---------------

export interface HttpErrorVO {
  error_code?: string;
  messages?: string;
  code: string;
  from: string;
  message: string;
}

// 인증 정보 Header에 저장
const axiosInstance: AxiosInstance = Axios.create({
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 20000,
  // headers: axiosHeaders,
});

/**
 * Refresh Token 갱신 실패시 로그인 페이지로 이동
 * @returns
 */
// async function refreshToken(): Promise<void> {
//   await Axios.post(API.REFRESH_TOKEN);
// }

// 확인 필요함
/**
 * axios 응답값 중간 처리
 */
// axiosInstance.interceptors.response.use(
//   (response) => {
//     console.log(response);
//     return response.data;
//   },
//   async (error) => {
//     return Promise.reject(error);
//   }
// );

/**
 * API 통신 실패시 에러 처리
 * @param response
 * @param isDisableShowError
 */
function afterAxiosError(
  response: AxiosResponse<unknown, any>,
  isDisableShowError: boolean
): void {
  // const authStore = useAuthStore();
  // const userManagerStore = useUserManager();
  // const data = response?.data as HttpErrorVO;
  // const loginUserinfo = cacheHelper.getCache(cacheType.USER_NO);
  // const loginUserPriv = userManagerStore.currUserPriv;
  // const errorMsg = '';
  // if (data.error_code == davisErrorCode.DAVIS_ERR_AUTH_1) {
  //   errorMsg = `${lang('davisMsg.login.error.loginFailed')} `; // `아이디 혹은 패스워드가 일치하지 않습니다.`;
  // } else if (data.error_code == davisErrorCode.DAVIS_ERR_AUTH_2) {
  //   errorMsg = lang('davisMsg.login.error.sessionFail'); // '인증 정보가 만료되었거나, 인증정보를 찾을 수 없습니다. 로그인 페이지로 돌아갑니다.'
  //   moveToLogin();
  // } else if (data.error_code == davisErrorCode.DAVIS_ERR_AUTH_3) {
  //   errorMsg = lang('davisMsg.login.error.noLoginCount'); // '로그인 시도 횟수를 초과하셨습니다. 관리자에게 문의해 주십시오.';
  // } else if (response.statusText == davisErrorCode.DAVIS_ERR_COMMON_1) {
  //   if (loginUserinfo) {
  //     errorMsg = lang('davisMsg.valueError'); // '잘못된 입력입니다. 형식에 맞게 입력하신 후 다시 시도해주세요';
  //   } else {
  //     errorMsg = lang('davisMsg.login.error.noUserINfo'); // "회원 정보를 가져올 수 없습니다. 다시 로그인해 주세요"
  //     authStore.davisLogout();
  //   }
  // } else if (data.error_code == davisErrorCode.DAVIS_ERR_AUTH_4) {
  //   errorMsg = lang('davisMsg.noAuth'); // '해당 요청을 수행할 권한이 없습니다.';
  // } else if (data.error_code == davisErrorCode.DAVIS_ERR_SIGNUP_1) {
  //   errorMsg = lang('davisMsg.login.error.duplicateUserID'); // '중복된 아이디입니다. 다른 아이디를 사용해주세요.';
  // } else if (data.error_code == davisErrorCode.DAVIS_ERR_PASS_1) {
  //   if (loginUserPriv != 2) {
  //     errorMsg = lang('davisMsg.passwordChange.error.nowUsedPassword'); // '현재 사용하고 있는 비밀번호 입니다.';
  //   } else {
  //     errorMsg = lang('davisMsg.passwordChange.error.usedNewPassword'); // '이전에 사용된 비밀번호는 사용할 수 없습니다.';
  //   }
  // } else if (data.error_code == 'KPI_IN_USE_NOT_DELETED') {
  //   errorMsg = lang('davisMsg.kpi.delete_error');
  // } else if (data.error_code == 'DASHBOARD_DUPLICATED_EXCEPTION') {
  //   errorMsg = lang('davisMsg.dashboard.duplicate_error');
  // } else if (data.error_code == 'KPI_DEFAULT_NOT_CHANGED') {
  //   errorMsg = lang('davisMsg.kpi.defualt_not_changed');
  // } else {
  //   errorMsg = lang('davisMsg.unExpectedError'); // '알수 없는 에러가 발생 했습니다. 잠시 후 다시 시도하시거나 관리자에게 문의 하십시오.'
  // }
  // if (!isDisableShowError) {
  //   notify.error(errorMsg);
  //   throw data.error_code;
  // }
}

// 로그인으로 이동 ( + 로그아웃 )
function moveToLogin() {
  const authStore = useAuthStore();
  setTimeout(() => {
    authStore.davisLogout();

    router.push({
      name: 'Login',
    });
  }, 3000);
}

type axiosFnType = <T = any, R = AxiosResponse<T>, D = any>(
  url: string,
  config?: AxiosRequestConfig<D>
) => Promise<R>;

const httpHelperV2 = () => {
  let isDisableProgress = false;
  let isDisableShowError = false;

  async function callAxiosFn(fn: axiosFnType, url: string, config?: object) {
    let result;

    try {
      if (!isDisableProgress) {
        progressConfig.show();
      }
      result = await fn(url, config);
    } catch (error) {
      if (Axios.isAxiosError(error) && error.response) {
        afterAxiosError(error.response, isDisableShowError);
      } else {
        if (!isDisableShowError) {
          notify.error('common.error.unexpected');
        }
      }

      throw error;
    } finally {
      if (!isDisableProgress) {
        progressConfig.hide();
      }
    }
    return result;
  }

  const helper = {
    disableProgress() {
      isDisableProgress = true;
      return helper;
    },
    disableShowError() {
      isDisableShowError = true;
      return helper;
    },

    get<T = any>(url: string, data?: object): Promise<T> {
      return callAxiosFn(axiosInstance.get, url, { params: data });
    },

    post<T = any>(url: string, data?: object): Promise<T> {
      return callAxiosFn(axiosInstance.post, url, data);
    },

    put<T = any>(url: string, data?: object): Promise<T> {
      return callAxiosFn(axiosInstance.put, url, data);
    },

    patch<T = any>(url: string, data?: object): Promise<T> {
      return callAxiosFn(axiosInstance.patch, url, data);
    },

    delete<T = any>(url: string, data?: object): Promise<T> {
      return callAxiosFn(axiosInstance.delete, url, { params: data });
    },
  };
  return helper;
};

export { httpHelperV2, axiosInstance };
