# httpHelperV2

- 변경 사항

  - 토큰 자동 갱신 추가
  - disableProgress / disableShowError 추가

- 참고 샘플
  - useTodoInfoStore.ts
  - useTodoListStore.ts
  - TodoListView.vue

## 1 기본 형

```ts
import { httpHelperV2 } from '@/utils/httpHelperV2';
const result = await httpHelperV2().get<결과 타입>('/view/sample/test-get', { i: 2 });
const result = await httpHelperV2().post<결과 타입>('/view/sample/test-post', { id: 2 });
const result = await httpHelperV2().put<결과 타입>('/view/sample/test-put', { id: 2 });
const result = await httpHelperV2().delete<결과 타입>('/view/sample/test-delete', {
  id: 2,
});
```

## 2 disableProgress/disableShowError

```ts
import { httpHelperV2 } from '@/utils/httpHelperV2';
const dto = await httpHelperV2()
  .disableProgress() // progress 비활성화
  .disableShowError() // 에러메세지 출력 비활성화
  .get<TodoListDTO>(API.TODO_LIST); // get,post,put,delete 는 제일 마지막에 호출
```

## 3

disableShowError()를 사용하는 경우 에러 처리(메세지 출력)를 수동으로

```ts
import { httpHelperV2 } from '@/utils/httpHelperV2';

try {
  const dto = await httpHelperV2()
    .disableShowError() // 에러메세지 출력 비활성화
    .get<TodoListDTO>(API.TODO_LIST); // get,post,put,delete 는 제일 마지막에 호출
} catch (error) {
  console.log(error);
}
```
