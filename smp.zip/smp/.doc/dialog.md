# Dialog

## Confirm

```ts
import dialog from '@/components/dialog';

// dialog.confirm(title, message) > 다국어 키 사용
dialog
  .confirm('common.dialog.confirm', '등록하시겠습니까?')
  .onOk(() => {
    console.log('ok!!!');
  })
  .onCancel(() => {
    console.log('cancel!!!');
  });
```

## Custom dialog

### 기본

기본형 사용자 정의 컴포넌트 : 확인/취소 버튼을 그대로 사용할 경우

- 참고 : @views/guide/popup/ModalExample.vue

사용자 정의 컴포넌트 : 확인/취소외 버튼을 추가한 경우

- 참고 : @views/guide/popup/ModalExampleButton3.vue

Dialog위에 confirm Dialog를 실행할 경우

- 참고 : @views/guide/popup/ModalExampleOnDialog.vue

### 실행

```ts

import dialog from '@/components/dialog';
dialog
  .open({
    component: PasswordChangePopupVue, <- 사용자 정의 컴포넌트
    componentProps: {
      text: 'something',            <- 전달 값
    },
  })
  .onOk(() => {
    console.log('ok!!!');
  })
  .onCancel(() => {
    console.log('cancel!!!');
  });
```
