#Notify

```ts
import notify from '@/config/notifyConfig';

notify.warning('login.error.emptyUserIDPassword');
notify.error('다국어 키');
notify.info('다국어 키');
```
